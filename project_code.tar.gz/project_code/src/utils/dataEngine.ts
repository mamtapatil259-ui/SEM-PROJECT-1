import Papa from "papaparse";
import { ColumnSchema, ColumnType, AggregationType, FilterState } from "../types";

export function analyzeDatasetSchema(rows: Record<string, any>[]): ColumnSchema[] {
  if (!rows || rows.length === 0) return [];

  // Get all unique keys across rows
  const keys = Array.from(new Set(rows.flatMap(r => Object.keys(r))));

  return keys.map(key => {
    const values = rows.map(r => r[key]);
    const nonNullValues = values.filter(v => v !== null && v !== undefined && v !== "");
    const nullCount = values.length - nonNullValues.length;
    const uniqueValues = new Set(nonNullValues);

    let type: ColumnType = "string";

    if (nonNullValues.length > 0) {
      // Check if all are boolean
      const allBoolean = nonNullValues.every(v => 
        typeof v === "boolean" || v === "true" || v === "false" || v === "Yes" || v === "No"
      );

      // Check if all are number
      const allNumber = nonNullValues.every(v => {
        if (typeof v === "number") return !isNaN(v);
        if (typeof v === "string") {
          const trimmed = v.trim().replace(/^[$-]/, "").replace(/,/g, "");
          return trimmed !== "" && !isNaN(Number(trimmed));
        }
        return false;
      });

      // Check if all are date (e.g. YYYY-MM-DD, MM/DD/YYYY)
      const allDate = !allNumber && nonNullValues.every(v => {
        if (typeof v !== "string") return false;
        const dateRegex = /^\d{4}-\d{2}-\d{2}|\d{1,2}\/\d{1,2}\/\d{2,4}|\d{4}\/\d{2}\/\d{2}/;
        if (!dateRegex.test(v)) return false;
        const parsed = Date.parse(v);
        return !isNaN(parsed);
      });

      if (allBoolean) {
        type = "boolean";
      } else if (allNumber) {
        type = "number";
      } else if (allDate) {
        type = "date";
      }
    }

    const schema: ColumnSchema = {
      name: key,
      type,
      sampleValues: Array.from(uniqueValues).slice(0, 5),
      uniqueCount: uniqueValues.size,
      nullCount
    };

    if (type === "number" && nonNullValues.length > 0) {
      const numVals = nonNullValues.map(v => {
        if (typeof v === "number") return v;
        return Number(String(v).replace(/^[$-]/, "").replace(/,/g, ""));
      }).filter(n => !isNaN(n));

      if (numVals.length > 0) {
        schema.min = Math.min(...numVals);
        schema.max = Math.max(...numVals);
        schema.mean = Number((numVals.reduce((a, b) => a + b, 0) / numVals.length).toFixed(2));
      }
    }

    return schema;
  });
}

export function parseRawInput(input: string, format: "csv" | "json" | "tsv" | "auto" = "auto"): { rows: any[]; error?: string } {
  const trimmed = input.trim();
  if (!trimmed) {
    return { rows: [], error: "Input text is empty." };
  }

  let actualFormat = format;
  if (actualFormat === "auto") {
    if (trimmed.startsWith("[") || trimmed.startsWith("{")) {
      actualFormat = "json";
    } else if (trimmed.includes("\t") && !trimmed.includes(",")) {
      actualFormat = "tsv";
    } else {
      actualFormat = "csv";
    }
  }

  if (actualFormat === "json") {
    try {
      const parsed = JSON.parse(trimmed);
      let rows: any[] = [];
      if (Array.isArray(parsed)) {
        rows = parsed;
      } else if (typeof parsed === "object" && parsed !== null) {
        // Look for array inside object (e.g. { data: [...] })
        const arrayProp = Object.values(parsed).find(val => Array.isArray(val));
        if (arrayProp) {
          rows = arrayProp as any[];
        } else {
          rows = [parsed];
        }
      }
      return { rows };
    } catch (err: any) {
      return { rows: [], error: `Invalid JSON format: ${err.message}` };
    }
  }

  // Parse CSV or TSV with PapaParse
  const delimiter = actualFormat === "tsv" ? "\t" : "";
  const result = Papa.parse(trimmed, {
    header: true,
    dynamicTyping: true,
    skipEmptyLines: true,
    delimiter: delimiter as any
  });

  if (result.errors && result.errors.length > 0 && result.data.length === 0) {
    return { rows: [], error: `CSV/TSV Parse error: ${result.errors[0].message}` };
  }

  // Clean keys
  const cleanRows = result.data.map((row: any) => {
    if (typeof row !== "object" || row === null) return {};
    const newRow: Record<string, any> = {};
    for (const [key, val] of Object.entries(row)) {
      const cleanKey = key.trim();
      if (cleanKey) {
        newRow[cleanKey] = val;
      }
    }
    return newRow;
  }).filter((r: any) => Object.keys(r).length > 0);

  return { rows: cleanRows };
}

export function calculateAggregation(rows: Record<string, any>[], column: string, agg: AggregationType): number {
  if (!rows || rows.length === 0 || !column) return 0;

  const values = rows.map(r => {
    const val = r[column];
    if (typeof val === "number") return val;
    if (typeof val === "string") {
      const num = Number(val.replace(/^[$-]/, "").replace(/,/g, ""));
      return isNaN(num) ? null : num;
    }
    return null;
  }).filter((v): v is number => v !== null && v !== undefined);

  if (values.length === 0) {
    if (agg === "COUNT") return rows.length;
    return 0;
  }

  switch (agg) {
    case "SUM":
      return Number(values.reduce((a, b) => a + b, 0).toFixed(2));
    case "AVERAGE":
      return Number((values.reduce((a, b) => a + b, 0) / values.length).toFixed(2));
    case "MAX":
      return Math.max(...values);
    case "MIN":
      return Math.min(...values);
    case "COUNT":
      return rows.length;
    default:
      return 0;
  }
}

export function prepareChartData(
  rows: Record<string, any>[],
  xCol: string,
  yCol: string,
  agg: AggregationType,
  groupCol?: string
): any[] {
  if (!rows || rows.length === 0 || !xCol) return [];

  // If groupCol is provided, we group by xCol AND generate multiple keys
  if (groupCol && groupCol !== xCol) {
    const map = new Map<string, Record<string, number[]>>();
    const allGroups = new Set<string>();

    rows.forEach(r => {
      const xVal = String(r[xCol] ?? "Unknown");
      const gVal = String(r[groupCol] ?? "Other");
      allGroups.add(gVal);

      if (!map.has(xVal)) {
        map.set(xVal, {});
      }
      const groupMap = map.get(xVal)!;
      if (!groupMap[gVal]) {
        groupMap[gVal] = [];
      }

      let yVal = r[yCol];
      if (typeof yVal === "string") {
        yVal = Number(yVal.replace(/^[$-]/, "").replace(/,/g, ""));
      }
      if (typeof yVal === "number" && !isNaN(yVal)) {
        groupMap[gVal].push(yVal);
      } else if (agg === "COUNT") {
        groupMap[gVal].push(1);
      }
    });

    const result: any[] = [];
    map.forEach((groupMap, xVal) => {
      const rowObj: Record<string, any> = { name: xVal };
      allGroups.forEach(gVal => {
        const vals = groupMap[gVal] || [];
        if (vals.length === 0) {
          rowObj[gVal] = 0;
        } else if (agg === "SUM") {
          rowObj[gVal] = Number(vals.reduce((a, b) => a + b, 0).toFixed(2));
        } else if (agg === "AVERAGE") {
          rowObj[gVal] = Number((vals.reduce((a, b) => a + b, 0) / vals.length).toFixed(2));
        } else if (agg === "MAX") {
          rowObj[gVal] = Math.max(...vals);
        } else if (agg === "MIN") {
          rowObj[gVal] = Math.min(...vals);
        } else if (agg === "COUNT") {
          rowObj[gVal] = vals.length;
        }
      });
      result.push(rowObj);
    });

    return result.slice(0, 30); // limit to 30 items for visual clarity
  }

  // Simple grouping by xCol
  const map = new Map<string, number[]>();
  rows.forEach(r => {
    const xVal = String(r[xCol] ?? "Unknown");
    if (!map.has(xVal)) {
      map.set(xVal, []);
    }
    let yVal = r[yCol];
    if (typeof yVal === "string") {
      yVal = Number(yVal.replace(/^[$-]/, "").replace(/,/g, ""));
    }
    if (typeof yVal === "number" && !isNaN(yVal)) {
      map.get(xVal)!.push(yVal);
    } else if (agg === "COUNT") {
      map.get(xVal)!.push(1);
    }
  });

  const result: any[] = [];
  map.forEach((vals, xVal) => {
    let finalVal = 0;
    if (vals.length > 0) {
      if (agg === "SUM") {
        finalVal = Number(vals.reduce((a, b) => a + b, 0).toFixed(2));
      } else if (agg === "AVERAGE") {
        finalVal = Number((vals.reduce((a, b) => a + b, 0) / vals.length).toFixed(2));
      } else if (agg === "MAX") {
        finalVal = Math.max(...vals);
      } else if (agg === "MIN") {
        finalVal = Math.min(...vals);
      } else if (agg === "COUNT") {
        finalVal = vals.length;
      }
    }
    result.push({ name: xVal, value: finalVal });
  });

  return result.slice(0, 30);
}

export function filterDataset(
  rows: Record<string, any>[],
  filterState: FilterState,
  columns: ColumnSchema[]
): Record<string, any>[] {
  if (!rows || rows.length === 0) return [];

  const filtered = rows.filter(row => {
    // 1. Search Query filter across all string columns
    if (filterState.searchQuery && filterState.searchQuery.trim() !== "") {
      const q = filterState.searchQuery.toLowerCase().trim();
      const match = Object.values(row).some(val => 
        val !== null && val !== undefined && String(val).toLowerCase().includes(q)
      );
      if (!match) return false;
    }

    // 2. Categorical filters
    if (filterState.categoricalFilters) {
      for (const [col, allowedValues] of Object.entries(filterState.categoricalFilters)) {
        if (allowedValues && allowedValues.length > 0) {
          const cellVal = String(row[col] ?? "Unknown");
          if (!allowedValues.includes(cellVal)) {
            return false;
          }
        }
      }
    }

    // 3. Numerical ranges
    if (filterState.numericalRanges) {
      for (const [col, range] of Object.entries(filterState.numericalRanges)) {
        if (range && range.length === 2) {
          const [min, max] = range;
          let cellVal = row[col];
          if (typeof cellVal === "string") {
            cellVal = Number(cellVal.replace(/^[$-]/, "").replace(/,/g, ""));
          }
          if (typeof cellVal === "number" && !isNaN(cellVal)) {
            if (cellVal < min || cellVal > max) {
              return false;
            }
          }
        }
      }
    }

    return true;
  });

  if (filterState.sortColumn && filterState.sortColumn.trim() !== "") {
    const col = filterState.sortColumn;
    const dir = filterState.sortDirection === "desc" ? -1 : 1;
    return [...filtered].sort((a, b) => {
      let valA = a[col];
      let valB = b[col];
      if (valA === null || valA === undefined || valA === "") return 1;
      if (valB === null || valB === undefined || valB === "") return -1;
      if (typeof valA === "string") {
        const numA = Number(valA.replace(/^[$-]/, "").replace(/,/g, ""));
        if (!isNaN(numA)) valA = numA;
      }
      if (typeof valB === "string") {
        const numB = Number(valB.replace(/^[$-]/, "").replace(/,/g, ""));
        if (!isNaN(numB)) valB = numB;
      }
      if (typeof valA === "number" && typeof valB === "number") {
        return (valA - valB) * dir;
      }
      return String(valA).localeCompare(String(valB)) * dir;
    });
  }

  return filtered;
}

// Data Cleaning operations
export function cleanDropNullRows(rows: Record<string, any>[]): Record<string, any>[] {
  return rows.filter(r => {
    return Object.values(r).every(v => v !== null && v !== undefined && String(v).trim() !== "");
  });
}

export function cleanFillMean(rows: Record<string, any>[], targetCol?: string): Record<string, any>[] {
  const newRows = rows.map(r => ({ ...r }));
  const colsToProcess = targetCol ? [targetCol] : Object.keys(rows[0] || {});

  colsToProcess.forEach(col => {
    const nums = newRows
      .map(r => r[col])
      .filter(v => typeof v === "number" && !isNaN(v)) as number[];

    if (nums.length > 0) {
      const mean = Number((nums.reduce((a, b) => a + b, 0) / nums.length).toFixed(2));
      newRows.forEach(r => {
        if (r[col] === null || r[col] === undefined || String(r[col]).trim() === "") {
          r[col] = mean;
        }
      });
    }
  });

  return newRows;
}

export function cleanRemoveDuplicates(rows: Record<string, any>[]): Record<string, any>[] {
  const seen = new Set<string>();
  return rows.filter(r => {
    const key = JSON.stringify(r);
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

export function cleanTrimStrings(rows: Record<string, any>[]): Record<string, any>[] {
  return rows.map(r => {
    const newR: Record<string, any> = {};
    for (const [k, v] of Object.entries(r)) {
      if (typeof v === "string") {
        newR[k.trim()] = v.trim();
      } else {
        newR[k.trim()] = v;
      }
    }
    return newR;
  });
}
