import React, { createContext, useContext, useState, useEffect, useMemo } from "react";
import { Transition, TargetAndTransition } from "motion/react";

export type AnimationMode = "energetic" | "gentle" | "snappy" | "reduced";
export type AnimationSpeed = 0.75 | 1 | 1.5;

interface AnimationContextType {
  mode: AnimationMode;
  setMode: (mode: AnimationMode) => void;
  speed: AnimationSpeed;
  setSpeed: (speed: AnimationSpeed) => void;
  isReduced: boolean;
  springTransition: (stiffness?: number, damping?: number) => Transition;
  smoothTransition: (duration?: number) => Transition;
  cardHover: TargetAndTransition;
  buttonHover: TargetAndTransition;
  buttonTap: TargetAndTransition;
}

const AnimationContext = createContext<AnimationContextType | undefined>(undefined);

const STORAGE_KEY_MODE = "autodatadash_anim_mode";
const STORAGE_KEY_SPEED = "autodatadash_anim_speed";

export const AnimationProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [mode, setModeState] = useState<AnimationMode>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_MODE);
    if (saved === "energetic" || saved === "gentle" || saved === "snappy" || saved === "reduced") {
      return saved;
    }
    return "energetic";
  });

  const [speed, setSpeedState] = useState<AnimationSpeed>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_SPEED);
    if (saved === "0.75" || saved === "1" || saved === "1.5") {
      return parseFloat(saved) as AnimationSpeed;
    }
    return 1;
  });

  const setMode = (newMode: AnimationMode) => {
    setModeState(newMode);
    localStorage.setItem(STORAGE_KEY_MODE, newMode);
  };

  const setSpeed = (newSpeed: AnimationSpeed) => {
    setSpeedState(newSpeed);
    localStorage.setItem(STORAGE_KEY_SPEED, newSpeed.toString());
  };

  // Sync with user's system reduced motion preference if available
  useEffect(() => {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches && !localStorage.getItem(STORAGE_KEY_MODE)) {
      setModeState("reduced");
    }
  }, []);

  const isReduced = mode === "reduced";

  const speedFactor = useMemo(() => {
    if (speed === 0.75) return 1.35; // Slower duration
    if (speed === 1.5) return 0.7;   // Faster duration
    return 1.0;
  }, [speed]);

  const springTransition = useMemo(() => {
    return (stiffness = 380, damping = 26): Transition => {
      if (isReduced) return { duration: 0 };
      if (mode === "snappy") {
        return { type: "spring", stiffness: 500 * speed, damping: 30, mass: 0.8 };
      }
      if (mode === "gentle") {
        return { duration: 0.45 * speedFactor, ease: [0.22, 1, 0.36, 1] };
      }
      // Energetic spring (default)
      return { type: "spring", stiffness: stiffness * speed, damping: damping, mass: 1 };
    };
  }, [mode, speed, speedFactor, isReduced]);

  const smoothTransition = useMemo(() => {
    return (duration = 0.35): Transition => {
      if (isReduced) return { duration: 0 };
      if (mode === "snappy") {
        return { duration: 0.15 * speedFactor, ease: "easeOut" };
      }
      if (mode === "gentle") {
        return { duration: duration * 1.3 * speedFactor, ease: [0.16, 1, 0.3, 1] };
      }
      return { duration: duration * speedFactor, ease: [0.25, 0.1, 0.25, 1] };
    };
  }, [mode, speedFactor, isReduced]);

  const cardHover = useMemo((): TargetAndTransition => {
    if (isReduced) return {};
    if (mode === "gentle") {
      return {
        y: -3,
        scale: 1.01,
        boxShadow: "0 10px 25px -5px rgba(0, 0, 0, 0.2), 0 8px 10px -6px rgba(0, 0, 0, 0.2)",
        transition: { duration: 0.3 * speedFactor, ease: "easeOut" },
      };
    }
    if (mode === "snappy") {
      return {
        y: -2,
        scale: 1.008,
        transition: { duration: 0.12 * speedFactor },
      };
    }
    // Energetic
    return {
      y: -5,
      scale: 1.02,
      boxShadow: "0 14px 28px -6px rgba(0, 0, 0, 0.25), 0 10px 10px -5px rgba(0, 0, 0, 0.2)",
      transition: { type: "spring", stiffness: 420 * speed, damping: 22 },
    };
  }, [mode, speed, speedFactor, isReduced]);

  const buttonHover = useMemo((): TargetAndTransition => {
    if (isReduced) return {};
    if (mode === "gentle") {
      return { scale: 1.02, transition: { duration: 0.2 * speedFactor } };
    }
    if (mode === "snappy") {
      return { scale: 1.015, transition: { duration: 0.1 * speedFactor } };
    }
    return { scale: 1.04, transition: { type: "spring", stiffness: 450 * speed, damping: 18 } };
  }, [mode, speed, speedFactor, isReduced]);

  const buttonTap = useMemo((): TargetAndTransition => {
    if (isReduced) return {};
    return { scale: 0.96, transition: { duration: 0.08 } };
  }, [isReduced]);

  return (
    <AnimationContext.Provider
      value={{
        mode,
        setMode,
        speed,
        setSpeed,
        isReduced,
        springTransition,
        smoothTransition,
        cardHover,
        buttonHover,
        buttonTap,
      }}
    >
      {children}
    </AnimationContext.Provider>
  );
};

export const useAnimationConfig = () => {
  const context = useContext(AnimationContext);
  if (!context) {
    throw new Error("useAnimationConfig must be used within an AnimationProvider");
  }
  return context;
};
