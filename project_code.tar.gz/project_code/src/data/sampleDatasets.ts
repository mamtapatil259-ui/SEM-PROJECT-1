import { Dataset } from "../types";
import { analyzeDatasetSchema } from "../utils/dataEngine";

const ECOMMERCE_RAW = [
  { Date: "2025-01-05", OrderID: "ORD-1001", Category: "Electronics", Product: "Wireless Earbuds Pro", Region: "North America", Revenue: 149.99, Cost: 65.00, ProfitMargin: 56.6, UnitsSold: 3, CustomerRating: 4.8, ReturnRate: 2.1 },
  { Date: "2025-01-08", OrderID: "ORD-1002", Category: "Home & Kitchen", Product: "Smart Coffee Maker", Region: "Europe", Revenue: 220.00, Cost: 110.00, ProfitMargin: 50.0, UnitsSold: 2, CustomerRating: 4.5, ReturnRate: 3.5 },
  { Date: "2025-01-12", OrderID: "ORD-1003", Category: "Electronics", Product: "4K Ultra Monitor", Region: "North America", Revenue: 450.00, Cost: 280.00, ProfitMargin: 37.7, UnitsSold: 1, CustomerRating: 4.9, ReturnRate: 1.0 },
  { Date: "2025-01-15", OrderID: "ORD-1004", Category: "Apparel", Product: "Merino Wool Jacket", Region: "Asia Pacific", Revenue: 180.00, Cost: 72.00, ProfitMargin: 60.0, UnitsSold: 4, CustomerRating: 4.3, ReturnRate: 8.4 },
  { Date: "2025-01-18", OrderID: "ORD-1005", Category: "Electronics", Product: "Gaming Mechanical Keyboard", Region: "Europe", Revenue: 130.00, Cost: 55.00, ProfitMargin: 57.7, UnitsSold: 5, CustomerRating: 4.7, ReturnRate: 2.8 },
  { Date: "2025-01-22", OrderID: "ORD-1006", Category: "Fitness", Product: "Smart Gym Trackers", Region: "North America", Revenue: 299.99, Cost: 140.00, ProfitMargin: 53.3, UnitsSold: 6, CustomerRating: 4.6, ReturnRate: 4.2 },
  { Date: "2025-01-28", OrderID: "ORD-1007", Category: "Home & Kitchen", Product: "Robot Vacuum Cleaners", Region: "Asia Pacific", Revenue: 350.00, Cost: 190.00, ProfitMargin: 45.7, UnitsSold: 2, CustomerRating: 4.4, ReturnRate: 5.1 },
  { Date: "2025-02-03", OrderID: "ORD-1008", Category: "Apparel", Product: "Running Shoes Light", Region: "North America", Revenue: 120.00, Cost: 45.00, ProfitMargin: 62.5, UnitsSold: 10, CustomerRating: 4.8, ReturnRate: 6.0 },
  { Date: "2025-02-09", OrderID: "ORD-1009", Category: "Electronics", Product: "Wireless Earbuds Pro", Region: "Europe", Revenue: 299.98, Cost: 130.00, ProfitMargin: 56.6, UnitsSold: 6, CustomerRating: 4.8, ReturnRate: 2.1 },
  { Date: "2025-02-14", OrderID: "ORD-1010", Category: "Fitness", Product: "Yoga Mat Eco-Friendly", Region: "North America", Revenue: 89.97, Cost: 30.00, ProfitMargin: 66.6, UnitsSold: 9, CustomerRating: 4.9, ReturnRate: 1.5 },
  { Date: "2025-02-19", OrderID: "ORD-1011", Category: "Home & Kitchen", Product: "Air Purifier HEPA", Region: "Europe", Revenue: 400.00, Cost: 210.00, ProfitMargin: 47.5, UnitsSold: 4, CustomerRating: 4.7, ReturnRate: 3.0 },
  { Date: "2025-02-25", OrderID: "ORD-1012", Category: "Electronics", Product: "4K Ultra Monitor", Region: "Asia Pacific", Revenue: 900.00, Cost: 560.00, ProfitMargin: 37.7, UnitsSold: 2, CustomerRating: 4.9, ReturnRate: 1.0 },
  { Date: "2025-03-02", OrderID: "ORD-1013", Category: "Apparel", Product: "Waterproof Travel Backpack", Region: "Europe", Revenue: 240.00, Cost: 90.00, ProfitMargin: 62.5, UnitsSold: 6, CustomerRating: 4.6, ReturnRate: 4.5 },
  { Date: "2025-03-08", OrderID: "ORD-1014", Category: "Fitness", Product: "Adjustable Dumbbell Set", Region: "North America", Revenue: 550.00, Cost: 300.00, ProfitMargin: 45.4, UnitsSold: 5, CustomerRating: 4.9, ReturnRate: 2.0 },
  { Date: "2025-03-15", OrderID: "ORD-1015", Category: "Electronics", Product: "Gaming Mechanical Keyboard", Region: "North America", Revenue: 390.00, Cost: 165.00, ProfitMargin: 57.7, UnitsSold: 15, CustomerRating: 4.7, ReturnRate: 2.8 },
  { Date: "2025-03-21", OrderID: "ORD-1016", Category: "Home & Kitchen", Product: "Smart Coffee Maker", Region: "Asia Pacific", Revenue: 330.00, Cost: 165.00, ProfitMargin: 50.0, UnitsSold: 3, CustomerRating: 4.5, ReturnRate: 3.5 },
  { Date: "2025-03-28", OrderID: "ORD-1017", Category: "Electronics", Product: "Wireless Earbuds Pro", Region: "North America", Revenue: 749.95, Cost: 325.00, ProfitMargin: 56.6, UnitsSold: 15, CustomerRating: 4.8, ReturnRate: 2.1 },
  { Date: "2025-04-04", OrderID: "ORD-1018", Category: "Apparel", Product: "Running Shoes Light", Region: "Europe", Revenue: 360.00, Cost: 135.00, ProfitMargin: 62.5, UnitsSold: 30, CustomerRating: 4.8, ReturnRate: 6.0 },
  { Date: "2025-04-12", OrderID: "ORD-1019", Category: "Fitness", Product: "Smart Gym Trackers", Region: "Asia Pacific", Revenue: 599.98, Cost: 280.00, ProfitMargin: 53.3, UnitsSold: 12, CustomerRating: 4.6, ReturnRate: 4.2 },
  { Date: "2025-04-20", OrderID: "ORD-1020", Category: "Electronics", Product: "4K Ultra Monitor", Region: "North America", Revenue: 1350.00, Cost: 840.00, ProfitMargin: 37.7, UnitsSold: 3, CustomerRating: 4.9, ReturnRate: 1.0 }
];

const SAAS_GROWTH_RAW = [
  { Month: "2024-07", Channel: "Organic Search", NewSignups: 1240, ActiveUsers: 8500, ChurnRate: 3.2, CAC: 45, LTV: 850, ConversionRate: 6.8 },
  { Month: "2024-07", Channel: "Paid Ads", NewSignups: 2100, ActiveUsers: 9200, ChurnRate: 4.5, CAC: 120, LTV: 780, ConversionRate: 4.2 },
  { Month: "2024-07", Channel: "Referral Program", NewSignups: 650, ActiveUsers: 5100, ChurnRate: 1.8, CAC: 25, LTV: 1100, ConversionRate: 11.5 },
  { Month: "2024-08", Channel: "Organic Search", NewSignups: 1380, ActiveUsers: 9100, ChurnRate: 3.0, CAC: 43, LTV: 870, ConversionRate: 7.1 },
  { Month: "2024-08", Channel: "Paid Ads", NewSignups: 2350, ActiveUsers: 10400, ChurnRate: 4.2, CAC: 115, LTV: 800, ConversionRate: 4.5 },
  { Month: "2024-08", Channel: "Referral Program", NewSignups: 790, ActiveUsers: 5700, ChurnRate: 1.6, CAC: 24, LTV: 1150, ConversionRate: 12.0 },
  { Month: "2024-09", Channel: "Organic Search", NewSignups: 1520, ActiveUsers: 9900, ChurnRate: 2.8, CAC: 42, LTV: 890, ConversionRate: 7.4 },
  { Month: "2024-09", Channel: "Paid Ads", NewSignups: 2600, ActiveUsers: 11800, ChurnRate: 3.9, CAC: 110, LTV: 820, ConversionRate: 4.8 },
  { Month: "2024-09", Channel: "Referral Program", NewSignups: 920, ActiveUsers: 6400, ChurnRate: 1.5, CAC: 22, LTV: 1200, ConversionRate: 12.8 },
  { Month: "2024-10", Channel: "Organic Search", NewSignups: 1710, ActiveUsers: 10800, ChurnRate: 2.6, CAC: 40, LTV: 920, ConversionRate: 7.8 },
  { Month: "2024-10", Channel: "Paid Ads", NewSignups: 2900, ActiveUsers: 13200, ChurnRate: 3.7, CAC: 108, LTV: 840, ConversionRate: 5.1 },
  { Month: "2024-10", Channel: "Referral Program", NewSignups: 1100, ActiveUsers: 7200, ChurnRate: 1.4, CAC: 20, LTV: 1250, ConversionRate: 13.5 },
  { Month: "2024-11", Channel: "Organic Search", NewSignups: 1950, ActiveUsers: 11900, ChurnRate: 2.4, CAC: 39, LTV: 950, ConversionRate: 8.2 },
  { Month: "2024-11", Channel: "Paid Ads", NewSignups: 3200, ActiveUsers: 14900, ChurnRate: 3.5, CAC: 105, LTV: 870, ConversionRate: 5.4 },
  { Month: "2024-11", Channel: "Referral Program", NewSignups: 1350, ActiveUsers: 8100, ChurnRate: 1.2, CAC: 18, LTV: 1320, ConversionRate: 14.2 },
  { Month: "2024-12", Channel: "Organic Search", NewSignups: 2200, ActiveUsers: 13100, ChurnRate: 2.2, CAC: 38, LTV: 980, ConversionRate: 8.6 },
  { Month: "2024-12", Channel: "Paid Ads", NewSignups: 3500, ActiveUsers: 16800, ChurnRate: 3.3, CAC: 102, LTV: 900, ConversionRate: 5.8 },
  { Month: "2024-12", Channel: "Referral Program", NewSignups: 1600, ActiveUsers: 9200, ChurnRate: 1.1, CAC: 16, LTV: 1400, ConversionRate: 15.0 }
];

const HEALTHCARE_RAW = [
  { Department: "Cardiology", PatientsAdmitted: 420, AvgStayDays: 5.4, AvgCostUSD: 14500, PatientSatisfaction: 91, RecoveryRate: 94.2, StaffCount: 38 },
  { Department: "Neurology", PatientsAdmitted: 280, AvgStayDays: 6.8, AvgCostUSD: 18200, PatientSatisfaction: 88, RecoveryRate: 89.5, StaffCount: 30 },
  { Department: "Orthopedics", PatientsAdmitted: 560, AvgStayDays: 3.9, AvgCostUSD: 11200, PatientSatisfaction: 94, RecoveryRate: 97.1, StaffCount: 45 },
  { Department: "Pediatrics", PatientsAdmitted: 690, AvgStayDays: 2.5, AvgCostUSD: 6800, PatientSatisfaction: 96, RecoveryRate: 98.8, StaffCount: 52 },
  { Department: "Oncology", PatientsAdmitted: 310, AvgStayDays: 8.2, AvgCostUSD: 24500, PatientSatisfaction: 89, RecoveryRate: 85.0, StaffCount: 40 },
  { Department: "Emergency", PatientsAdmitted: 1450, AvgStayDays: 1.2, AvgCostUSD: 3900, PatientSatisfaction: 83, RecoveryRate: 92.4, StaffCount: 75 },
  { Department: "General Surgery", PatientsAdmitted: 490, AvgStayDays: 4.5, AvgCostUSD: 13800, PatientSatisfaction: 90, RecoveryRate: 95.5, StaffCount: 42 },
  { Department: "Maternity & OBGYN", PatientsAdmitted: 620, AvgStayDays: 2.8, AvgCostUSD: 7500, PatientSatisfaction: 95, RecoveryRate: 99.2, StaffCount: 48 },
  { Department: "Pulmonology", PatientsAdmitted: 350, AvgStayDays: 5.1, AvgCostUSD: 12900, PatientSatisfaction: 87, RecoveryRate: 91.0, StaffCount: 28 },
  { Department: "Gastroenterology", PatientsAdmitted: 390, AvgStayDays: 3.4, AvgCostUSD: 9400, PatientSatisfaction: 92, RecoveryRate: 96.0, StaffCount: 32 }
];

const CLIMATE_RAW = [
  { City: "Tokyo", Country: "Japan", AvgTempC: 16.2, RainfallMM: 1528, SunshineHours: 1876, HumidityPct: 65, AirQualityIndex: 42, CO2EmissionsMt: 62.4 },
  { City: "London", Country: "UK", AvgTempC: 11.5, RainfallMM: 615, SunshineHours: 1633, HumidityPct: 78, AirQualityIndex: 48, CO2EmissionsMt: 31.2 },
  { City: "New York", Country: "USA", AvgTempC: 13.1, RainfallMM: 1260, SunshineHours: 2680, HumidityPct: 63, AirQualityIndex: 55, CO2EmissionsMt: 54.8 },
  { City: "Sydney", Country: "Australia", AvgTempC: 18.8, RainfallMM: 1213, SunshineHours: 2592, HumidityPct: 64, AirQualityIndex: 28, CO2EmissionsMt: 38.1 },
  { City: "São Paulo", Country: "Brazil", AvgTempC: 20.4, RainfallMM: 1441, SunshineHours: 2003, HumidityPct: 76, AirQualityIndex: 68, CO2EmissionsMt: 49.3 },
  { City: "Singapore", Country: "Singapore", AvgTempC: 27.8, RainfallMM: 2340, SunshineHours: 2022, HumidityPct: 83, AirQualityIndex: 35, CO2EmissionsMt: 51.0 },
  { City: "Cairo", Country: "Egypt", AvgTempC: 22.1, RainfallMM: 24, SunshineHours: 3541, HumidityPct: 52, AirQualityIndex: 94, CO2EmissionsMt: 44.5 },
  { City: "Stockholm", Country: "Sweden", AvgTempC: 7.9, RainfallMM: 539, SunshineHours: 1821, HumidityPct: 74, AirQualityIndex: 18, CO2EmissionsMt: 14.2 },
  { City: "Vancouver", Country: "Canada", AvgTempC: 11.0, RainfallMM: 1460, SunshineHours: 1938, HumidityPct: 72, AirQualityIndex: 22, CO2EmissionsMt: 19.8 },
  { City: "Dubai", Country: "UAE", AvgTempC: 28.5, RainfallMM: 68, SunshineHours: 3568, HumidityPct: 58, AirQualityIndex: 88, CO2EmissionsMt: 72.1 }
];

const FINANCE_RAW = [
  { Ticker: "NVDA", Sector: "Technology", PriceUSD: 128.50, DailyChangePct: 4.2, MarketCapBillion: 3150, PE_Ratio: 48.5, DividendYieldPct: 0.03, Beta: 1.68 },
  { Ticker: "AAPL", Sector: "Technology", PriceUSD: 225.40, DailyChangePct: 1.1, MarketCapBillion: 3420, PE_Ratio: 33.2, DividendYieldPct: 0.45, Beta: 1.12 },
  { Ticker: "MSFT", Sector: "Technology", PriceUSD: 445.80, DailyChangePct: 1.8, MarketCapBillion: 3310, PE_Ratio: 36.4, DividendYieldPct: 0.68, Beta: 0.98 },
  { Ticker: "GOOGL", Sector: "Communication", PriceUSD: 182.20, DailyChangePct: 2.3, MarketCapBillion: 2280, PE_Ratio: 25.1, DividendYieldPct: 0.44, Beta: 1.05 },
  { Ticker: "AMZN", Sector: "Consumer", PriceUSD: 195.60, DailyChangePct: 1.5, MarketCapBillion: 2040, PE_Ratio: 41.0, DividendYieldPct: 0.00, Beta: 1.28 },
  { Ticker: "JPM", Sector: "Financial", PriceUSD: 215.30, DailyChangePct: -0.4, MarketCapBillion: 615, PE_Ratio: 12.8, DividendYieldPct: 2.15, Beta: 1.10 },
  { Ticker: "V", Sector: "Financial", PriceUSD: 282.90, DailyChangePct: 0.6, MarketCapBillion: 578, PE_Ratio: 30.5, DividendYieldPct: 0.74, Beta: 0.94 },
  { Ticker: "JNJ", Sector: "Healthcare", PriceUSD: 154.20, DailyChangePct: -0.2, MarketCapBillion: 370, PE_Ratio: 16.4, DividendYieldPct: 3.20, Beta: 0.55 },
  { Ticker: "PG", Sector: "Consumer", PriceUSD: 168.40, DailyChangePct: 0.3, MarketCapBillion: 395, PE_Ratio: 26.8, DividendYieldPct: 2.40, Beta: 0.48 },
  { Ticker: "XOM", Sector: "Energy", PriceUSD: 118.90, DailyChangePct: -1.2, MarketCapBillion: 472, PE_Ratio: 13.5, DividendYieldPct: 3.10, Beta: 0.85 }
];

const HR_ANALYTICS_RAW = [
  { Department: "Engineering", Headcount: 240, AvgSalaryUSD: 145000, RemotePct: 78, AvgTenureYears: 3.8, TrainingHoursPerYear: 52, EngagementScore: 84, TurnoverRatePct: 8.5 },
  { Department: "Product", Headcount: 65, AvgSalaryUSD: 138000, RemotePct: 82, AvgTenureYears: 4.2, TrainingHoursPerYear: 48, EngagementScore: 88, TurnoverRatePct: 6.2 },
  { Department: "Sales", Headcount: 180, AvgSalaryUSD: 112000, RemotePct: 65, AvgTenureYears: 2.5, TrainingHoursPerYear: 64, EngagementScore: 81, TurnoverRatePct: 16.4 },
  { Department: "Marketing", Headcount: 85, AvgSalaryUSD: 98000, RemotePct: 75, AvgTenureYears: 3.1, TrainingHoursPerYear: 45, EngagementScore: 83, TurnoverRatePct: 11.2 },
  { Department: "Customer Support", Headcount: 150, AvgSalaryUSD: 68000, RemotePct: 90, AvgTenureYears: 2.1, TrainingHoursPerYear: 72, EngagementScore: 79, TurnoverRatePct: 19.5 },
  { Department: "Finance & Legal", Headcount: 45, AvgSalaryUSD: 125000, RemotePct: 60, AvgTenureYears: 5.4, TrainingHoursPerYear: 38, EngagementScore: 86, TurnoverRatePct: 5.1 },
  { Department: "Human Resources", Headcount: 35, AvgSalaryUSD: 88000, RemotePct: 70, AvgTenureYears: 4.6, TrainingHoursPerYear: 60, EngagementScore: 89, TurnoverRatePct: 7.0 },
  { Department: "Design & UX", Headcount: 40, AvgSalaryUSD: 118000, RemotePct: 85, AvgTenureYears: 3.5, TrainingHoursPerYear: 50, EngagementScore: 87, TurnoverRatePct: 9.1 }
];

export const SAMPLE_DATASETS: { id: string; name: string; category: string; description: string; rawData: any[] }[] = [
  {
    id: "ecommerce-sales",
    name: "E-Commerce Revenue & Orders",
    category: "Retail & Sales",
    description: "Multi-regional online retail dataset tracking revenues, profit margins, return rates, and customer ratings across product categories.",
    rawData: ECOMMERCE_RAW
  },
  {
    id: "saas-growth",
    name: "SaaS Marketing & User Growth",
    category: "SaaS & Tech",
    description: "Monthly customer acquisition channels, active users, CAC, LTV, and churn metrics for a fast-growing B2B SaaS software platform.",
    rawData: SAAS_GROWTH_RAW
  },
  {
    id: "healthcare-vitals",
    name: "Healthcare Hospital Department Metrics",
    category: "Healthcare",
    description: "Departmental patient admissions, length of stay, average treatment costs, recovery rates, and patient satisfaction survey scores.",
    rawData: HEALTHCARE_RAW
  },
  {
    id: "climate-weather",
    name: "Global Climate & Air Quality Index",
    category: "Environment",
    description: "Comparative weather statistics for top global cities including temperatures, rainfall, sunshine hours, humidity, and CO2 emissions.",
    rawData: CLIMATE_RAW
  },
  {
    id: "finance-stocks",
    name: "Stock Market Performance Top Tickers",
    category: "Finance",
    description: "Key financial metrics for leading equities including stock prices, market cap, P/E ratios, dividend yields, and market volatility (Beta).",
    rawData: FINANCE_RAW
  },
  {
    id: "hr-analytics",
    name: "HR Workforce & Retention Tracker",
    category: "Human Resources",
    description: "Departmental headcount, average salaries, remote working percentage, employee engagement scores, and turnover rates.",
    rawData: HR_ANALYTICS_RAW
  }
];

export function getSampleDataset(id: string): Dataset | null {
  const sample = SAMPLE_DATASETS.find(d => d.id === id);
  if (!sample) return null;
  const columns = analyzeDatasetSchema(sample.rawData);
  return {
    id: sample.id,
    name: sample.name,
    description: sample.description,
    rows: sample.rawData,
    columns,
    uploadedAt: new Date().toISOString()
  };
}
