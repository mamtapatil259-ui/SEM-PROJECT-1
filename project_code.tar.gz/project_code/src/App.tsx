import React, { useState, useEffect, useMemo } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Navbar, AppTab } from "./components/Navbar";
import { DatasetIngestionModal } from "./components/DatasetIngestionModal";
import { ExcelUploadSection } from "./components/ExcelUploadSection";
import { FilterBar } from "./components/FilterBar";
import { DashboardCanvasView } from "./components/DashboardCanvasView";
import { DataExplorerView } from "./components/DataExplorerView";
import { ChartBuilderModal } from "./components/ChartBuilderModal";
import { KpiBuilderModal } from "./components/KpiBuilderModal";
import { DataInsightsChat } from "./components/DataInsightsChat";
import { ExportReportModal } from "./components/ExportReportModal";
import { BrandLogo } from "./components/BrandLogo";
import { useAnimationConfig } from "./context/AnimationContext";
import { Dataset, KpiConfig, ChartConfig, FilterState, ColorTheme } from "./types";
import { getSampleDataset } from "./data/sampleDatasets";
import { filterDataset, analyzeDatasetSchema } from "./utils/dataEngine";
import { Sparkles, BarChart3, Database, Bot, Table } from "lucide-react";

export default function App() {
  const { springTransition, isReduced } = useAnimationConfig();
  // Initial dataset set to null so users always see the animated Welcome to Auto DataDash entrance
  const [currentDataset, setCurrentDataset] = useState<Dataset | null>(null);

  const [activeTab, setActiveTab] = useState<AppTab>("import_raw");
  const [showRawData, setShowRawData] = useState(true);
  const [colorTheme, setColorTheme] = useState<ColorTheme>("indigo");

  // Dashboard configuration state
  const [kpis, setKpis] = useState<KpiConfig[]>([]);
  const [charts, setCharts] = useState<ChartConfig[]>([]);
  const [executiveSummary, setExecutiveSummary] = useState<string | undefined>();
  const [keyInsights, setKeyInsights] = useState<string[] | undefined>();

  // Filter state
  const [filterState, setFilterState] = useState<FilterState>({
    searchQuery: "",
    categoricalFilters: {},
    numericalRanges: {},
  });

  // Modals & Drawers
  const [isIngestionOpen, setIsIngestionOpen] = useState(false);
  const [isChartModalOpen, setIsChartModalOpen] = useState(false);
  const [editingChart, setEditingChart] = useState<ChartConfig | null>(null);
  const [isKpiModalOpen, setIsKpiModalOpen] = useState(false);
  const [editingKpi, setEditingKpi] = useState<KpiConfig | null>(null);
  const [isExportModalOpen, setIsExportModalOpen] = useState(false);
  const [isInsightsChatOpen, setIsInsightsChatOpen] = useState(false);
  const [isAutoGenerating, setIsAutoGenerating] = useState(false);
  const [isCleaned, setIsCleaned] = useState(false);

  // Load default layout when dataset changes
  useEffect(() => {
    if (!currentDataset) return;
    setFilterState({ searchQuery: "", categoricalFilters: {}, numericalRanges: {} });
    setIsCleaned(false);

    // Try loading saved preset from localStorage
    const savedKey = `autodatadash_${currentDataset.id}`;
    const legacyKey = `datapulse_dash_${currentDataset.id}`;
    const savedJson = localStorage.getItem(savedKey) || localStorage.getItem(legacyKey);
    if (savedJson) {
      try {
        const parsed = JSON.parse(savedJson);
        if (parsed.kpis && parsed.charts) {
          setKpis(parsed.kpis);
          setCharts(parsed.charts);
          setExecutiveSummary(parsed.executiveSummary);
          setKeyInsights(parsed.keyInsights);
          return;
        }
      } catch (e) {
        console.log("Using default dashboard layout preset.");
      }
    }

    // Set default jaw-dropping layout for known samples
    if (currentDataset.id === "ecommerce-sales") {
      setExecutiveSummary(
        "Online retail sales show strong revenue velocity in North America and Europe, driven heavily by premium Electronics and Apparel items. Profit margins average 55.4% across orders with minimal return rates."
      );
      setKeyInsights([
        "Wireless Earbuds Pro and 4K Ultra Monitors generate over 60% of total revenue volume.",
        "North America leads in order volume, while Asia Pacific achieves the highest average units sold per transaction.",
        "Customer satisfaction remains exceptional at 4.7/5.0 average rating across all regions.",
      ]);
      setKpis([
        { id: "kpi-1", title: "Total Revenue USD", column: "Revenue", aggregation: "SUM", format: "currency", trendLabel: "+18.4% MoM", trendDirection: "up" },
        { id: "kpi-2", title: "Avg Profit Margin", column: "ProfitMargin", aggregation: "AVERAGE", format: "percentage", trendLabel: "Target >50%", trendDirection: "up" },
        { id: "kpi-3", title: "Total Units Sold", column: "UnitsSold", aggregation: "SUM", format: "number", trendLabel: "+240 units", trendDirection: "up" },
        { id: "kpi-4", title: "Avg Customer Rating", column: "CustomerRating", aggregation: "AVERAGE", format: "standard", suffix: "/5.0", trendLabel: "Excellent", trendDirection: "up" },
      ]);
      setCharts([
        { id: "c-1", title: "Total Revenue & Units (Composed Combo)", type: "composed", xAxisColumn: "Category", yAxisColumn: "Revenue", aggregation: "SUM", colorTheme: "indigo", colSpan: 2, showBrush: true, showReferenceLine: true },
        { id: "c-2", title: "Profit Margin % by Geographic Region", type: "radialBar", xAxisColumn: "Region", yAxisColumn: "ProfitMargin", aggregation: "AVERAGE", colorTheme: "emerald", colSpan: 1 },
        { id: "c-3", title: "Sales Revenue Treemap Allocation", type: "treemap", xAxisColumn: "Category", yAxisColumn: "Revenue", aggregation: "SUM", colorTheme: "purple", colSpan: 1 },
        { id: "c-4", title: "Revenue Trend Over Time", type: "area", xAxisColumn: "Date", yAxisColumn: "Revenue", aggregation: "SUM", colorTheme: "cyan", colSpan: 1, showBrush: true },
        { id: "c-5", title: "Sales Revenue Share by Region", type: "pie", xAxisColumn: "Region", yAxisColumn: "Revenue", aggregation: "SUM", colorTheme: "amber", colSpan: 1 },
        { id: "c-6", title: "Correlation: Price Revenue vs Units Sold", type: "scatter", xAxisColumn: "Revenue", yAxisColumn: "UnitsSold", aggregation: "SUM", colorTheme: "rose", colSpan: 2 },
      ]);
    } else if (currentDataset.id === "saas-growth") {
      setExecutiveSummary(
        "B2B SaaS customer acquisition has accelerated steadily from July through December. Paid Ads drive total volume while Referral Programs achieve the lowest CAC and highest user lifetime value."
      );
      setKeyInsights([
        "Referral Program conversion rate reached an impressive 15.0% in December.",
        "Paid Ads CAC decreased from $120 to $102 while organic search volume doubled.",
        "Monthly churn rate improved across all acquisition cohorts, averaging 2.6%.",
      ]);
      setKpis([
        { id: "k1", title: "Total New Signups", column: "NewSignups", aggregation: "SUM", format: "number", trendLabel: "+35% Q4 growth", trendDirection: "up" },
        { id: "k2", title: "Avg Monthly Active Users", column: "ActiveUsers", aggregation: "AVERAGE", format: "number", trendLabel: "10,230 MAU", trendDirection: "up" },
        { id: "k3", title: "Avg Customer Acquisition Cost", column: "CAC", aggregation: "AVERAGE", format: "currency", trendLabel: "-14% improvement", trendDirection: "up" },
        { id: "k4", title: "Avg Churn Rate", column: "ChurnRate", aggregation: "AVERAGE", format: "percentage", trendLabel: "Below industry avg", trendDirection: "up" },
      ]);
      setCharts([
        { id: "sc1", title: "New Signups & Growth (Combo Graphic)", type: "composed", xAxisColumn: "Channel", yAxisColumn: "NewSignups", aggregation: "SUM", colorTheme: "indigo", colSpan: 2, showReferenceLine: true },
        { id: "sc2", title: "Monthly Active Users Growth Trend", type: "area", xAxisColumn: "Month", yAxisColumn: "ActiveUsers", aggregation: "SUM", groupByColumn: "Channel", colorTheme: "emerald", colSpan: 2, showBrush: true },
        { id: "sc3", title: "Customer Lifetime Value (LTV) Radial Breakdown", type: "radialBar", xAxisColumn: "Channel", yAxisColumn: "LTV", aggregation: "AVERAGE", colorTheme: "amber", colSpan: 1 },
        { id: "sc4", title: "Channel Signups Treemap Density", type: "treemap", xAxisColumn: "Channel", yAxisColumn: "NewSignups", aggregation: "SUM", colorTheme: "purple", colSpan: 1 },
      ]);
    } else {
      // Default fallback for uploaded datasets
      const numCols = currentDataset.columns.filter((c) => c.type === "number");
      const stringCols = currentDataset.columns.filter((c) => c.type === "string" || c.type === "date");
      const defaultX = stringCols[0]?.name || currentDataset.columns[0]?.name || "";
      const defaultY1 = numCols[0]?.name || "";
      const defaultY2 = numCols[1]?.name || defaultY1;

      setKpis(
        numCols.slice(0, 4).map((c, idx) => ({
          id: `kpi-auto-${idx}`,
          title: `Total ${c.name}`,
          column: c.name,
          aggregation: "SUM",
          format: "number",
        }))
      );

      if (defaultX && defaultY1) {
        setCharts([
          { id: "auto-c1", title: `SUM of ${defaultY1} by ${defaultX}`, type: "bar", xAxisColumn: defaultX, yAxisColumn: defaultY1, aggregation: "SUM", colorTheme: "indigo", colSpan: 1 },
          { id: "auto-c2", title: `AVERAGE of ${defaultY2 || defaultY1} by ${defaultX}`, type: "line", xAxisColumn: defaultX, yAxisColumn: defaultY2 || defaultY1, aggregation: "AVERAGE", colorTheme: "emerald", colSpan: 1 },
        ]);
      }
    }
  }, [currentDataset]);

  // Save changes to localStorage
  useEffect(() => {
    if (!currentDataset) return;
    const key = `autodatadash_${currentDataset.id}`;
    localStorage.setItem(
      key,
      JSON.stringify({
        kpis,
        charts,
        executiveSummary,
        keyInsights,
      })
    );
  }, [kpis, charts, executiveSummary, keyInsights, currentDataset]);

  // Compute filtered dataset rows
  const filteredRows = useMemo(() => {
    if (!currentDataset) return [];
    return filterDataset(currentDataset.rows, filterState, currentDataset.columns);
  }, [currentDataset, filterState]);

  // Handle Auto-Generate Dashboard
  const handleAutoGenerateDashboard = async () => {
    if (!currentDataset || isAutoGenerating) return;
    setIsAutoGenerating(true);

    try {
      const response = await fetch("/api/analytics/generate-dashboard", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          datasetName: currentDataset.name,
          columns: currentDataset.columns.map((c) => ({ name: c.name, type: c.type, nullCount: c.nullCount, uniqueCount: c.uniqueCount })),
          sampleRows: currentDataset.rows.slice(0, 15),
          rowCount: currentDataset.rows.length,
        }),
      });

      const data = await response.json();
      if (!response.ok || !data.success || !data.dashboardConfig) {
        throw new Error(data.error || "Failed to generate dashboard");
      }

      const cfg = data.dashboardConfig;
      if (cfg.kpis && Array.isArray(cfg.kpis)) {
        setKpis(cfg.kpis.map((k: any, idx: number) => ({ ...k, id: k.id || `kpi-auto-${idx}` })));
      }
      if (cfg.charts && Array.isArray(cfg.charts)) {
        setCharts(cfg.charts.map((c: any, idx: number) => ({ ...c, id: c.id || `chart-auto-${idx}` })));
      }
      setExecutiveSummary(cfg.executiveSummary);
      setKeyInsights(cfg.keyInsights);
      setActiveTab("kpi_scorecard");
    } catch (err: any) {
      console.log("[DataPulse Engine] Activating instant algorithmic dashboard profile.");
      if (currentDataset) {
        const numCols = currentDataset.columns.filter((c) => c.type === "number" || c.type === "currency" || c.type === "percentage");
        const catCols = currentDataset.columns.filter((c) => c.type === "string" || c.type === "date" || c.type === "boolean");
        const xCol = catCols[0]?.name || currentDataset.columns[0]?.name || "category";
        const yCol = numCols[0]?.name || currentDataset.columns[1]?.name || "value";

        setKpis([
          {
            id: "kpi-fb-1",
            title: `Total ${yCol}`,
            column: yCol,
            aggregation: "SUM",
            format: numCols[0]?.type === "currency" ? "currency" : "number",
            description: `Automated tracking for ${yCol}`,
            trendLabel: "+10% vs baseline",
            trendDirection: "up",
          },
        ]);
        setCharts([
          {
            id: "chart-fb-1",
            title: `${yCol} by ${xCol}`,
            description: `Distribution of ${yCol} across ${xCol}`,
            type: "bar",
            xAxisColumn: xCol,
            yAxisColumn: yCol,
            aggregation: "SUM",
            colSpan: 2,
            colorTheme: "indigo",
          },
        ]);
        setExecutiveSummary(`Analytical profile generated for "${currentDataset.name}". Dataset contains ${currentDataset.rows.length} records across ${currentDataset.columns.length} dimensions.`);
        setKeyInsights([
          `Primary distribution across ${xCol} indicates structured variance.`,
          `Core volume metric (${yCol}) is ready for interactive filtering and slice-and-dice exploration.`,
        ]);
        setActiveTab("kpi_scorecard");
      }
    } finally {
      setIsAutoGenerating(false);
    }
  };

  // Chart handlers
  const handleSaveChart = (chart: ChartConfig) => {
    setCharts((prev) => {
      const exists = prev.some((c) => c.id === chart.id);
      if (exists) {
        return prev.map((c) => (c.id === chart.id ? chart : c));
      }
      return [chart, ...prev];
    });
  };

  const handleDeleteChart = (id: string) => {
    setCharts((prev) => prev.filter((c) => c.id !== id));
  };

  const handleToggleChartSpan = (id: string) => {
    setCharts((prev) =>
      prev.map((c) => {
        if (c.id === id) {
          return { ...c, colSpan: c.colSpan === 1 ? 2 : 1 };
        }
        return c;
      })
    );
  };

  const handleUpdateChartColor = (id: string, theme: ColorTheme, customHex?: string) => {
    setCharts((prev) =>
      prev.map((c) => (c.id === id ? { ...c, colorTheme: theme, customColorHex: customHex } : c))
    );
  };

  const handleSetColorTheme = (theme: ColorTheme) => {
    setColorTheme(theme);
    setCharts((prev) =>
      prev.map((c) => ({
        ...c,
        colorTheme: theme,
        customColorHex: undefined,
      }))
    );
  };

  // KPI handlers
  const handleSaveKpi = (kpi: KpiConfig) => {
    setKpis((prev) => {
      const exists = prev.some((k) => k.id === kpi.id);
      if (exists) {
        return prev.map((k) => (k.id === kpi.id ? kpi : k));
      }
      return [...prev, kpi];
    });
  };

  const handleDeleteKpi = (id: string) => {
    setKpis((prev) => prev.filter((k) => k.id !== id));
  };

  // Data hygiene update rows
  const handleUpdateDatasetRows = (newRows: Record<string, any>[], actionNote: string) => {
    if (!currentDataset) return;
    const columns = analyzeDatasetSchema(newRows);
    setCurrentDataset({
      ...currentDataset,
      rows: newRows,
      columns,
    });
    setIsCleaned(true);
  };

  const handleResetToOriginal = () => {
    if (!currentDataset) return;
    const orig = getSampleDataset(currentDataset.id);
    if (orig) {
      setCurrentDataset(orig);
      setIsCleaned(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 text-slate-100 flex flex-col font-sans antialiased selection:bg-indigo-500 selection:text-white relative overflow-x-hidden">
      {/* Aesthetic Background Theme Layer */}
      <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden">
        <div className="absolute -top-[10%] left-[15%] w-[600px] h-[600px] rounded-full bg-gradient-to-tr from-indigo-500/10 via-purple-500/10 to-pink-500/5 blur-3xl animate-pulse" style={{ animationDuration: "8s" }} />
        <div className="absolute top-[35%] -right-[10%] w-[650px] h-[650px] rounded-full bg-gradient-to-br from-blue-500/10 via-teal-500/10 to-emerald-500/10 blur-3xl" />
        <div className="absolute -bottom-[15%] left-[25%] w-[700px] h-[700px] rounded-full bg-gradient-to-tr from-violet-500/10 via-indigo-500/10 to-slate-800/20 blur-3xl" />
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#ffffff05_1px,transparent_1px),linear-gradient(to_bottom,#ffffff05_1px,transparent_1px)] bg-[size:28px_28px]" />
      </div>

      {/* Top Navbar */}
      <Navbar
        currentDataset={currentDataset}
        onOpenIngestion={() => setIsIngestionOpen(true)}
        onAutoGenerate={handleAutoGenerateDashboard}
        isAutoGenerating={isAutoGenerating}
        onOpenExport={() => setIsExportModalOpen(true)}
        colorTheme={colorTheme}
        setColorTheme={handleSetColorTheme}
      />

      {/* Main Body */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 pt-6 relative z-10">
        {!currentDataset ? (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, ease: "easeOut" }}
            className="space-y-8 my-8 relative"
          >
            {/* Minimalist Welcome Header */}
            <div className="py-4 text-center flex flex-col items-center justify-center max-w-2xl mx-auto">
              <motion.div
                initial={{ scale: 0, rotate: -15 }}
                animate={{ scale: 1, rotate: 0 }}
                transition={{ duration: 0.6, delay: 0.1, type: "spring", stiffness: 140 }}
                className="mb-3"
              >
                <BrandLogo size="lg" />
              </motion.div>

              <motion.h2
                initial={{ y: 15, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ duration: 0.5, delay: 0.2 }}
                className="text-3xl sm:text-4xl font-black text-slate-100 tracking-tight flex flex-wrap items-center justify-center gap-2"
              >
                <span>Welcome to</span>
                <span className="bg-gradient-to-r from-indigo-400 via-cyan-400 to-emerald-400 bg-clip-text text-transparent drop-shadow-sm">
                  Auto DataDash
                </span>
              </motion.h2>
            </div>

            <motion.div
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="max-w-4xl mx-auto"
            >
              <ExcelUploadSection
                onSelectDataset={(ds) => {
                  setCurrentDataset(ds);
                  setActiveTab("import_raw");
                }}
                onAutoGenerate={handleAutoGenerateDashboard}
                isAutoGenerating={isAutoGenerating}
                onOpenSampleLibrary={() => setIsIngestionOpen(true)}
              />
            </motion.div>
          </motion.div>
        ) : (
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={isReduced ? { opacity: 0 } : { opacity: 0, y: 16, scale: 0.99 }}
              animate={isReduced ? { opacity: 1 } : { opacity: 1, y: 0, scale: 1 }}
              exit={isReduced ? { opacity: 0 } : { opacity: 0, y: -12, scale: 0.99 }}
              transition={isReduced ? { duration: 0 } : springTransition(380, 28)}
              className="space-y-6"
            >
              {/* Page 1: File Import & Raw Dataset */}
              {activeTab === "import_raw" && (
                <div className="space-y-6">
                <div style={{ backgroundColor: "#0e2346" }} className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-md">
                  <div style={{ backgroundColor: "#06062c", minHeight: "54px" }} className="flex items-center gap-3 mb-4 p-2 rounded-xl">
                    <div className="w-10 h-10 rounded-xl bg-indigo-950/60 text-indigo-400 flex items-center justify-center border border-indigo-800/50 font-bold shrink-0">
                      1
                    </div>
                    <div>
                      <h2 style={{ color: "#ffffff" }} className="text-xl font-extrabold text-slate-100">File Import & Raw Dataset Studio</h2>
                      <p style={{ color: "#d1cece" }} className="text-xs text-slate-400">Upload spreadsheets and choose sample data libraries</p>
                    </div>
                  </div>
                  <div style={{ borderColor: "#000000" }}>
                    <ExcelUploadSection
                      onSelectDataset={(ds) => {
                        setCurrentDataset(ds);
                        setActiveTab("import_raw");
                      }}
                      onAutoGenerate={handleAutoGenerateDashboard}
                      isAutoGenerating={isAutoGenerating}
                    />
                  </div>
                </div>

                {/* Raw Data Analyser */}
                <div style={{ backgroundColor: "#f3f7ff" }} className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-md">
                  <div
                    style={{ backgroundColor: "#fff9f9", color: "#180606", fontWeight: "normal" }}
                    className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6 border-b border-slate-800 pb-4 p-4 rounded-xl"
                  >
                    <div>
                      <h4 className="font-extrabold text-slate-100 text-base flex items-center gap-2">
                        <Table className="w-5 h-5 text-indigo-400" />
                        <span style={{ color: "#000000" }}>Raw Data Analyser</span>
                        <span style={{ color: "#19273f" }} className="text-xs px-2.5 py-0.5 bg-indigo-950/60 text-indigo-300 border border-indigo-800/60 rounded-full font-semibold">
                          {currentDataset.rows.length.toLocaleString()} rows
                        </span>
                      </h4>
                      <p style={{ color: "#101a2e" }} className="text-xs text-slate-400 mt-0.5">
                        Verify data formatting, search across cells, and explore tabular data
                      </p>
                    </div>
                  </div>

                  <DataExplorerView
                    dataset={currentDataset}
                    onUpdateDatasetRows={handleUpdateDatasetRows}
                    onResetToOriginal={handleResetToOriginal}
                    isCleaned={isCleaned}
                  />
                </div>

                {/* Bottom Navigation Banner */}
                <div style={{ backgroundColor: "#ffffff" }} className="flex flex-col sm:flex-row items-center justify-between gap-4 border border-indigo-900/50 p-6 rounded-2xl shadow-xs">
                  <div>
                    <h5 style={{ color: "#000000" }} className="font-bold text-slate-100 text-sm">Data Imported & Verified?</h5>
                    <p style={{ color: "#142640" }} className="text-xs text-slate-400">Proceed to build your KPI scorecard or explore graphical visualizations.</p>
                  </div>
                  <div className="flex items-center gap-3 w-full sm:w-auto">
                    <button
                      onClick={() => setActiveTab("kpi_scorecard")}
                      className="flex-1 sm:flex-initial px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-sm transition-all text-center"
                    >
                      Proceed to KPI Scorecards →
                    </button>
                    <button
                      onClick={() => setActiveTab("visualizations")}
                      className="flex-1 sm:flex-initial px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-sm transition-all text-center"
                    >
                      Graphical Visualizations →
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Page 2: KPI Scorecards */}
            {activeTab === "kpi_scorecard" && (
              <div className="space-y-6 animate-fadeIn">
                <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 flex items-center justify-between shadow-xs">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-emerald-950/60 text-emerald-400 flex items-center justify-center border border-emerald-800/50 font-bold text-sm">
                      2
                    </div>
                    <div>
                      <h3 className="font-bold text-slate-100 text-sm">KPI Scorecard Page</h3>
                      <p className="text-xs text-slate-400">Real-time aggregated metrics and executive intelligence</p>
                    </div>
                  </div>
                  <button
                    onClick={() => setActiveTab("visualizations")}
                    className="px-4 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition-all shadow-xs"
                  >
                    Go to Visualizations →
                  </button>
                </div>

                {/* Global Filter Bar */}
                <FilterBar
                  columns={currentDataset.columns}
                  filterState={filterState}
                  onFilterChange={setFilterState}
                  totalRowsCount={currentDataset.rows.length}
                  filteredRowsCount={filteredRows.length}
                />

                <DashboardCanvasView
                  dataset={currentDataset}
                  filteredRows={filteredRows}
                  kpis={kpis}
                  charts={charts}
                  executiveSummary={executiveSummary}
                  keyInsights={keyInsights}
                  onOpenAddKpi={() => {
                    setEditingKpi(null);
                    setIsKpiModalOpen(true);
                  }}
                  onEditKpi={(kpi) => {
                    setEditingKpi(kpi);
                    setIsKpiModalOpen(true);
                  }}
                  onDeleteKpi={handleDeleteKpi}
                  onOpenAddChart={() => {
                    setEditingChart(null);
                    setIsChartModalOpen(true);
                  }}
                  onEditChart={(chart) => {
                    setEditingChart(chart);
                    setIsChartModalOpen(true);
                  }}
                  onDeleteChart={handleDeleteChart}
                  onToggleChartSpan={handleToggleChartSpan}
                  onUpdateChartColor={handleUpdateChartColor}
                  onAutoGenerate={handleAutoGenerateDashboard}
                  isAutoGenerating={isAutoGenerating}
                  onOpenInsightsChat={() => setIsInsightsChatOpen(true)}
                  colorTheme={colorTheme}
                  activePage="kpi_scorecard"
                />

                {/* Bottom Navigation Banner */}
                <div className="flex flex-col sm:flex-row items-center justify-between gap-4 bg-slate-900/80 border border-slate-800 p-6 rounded-2xl">
                  <div>
                    <h5 className="font-bold text-slate-100 text-sm">Need to check raw data or view charts?</h5>
                    <p className="text-xs text-slate-400">Switch tabs at any time to inspect data or dive into visual analytics.</p>
                  </div>
                  <div className="flex items-center gap-3 w-full sm:w-auto">
                    <button
                      onClick={() => setActiveTab("import_raw")}
                      className="flex-1 sm:flex-initial px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-bold text-xs transition-all text-center"
                    >
                      ← Back to Raw Data
                    </button>
                    <button
                      onClick={() => setActiveTab("visualizations")}
                      className="flex-1 sm:flex-initial px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-sm transition-all text-center"
                    >
                      Proceed to Visualizations →
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Page 3: Graphical Visualizations */}
            {activeTab === "visualizations" && (
              <div className="space-y-6 animate-fadeIn">
                <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 flex items-center justify-between shadow-xs">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-indigo-950/60 text-indigo-400 flex items-center justify-center border border-indigo-800/50 font-bold text-sm">
                      3
                    </div>
                    <div>
                      <h3 className="font-bold text-slate-100 text-sm">Graphical Visualizations Page</h3>
                      <p className="text-xs text-slate-400">Slice, dice, and explore dynamic interactive charts</p>
                    </div>
                  </div>
                  <button
                    onClick={() => setActiveTab("kpi_scorecard")}
                    className="px-4 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold transition-all border border-slate-700"
                  >
                    ← Back to KPI Scorecards
                  </button>
                </div>

                {/* Global Filter Bar */}
                <FilterBar
                  columns={currentDataset.columns}
                  filterState={filterState}
                  onFilterChange={setFilterState}
                  totalRowsCount={currentDataset.rows.length}
                  filteredRowsCount={filteredRows.length}
                />

                <DashboardCanvasView
                  dataset={currentDataset}
                  filteredRows={filteredRows}
                  kpis={kpis}
                  charts={charts}
                  executiveSummary={executiveSummary}
                  keyInsights={keyInsights}
                  onOpenAddKpi={() => {
                    setEditingKpi(null);
                    setIsKpiModalOpen(true);
                  }}
                  onEditKpi={(kpi) => {
                    setEditingKpi(kpi);
                    setIsKpiModalOpen(true);
                  }}
                  onDeleteKpi={handleDeleteKpi}
                  onOpenAddChart={() => {
                    setEditingChart(null);
                    setIsChartModalOpen(true);
                  }}
                  onEditChart={(chart) => {
                    setEditingChart(chart);
                    setIsChartModalOpen(true);
                  }}
                  onDeleteChart={handleDeleteChart}
                  onToggleChartSpan={handleToggleChartSpan}
                  onUpdateChartColor={handleUpdateChartColor}
                  onAutoGenerate={handleAutoGenerateDashboard}
                  isAutoGenerating={isAutoGenerating}
                  onOpenInsightsChat={() => setIsInsightsChatOpen(true)}
                  colorTheme={colorTheme}
                  activePage="visualizations"
                />

                {/* Bottom Navigation Banner */}
                <div className="flex flex-col sm:flex-row items-center justify-between gap-4 bg-slate-900/80 border border-slate-800 p-6 rounded-2xl">
                  <div>
                    <h5 className="font-bold text-slate-100 text-sm">Exploration complete?</h5>
                    <p className="text-xs text-slate-400">Return to KPI Scorecards or import a new file whenever you're ready.</p>
                  </div>
                  <div className="flex items-center gap-3 w-full sm:w-auto">
                    <button
                      onClick={() => setActiveTab("kpi_scorecard")}
                      className="flex-1 sm:flex-initial px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-bold text-xs transition-all text-center"
                    >
                      ← Back to KPI Scorecard
                    </button>
                    <button
                      onClick={() => setActiveTab("import_raw")}
                      className="flex-1 sm:flex-initial px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-bold text-xs transition-all text-center"
                    >
                      ← File Import Page
                    </button>
                  </div>
                </div>
              </div>
            )}
            </motion.div>
          </AnimatePresence>
        )}
      </main>

      {/* Modals & Drawers */}
      <DatasetIngestionModal
        isOpen={isIngestionOpen}
        onClose={() => setIsIngestionOpen(false)}
        onSelectDataset={(dataset) => {
          setCurrentDataset(dataset);
        }}
      />

      <ChartBuilderModal
        isOpen={isChartModalOpen}
        onClose={() => {
          setIsChartModalOpen(false);
          setEditingChart(null);
        }}
        onSave={handleSaveChart}
        initialChart={editingChart}
        columns={currentDataset?.columns || []}
        rows={currentDataset?.rows || []}
      />

      <KpiBuilderModal
        isOpen={isKpiModalOpen}
        onClose={() => {
          setIsKpiModalOpen(false);
          setEditingKpi(null);
        }}
        onSave={handleSaveKpi}
        initialKpi={editingKpi}
        columns={currentDataset?.columns || []}
      />

      <ExportReportModal
        isOpen={isExportModalOpen}
        onClose={() => setIsExportModalOpen(false)}
        dataset={currentDataset}
        filteredRows={filteredRows}
        kpis={kpis}
        charts={charts}
        executiveSummary={executiveSummary}
        keyInsights={keyInsights}
      />

      {currentDataset && (
        <DataInsightsChat
          dataset={currentDataset}
          currentKpis={kpis}
          currentCharts={charts}
          onAddChart={(chart) => {
            handleSaveChart(chart);
          }}
          onAddKpi={(kpi) => {
            handleSaveKpi(kpi);
          }}
          isOpen={isInsightsChatOpen}
          onClose={() => setIsInsightsChatOpen(false)}
        />
      )}
    </div>
  );
}
