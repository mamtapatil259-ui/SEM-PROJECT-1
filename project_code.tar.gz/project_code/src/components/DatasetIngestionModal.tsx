import React, { useState, useRef } from "react";
import { Upload, FileText, Database, X, Sparkles, Check, AlertCircle, ArrowRight } from "lucide-react";
import * as XLSX from "xlsx";
import { SAMPLE_DATASETS, getSampleDataset } from "../data/sampleDatasets";
import { parseRawInput, analyzeDatasetSchema } from "../utils/dataEngine";
import { Dataset } from "../types";

interface DatasetIngestionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectDataset: (dataset: Dataset) => void;
}

export const DatasetIngestionModal: React.FC<DatasetIngestionModalProps> = ({
  isOpen,
  onClose,
  onSelectDataset,
}) => {
  const [activeTab, setActiveTab] = useState<"samples" | "upload" | "paste">("samples");
  const [pasteText, setPasteText] = useState("");
  const [customName, setCustomName] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleSelectSample = (id: string) => {
    const dataset = getSampleDataset(id);
    if (dataset) {
      onSelectDataset(dataset);
      onClose();
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    processFile(file);
  };

  const processFile = (file: File) => {
    setError(null);
    const ext = file.name.split(".").pop()?.toLowerCase();
    const isExcel = ext === "xlsx" || ext === "xls";

    if (isExcel) {
      const reader = new FileReader();
      reader.onload = (event) => {
        try {
          const data = new Uint8Array(event.target?.result as ArrayBuffer);
          const workbook = XLSX.read(data, { type: "array" });
          const sheetName = workbook.SheetNames[0];
          if (!sheetName) {
            setError("The uploaded Excel workbook contains no sheets.");
            return;
          }
          const worksheet = workbook.Sheets[sheetName];
          const rows = XLSX.utils.sheet_to_json<Record<string, any>>(worksheet, { defval: "" });

          if (!rows || rows.length === 0) {
            setError(`Sheet "${sheetName}" appears to be empty.`);
            return;
          }

          const columns = analyzeDatasetSchema(rows);
          const newDataset: Dataset = {
            id: `excel-${Date.now()}`,
            name: file.name.replace(/\.[^/.]+$/, ""),
            description: `Uploaded from Excel sheet "${sheetName}" (${rows.length} rows, ${columns.length} columns)`,
            rows,
            columns,
            uploadedAt: new Date().toISOString(),
          };

          onSelectDataset(newDataset);
          onClose();
        } catch (err: any) {
          setError(`Failed to parse Excel workbook: ${err?.message || "Unknown error"}`);
        }
      };
      reader.onerror = () => setError("Error reading Excel file from disk.");
      reader.readAsArrayBuffer(file);
    } else {
      const reader = new FileReader();
      reader.onload = (event) => {
        const content = event.target?.result as string;
        if (!content) {
          setError("Failed to read file contents.");
          return;
        }
        const format = ext === "json" ? "json" : ext === "tsv" ? "tsv" : "csv";
        const { rows, error: parseErr } = parseRawInput(content, format as any);

        if (parseErr || !rows || rows.length === 0) {
          setError(parseErr || "No valid data rows found in file.");
          return;
        }

        const columns = analyzeDatasetSchema(rows);
        const newDataset: Dataset = {
          id: `upload-${Date.now()}`,
          name: file.name.replace(/\.[^/.]+$/, ""),
          description: `Uploaded from file ${file.name} (${rows.length} rows, ${columns.length} columns)`,
          rows,
          columns,
          uploadedAt: new Date().toISOString(),
        };

        onSelectDataset(newDataset);
        onClose();
      };
      reader.onerror = () => {
        setError("Error reading file from disk.");
      };
      reader.readAsText(file);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      processFile(file);
    }
  };

  const handlePasteSubmit = () => {
    setError(null);
    if (!pasteText.trim()) {
      setError("Please paste CSV, TSV, or JSON data first.");
      return;
    }
    const { rows, error: parseErr } = parseRawInput(pasteText, "auto");
    if (parseErr || !rows || rows.length === 0) {
      setError(parseErr || "Could not parse valid data from pasted text.");
      return;
    }

    const columns = analyzeDatasetSchema(rows);
    const name = customName.trim() || `Pasted Dataset (${rows.length} rows)`;
    const newDataset: Dataset = {
      id: `paste-${Date.now()}`,
      name,
      description: `Custom dataset loaded via clipboard paste with ${rows.length} rows.`,
      rows,
      columns,
      uploadedAt: new Date().toISOString(),
    };

    onSelectDataset(newDataset);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-4xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-6 py-5 border-b border-slate-800 flex items-center justify-between bg-slate-900/50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center border border-indigo-500/30">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">Load Raw Dataset</h2>
              <p className="text-xs text-slate-400">Choose a rich sample dataset or upload your own CSV, TSV, or JSON</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-slate-800 bg-slate-950/40 px-6">
          <button
            onClick={() => { setActiveTab("samples"); setError(null); }}
            className={`flex items-center gap-2 px-5 py-3 text-sm font-semibold border-b-2 transition-all ${
              activeTab === "samples"
                ? "border-indigo-500 text-indigo-400 bg-indigo-500/10"
                : "border-transparent text-slate-400 hover:text-slate-200"
            }`}
          >
            <Sparkles className="w-4 h-4" />
            Preloaded Sample Library (6)
          </button>
          <button
            onClick={() => { setActiveTab("upload"); setError(null); }}
            className={`flex items-center gap-2 px-5 py-3 text-sm font-semibold border-b-2 transition-all ${
              activeTab === "upload"
                ? "border-indigo-500 text-indigo-400 bg-indigo-500/10"
                : "border-transparent text-slate-400 hover:text-slate-200"
            }`}
          >
            <Upload className="w-4 h-4" />
            Upload File
          </button>
          <button
            onClick={() => { setActiveTab("paste"); setError(null); }}
            className={`flex items-center gap-2 px-5 py-3 text-sm font-semibold border-b-2 transition-all ${
              activeTab === "paste"
                ? "border-indigo-500 text-indigo-400 bg-indigo-500/10"
                : "border-transparent text-slate-400 hover:text-slate-200"
            }`}
          >
            <FileText className="w-4 h-4" />
            Paste Raw Text
          </button>
        </div>

        {/* Error alert */}
        {error && (
          <div className="mx-6 mt-4 p-3 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-300 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
            <span>{error}</span>
          </div>
        )}

        {/* Content Body */}
        <div className="p-6 overflow-y-auto flex-1">
          {activeTab === "samples" && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {SAMPLE_DATASETS.map((sample) => (
                <div
                  key={sample.id}
                  onClick={() => handleSelectSample(sample.id)}
                  className="group relative bg-slate-950/60 hover:bg-slate-800/80 border border-slate-800 hover:border-indigo-500/50 rounded-2xl p-5 cursor-pointer transition-all duration-200 flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-[11px] font-bold tracking-wider uppercase px-2.5 py-0.5 rounded-full bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
                        {sample.category}
                      </span>
                      <span className="text-xs font-semibold text-slate-400">
                        {sample.rawData.length} rows
                      </span>
                    </div>
                    <h3 className="font-bold text-white group-hover:text-indigo-300 transition-colors text-base mb-1.5 flex items-center justify-between">
                      <span>{sample.name}</span>
                      <ArrowRight className="w-4 h-4 text-slate-500 group-hover:text-indigo-400 group-hover:translate-x-1 transition-all" />
                    </h3>
                    <p className="text-xs text-slate-400 line-clamp-2 leading-relaxed">
                      {sample.description}
                    </p>
                  </div>
                  <div className="mt-4 pt-3 border-t border-slate-800/60 flex items-center justify-between text-[11px] text-slate-400">
                    <span>Columns: {Object.keys(sample.rawData[0] || {}).slice(0, 4).join(", ")}...</span>
                    <span className="text-indigo-400 font-semibold group-hover:underline">Instant Load →</span>
                  </div>
                </div>
              ))}
            </div>
          )}

          {activeTab === "upload" && (
            <div className="flex flex-col items-center justify-center py-8">
              <div
                onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
                onDragLeave={() => setIsDragging(false)}
                onDrop={handleDrop}
                onClick={() => fileInputRef.current?.click()}
                className={`w-full max-w-2xl border-2 border-dashed rounded-2xl p-10 flex flex-col items-center justify-center cursor-pointer transition-all ${
                  isDragging
                    ? "border-indigo-500 bg-indigo-500/10 scale-[1.02]"
                    : "border-slate-700 bg-slate-950/40 hover:border-slate-600 hover:bg-slate-950/80"
                }`}
              >
                <div className="w-14 h-14 rounded-2xl bg-indigo-500/10 text-indigo-400 flex items-center justify-center mb-4 border border-indigo-500/20 shadow-lg">
                  <Upload className="w-7 h-7" />
                </div>
                <h3 className="text-base font-bold text-white mb-1">Drag and drop your file here</h3>
                <p className="text-xs text-slate-400 mb-6 text-center max-w-sm">
                  Supports Excel (.xlsx, .xls), CSV, TSV, and JSON formats. We parse columns, detect types, and calculate aggregates automatically.
                </p>
                <button
                  type="button"
                  onClick={(e) => { e.stopPropagation(); fileInputRef.current?.click(); }}
                  className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-semibold shadow-lg shadow-indigo-600/30 transition-all"
                >
                  Browse Files
                </button>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".xlsx,.xls,.csv,.tsv,.json,.txt"
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </div>
            </div>
          )}

          {activeTab === "paste" && (
            <div className="flex flex-col gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                  Dataset Name (Optional)
                </label>
                <input
                  type="text"
                  value={customName}
                  onChange={(e) => setCustomName(e.target.value)}
                  placeholder="e.g. Q3 Sales Performance"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-indigo-500"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                  Paste Raw Data (CSV, TSV, or JSON)
                </label>
                <textarea
                  rows={10}
                  value={pasteText}
                  onChange={(e) => setPasteText(e.target.value)}
                  placeholder={`Date,Category,Revenue,Units\n2025-01-01,Electronics,1200,5\n2025-01-02,Apparel,450,12\n2025-01-03,Home,890,4`}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-4 text-xs font-mono text-slate-200 focus:outline-none focus:border-indigo-500 resize-none leading-relaxed"
                />
              </div>
              <div className="flex justify-end">
                <button
                  onClick={handlePasteSubmit}
                  className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-semibold shadow-lg shadow-indigo-600/30 transition-all"
                >
                  <Check className="w-4 h-4" />
                  Parse & Load Dataset
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
