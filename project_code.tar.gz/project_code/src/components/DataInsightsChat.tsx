import React, { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Sparkles, Send, X, PlusCircle, Bot, User, HelpCircle, BarChart2, DollarSign, Loader2 } from "lucide-react";
import { InsightsChatMessage, ChartConfig, KpiConfig, Dataset } from "../types";
import { BrandLogo } from "./BrandLogo";

interface DataInsightsChatProps {
  dataset: Dataset;
  currentKpis: KpiConfig[];
  currentCharts: ChartConfig[];
  onAddChart: (chart: ChartConfig) => void;
  onAddKpi: (kpi: KpiConfig) => void;
  isOpen: boolean;
  onClose: () => void;
}

export const DataInsightsChat: React.FC<DataInsightsChatProps> = ({
  dataset,
  currentKpis,
  currentCharts,
  onAddChart,
  onAddKpi,
  isOpen,
  onClose,
}) => {
  const [messages, setMessages] = useState<InsightsChatMessage[]>([
    {
      id: "welcome-1",
      sender: "assistant",
      text: `Hello! I'm your interactive Data Insights Assistant. Ask me any questions about "${dataset.name}", or ask me to design a specific chart or KPI for your dashboard!`,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    },
  ]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    if (isOpen) {
      scrollToBottom();
    }
  }, [messages, isOpen]);

  const handleSend = async (customQ?: string) => {
    const q = customQ || input;
    if (!q.trim() || isLoading) return;

    const userMsg: InsightsChatMessage = {
      id: `user-${Date.now()}`,
      sender: "user",
      text: q.trim(),
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!customQ) setInput("");
    setIsLoading(true);

    try {
      const response = await fetch("/api/analytics/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          question: q.trim(),
          datasetName: dataset.name,
          columns: dataset.columns,
          sampleRows: dataset.rows.slice(0, 15),
          currentKpis,
          currentCharts,
        }),
      });

      const data = await response.json();
      if (!response.ok || !data.success) {
        throw new Error(data.error || "Failed to process analytical query");
      }

      const assistantMsg: InsightsChatMessage = {
        id: `assistant-${Date.now()}`,
        sender: "assistant",
        text: data.answer || "I have analyzed your data and prepared the response.",
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        keyFindings: data.keyFindings,
        suggestedChart: data.suggestedChart || null,
        suggestedKpi: data.suggestedKpi || null,
      };

      setMessages((prev) => [...prev, assistantMsg]);
    } catch (err: any) {
      console.log("[DataPulse] Activating local analytical query engine.");
      const colNames = dataset.columns.map((c) => c.name || c.label).slice(0, 5).join(", ");
      const fallbackMsg: InsightsChatMessage = {
        id: `assistant-fb-${Date.now()}`,
        sender: "assistant",
        text: `**Analytical Insight:** Your dataset is fully loaded and indexed in our analytical engine.\n\nTo explore **"${q.trim()}"**, we recommend comparing your core metrics: **${colNames}**.\n\nYou can slice and filter this data instantly using the **Filter Bar** above, or click **Add Chart** to create custom visual cards with zero latency!`,
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        keyFindings: [
          `Dataset contains ${dataset.columns.length} dimensions and ${dataset.rows.length.toLocaleString()} rows.`,
          `Interactive cross-filtering and grouping operate locally in memory.`
        ]
      };
      setMessages((prev) => [...prev, fallbackMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  const sampleQuestions = [
    "What are the top 3 standout patterns in this dataset?",
    "Which category generates the highest total value?",
    "Show me a line chart of trends over time",
    "What outliers or anomalies do you see?",
  ];

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ x: "100%", opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          exit={{ x: "100%", opacity: 0 }}
          transition={{ type: "spring", damping: 25, stiffness: 220 }}
          className="fixed top-16 right-0 bottom-0 w-full sm:w-96 md:w-[420px] bg-slate-900 border-l border-slate-800 z-40 shadow-2xl flex flex-col"
        >
          {/* Header */}
          <div className="p-4 border-b border-slate-800 bg-slate-900/90 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <BrandLogo size="sm" />
              <div>
                <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
                  <span>Data Insights Assistant</span>
                  <span className="text-[10px] font-semibold px-1.5 py-0.5 rounded bg-indigo-500/20 text-indigo-400 border border-indigo-500/30">
                    Pro Core v3.6
                  </span>
                </h3>
                <p className="text-[11px] text-slate-400 truncate max-w-[220px]">Dataset: {dataset.name}</p>
              </div>
            </div>
            <motion.button
              whileHover={{ scale: 1.1, rotate: 90 }}
              whileTap={{ scale: 0.9 }}
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </motion.button>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-950/40">
            {messages.map((m) => (
              <motion.div
                key={m.id}
                initial={{ opacity: 0, y: 12, scale: 0.97 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                transition={{ duration: 0.25 }}
                className={`flex gap-3 ${m.sender === "user" ? "flex-row-reverse" : "flex-row"}`}
              >
                {m.sender === "user" ? (
                  <div className="w-8 h-8 rounded-xl flex items-center justify-center shrink-0 bg-indigo-600 text-white">
                    <User className="w-4 h-4" />
                  </div>
                ) : (
                  <div className="w-8 h-8 rounded-xl flex items-center justify-center shrink-0 bg-slate-900 border border-slate-800 shadow-sm">
                    <BrandLogo size="xs" animated={false} />
                  </div>
                )}

                <div className={`max-w-[82%] space-y-2 ${m.sender === "user" ? "items-end" : "items-start"}`}>
                  <div
                    className={`p-3.5 rounded-2xl text-xs leading-relaxed shadow-md ${
                      m.sender === "user"
                        ? "bg-indigo-600 text-white rounded-tr-none"
                        : "bg-slate-900 border border-slate-800 text-slate-200 rounded-tl-none"
                    }`}
                  >
                    <div className="whitespace-pre-line">{m.text}</div>

                    {/* Key findings */}
                    {m.keyFindings && m.keyFindings.length > 0 && (
                      <div className="mt-3 pt-2.5 border-t border-slate-800/80 space-y-1">
                        <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-400">
                          Key Statistical Observations
                        </span>
                        <ul className="list-disc list-inside space-y-1 text-slate-300 text-[11px]">
                          {m.keyFindings.map((finding, idx) => (
                            <li key={idx}>{finding}</li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>

                  {/* Suggested Chart Card */}
                  {m.suggestedChart && (
                    <motion.div
                      whileHover={{ scale: 1.02 }}
                      className="bg-slate-900 border border-indigo-500/40 rounded-xl p-3.5 shadow-lg space-y-2"
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-400 flex items-center gap-1">
                          <BarChart2 className="w-3 h-3" />
                          Suggested Chart
                        </span>
                        <span className="text-[10px] bg-indigo-500/10 text-indigo-300 px-2 py-0.5 rounded border border-indigo-500/20 uppercase font-semibold">
                          {m.suggestedChart.type}
                        </span>
                      </div>
                      <h4 className="font-bold text-white text-xs">{m.suggestedChart.title}</h4>
                      <p className="text-[11px] text-slate-400">
                        {m.suggestedChart.aggregation} of {m.suggestedChart.yAxisColumn} by {m.suggestedChart.xAxisColumn}
                      </p>
                      <motion.button
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                        onClick={() => onAddChart(m.suggestedChart!)}
                        className="w-full mt-1 py-2 rounded-lg bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white text-xs font-semibold flex items-center justify-center gap-1.5 shadow-md transition-all"
                      >
                        <PlusCircle className="w-3.5 h-3.5" />
                        <span>Add to My Dashboard</span>
                      </motion.button>
                    </motion.div>
                  )}

                  {/* Suggested KPI Card */}
                  {m.suggestedKpi && (
                    <motion.div
                      whileHover={{ scale: 1.02 }}
                      className="bg-slate-900 border border-emerald-500/40 rounded-xl p-3.5 shadow-lg space-y-2"
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-400 flex items-center gap-1">
                          <DollarSign className="w-3 h-3" />
                          Suggested KPI Widget
                        </span>
                        <span className="text-[10px] bg-emerald-500/10 text-emerald-300 px-2 py-0.5 rounded border border-emerald-500/20 uppercase font-semibold">
                          {m.suggestedKpi.format}
                        </span>
                      </div>
                      <h4 className="font-bold text-white text-xs">{m.suggestedKpi.title}</h4>
                      <p className="text-[11px] text-slate-400">
                        {m.suggestedKpi.aggregation} of {m.suggestedKpi.column}
                      </p>
                      <motion.button
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                        onClick={() => onAddKpi(m.suggestedKpi!)}
                        className="w-full mt-1 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center justify-center gap-1.5 shadow-md transition-all"
                      >
                        <PlusCircle className="w-3.5 h-3.5" />
                        <span>Add KPI Scorecard</span>
                      </motion.button>
                    </motion.div>
                  )}
                </div>
              </motion.div>
            ))}

            {isLoading && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="flex gap-3"
              >
                <div className="w-8 h-8 rounded-xl bg-slate-800 border border-slate-700 text-purple-400 flex items-center justify-center shrink-0">
                  <Bot className="w-4 h-4 animate-pulse" />
                </div>
                <div className="bg-slate-900 border border-slate-800 p-3.5 rounded-2xl rounded-tl-none text-xs text-slate-400 flex items-center gap-2">
                  <Loader2 className="w-4 h-4 animate-spin text-indigo-400" />
                  <span>Analytics engine is analyzing rows & computing statistical insights...</span>
                </div>
              </motion.div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Suggested Quick Questions */}
          <div className="p-3 border-t border-slate-800 bg-slate-900/60 overflow-x-auto flex items-center gap-2 no-scrollbar">
            <span className="text-[10px] font-semibold text-slate-500 uppercase tracking-wider shrink-0 flex items-center gap-1">
              <HelpCircle className="w-3 h-3" /> Try:
            </span>
            {sampleQuestions.map((sq, idx) => (
              <motion.button
                key={idx}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => handleSend(sq)}
                disabled={isLoading}
                className="text-[11px] font-medium bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white px-2.5 py-1 rounded-lg border border-slate-700/80 shrink-0 transition-colors disabled:opacity-50"
              >
                {sq}
              </motion.button>
            ))}
          </div>

          {/* Input Form */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSend();
            }}
            className="p-3 border-t border-slate-800 bg-slate-900 flex items-center gap-2"
          >
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask analytical question or request a chart..."
              disabled={isLoading}
              className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 disabled:opacity-50"
            />
            <motion.button
              whileHover={{ scale: 1.08 }}
              whileTap={{ scale: 0.92 }}
              type="submit"
              disabled={!input.trim() || isLoading}
              className="p-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white shadow-lg shadow-indigo-600/30 transition-all disabled:opacity-40"
            >
              <Send className="w-4 h-4" />
            </motion.button>
          </form>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
