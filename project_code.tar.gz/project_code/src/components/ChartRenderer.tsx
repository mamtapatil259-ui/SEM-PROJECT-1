import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { useAnimationConfig } from "../context/AnimationContext";
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  LineChart,
  Line,
  AreaChart,
  Area,
  ComposedChart,
  RadialBarChart,
  RadialBar,
  Treemap,
  PieChart,
  Pie,
  Cell,
  ScatterChart,
  Scatter,
  RadarChart,
  Radar,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  LabelList,
  Brush,
  ReferenceLine,
} from "recharts";
import {
  Maximize2,
  Minimize2,
  Trash2,
  Edit3,
  BarChart2,
  TrendingUp,
  Layers,
  PieChart as PieIcon,
  Activity,
  ArrowUpDown,
  Grid,
  Table,
  X,
  Palette,
  Eye,
  EyeOff,
  Download,
  Sliders,
  Target,
  Sparkles,
  Zap,
} from "lucide-react";
import { ChartConfig, ChartType, ColorTheme } from "../types";
import { prepareChartData } from "../utils/dataEngine";

interface ChartRendererProps {
  chart: ChartConfig;
  rows: Record<string, any>[];
  onEdit?: (chart: ChartConfig) => void;
  onDelete?: (id: string) => void;
  onToggleSpan?: (id: string) => void;
  onUpdateColor?: (id: string, theme: ColorTheme, customHex?: string) => void;
  isPreview?: boolean;
}

// 6 Unique Multi-Color Palettes to make every graph distinct & visually rich
const UNIQUE_SPECTRUM_PALETTES = [
  ["#6366f1", "#10b981", "#f59e0b", "#ec4899", "#06b6d4", "#8b5cf6", "#f43f5e", "#3b82f6", "#14b8a6", "#eab308"],
  ["#06b6d4", "#3b82f6", "#8b5cf6", "#d946ef", "#f43f5e", "#f97316", "#eab308", "#10b981", "#0284c7", "#ec4899"],
  ["#10b981", "#059669", "#14b8a6", "#0ea5e9", "#2563eb", "#6366f1", "#8b5cf6", "#d946ef", "#f59e0b", "#f43f5e"],
  ["#f59e0b", "#f97316", "#ef4444", "#ec4899", "#a855f7", "#6366f1", "#3b82f6", "#06b6d4", "#10b981", "#d946ef"],
  ["#ec4899", "#d946ef", "#a855f7", "#8b5cf6", "#6366f1", "#3b82f6", "#06b6d4", "#10b981", "#f59e0b", "#f43f5e"],
  ["#14b8a6", "#06b6d4", "#38bdf8", "#818cf8", "#a78bfa", "#f472b6", "#fb7185", "#fbbf24", "#34d399", "#6366f1"],
];

function getUniquePaletteForChart(chart: ChartConfig): string[] {
  if (chart.customColorHex) {
    const basePalette = UNIQUE_SPECTRUM_PALETTES[0];
    return [chart.customColorHex, ...basePalette];
  }
  let hash = 0;
  const str = (chart.id || "") + (chart.title || "");
  for (let i = 0; i < str.length; i++) {
    hash = str.charCodeAt(i) + ((hash << 5) - hash);
  }
  const index = Math.abs(hash) % UNIQUE_SPECTRUM_PALETTES.length;
  return UNIQUE_SPECTRUM_PALETTES[index];
}

export const ChartRenderer: React.FC<ChartRendererProps> = ({
  chart,
  rows,
  onEdit,
  onDelete,
  onToggleSpan,
  onUpdateColor,
  isPreview = false,
}) => {
  const { springTransition, cardHover, buttonHover, buttonTap, isReduced } = useAnimationConfig();
  const [activeChartType, setActiveChartType] = useState<ChartType>(chart.type);
  const [sortOrder, setSortOrder] = useState<"none" | "desc" | "asc">("none");
  const [showValues, setShowValues] = useState<boolean>(chart.showValues !== false);
  const [showGrid, setShowGrid] = useState<boolean>(chart.showGrid !== false);
  const [showBrush, setShowBrush] = useState<boolean>(chart.showBrush || false);
  const [showReferenceLine, setShowReferenceLine] = useState<boolean>(chart.showReferenceLine || false);
  const [curveType, setCurveType] = useState<"monotone" | "linear" | "step">(chart.curveType || "monotone");
  const [showColorPicker, setShowColorPicker] = useState(false);
  const [isExpandedModalOpen, setIsExpandedModalOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<"chart" | "data">("chart");

  React.useEffect(() => {
    setActiveChartType(chart.type);
  }, [chart.type]);

  const rawData = prepareChartData(
    rows,
    chart.xAxisColumn,
    chart.yAxisColumn,
    chart.aggregation,
    chart.groupByColumn
  );

  const firstItem = rawData[0] || {};
  const seriesKeys = Object.keys(firstItem).filter((k) => k !== "name");
  const primaryValKey = seriesKeys[0] || "value";

  const data = React.useMemo(() => {
    if (sortOrder === "none") return rawData;
    const sorted = [...rawData];
    sorted.sort((a, b) => {
      const valA = Number(a[primaryValKey]) || 0;
      const valB = Number(b[primaryValKey]) || 0;
      return sortOrder === "desc" ? valB - valA : valA - valB;
    });
    return sorted;
  }, [rawData, sortOrder, primaryValKey]);

  const totalSum = React.useMemo(() => {
    return data.reduce((acc, curr) => acc + (Number(curr[primaryValKey]) || 0), 0);
  }, [data, primaryValKey]);

  const averageValue = React.useMemo(() => {
    return data.length > 0 ? totalSum / data.length : 0;
  }, [data, totalSum]);

  const colors = getUniquePaletteForChart(chart);

  const formatTooltipValue = (value: any) => {
    if (typeof value === "number") {
      if (Math.abs(value) >= 1000000) return `${(value / 1000000).toFixed(2)}M`;
      if (Math.abs(value) >= 1000) return `${(value / 1000).toFixed(1)}k`;
      return value.toLocaleString();
    }
    return value;
  };

  const xAxisLabelConfig = chart.customXAxisLabel
    ? { value: chart.customXAxisLabel, position: "insideBottom" as const, offset: -10, fill: "#64748b", fontSize: 11, fontWeight: 600 }
    : undefined;

  const yAxisLabelConfig = chart.customYAxisLabel
    ? { value: chart.customYAxisLabel, angle: -90, position: "insideLeft" as const, fill: "#64748b", fontSize: 11, fontWeight: 600 }
    : undefined;

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const val = payload[0].value;
      const pct = totalSum > 0 ? ((Number(val) / totalSum) * 100).toFixed(1) : null;
      return (
        <div className="bg-slate-900 border border-slate-700/80 p-3 rounded-2xl shadow-xl text-white text-xs max-w-xs z-50">
          <div className="font-bold text-slate-200 mb-1 border-b border-slate-800 pb-1 flex items-center justify-between gap-2">
            <span>{label}</span>
            {pct && (
              <span className="text-[10px] bg-indigo-500/20 text-indigo-300 px-2 py-0.5 rounded-full border border-indigo-500/30 font-semibold">
                {pct}% of total
              </span>
            )}
          </div>
          <div className="space-y-1 mt-1.5">
            {payload.map((p: any, idx: number) => (
              <div key={idx} className="flex items-center justify-between gap-3">
                <span className="flex items-center gap-1.5 text-slate-300">
                  <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: p.color }} />
                  <span>{p.name}:</span>
                </span>
                <span className="font-extrabold text-white">{formatTooltipValue(p.value)}</span>
              </div>
            ))}
          </div>
        </div>
      );
    }
    return null;
  };

  const renderChartContent = (height = 260) => {
    if (!data || data.length === 0) {
      return (
        <div className="h-64 flex flex-col items-center justify-center text-slate-500 text-xs gap-2">
          <BarChart2 className="w-8 h-8 stroke-1 text-slate-300" />
          <span>No matching data for selected columns</span>
        </div>
      );
    }

    switch (activeChartType) {
      case "bar":
        return (
          <ResponsiveContainer width="100%" height={height}>
            <BarChart data={data} margin={{ top: 15, right: 10, left: 0, bottom: showBrush ? 30 : 20 }}>
              {showGrid && <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" opacity={0.8} />}
              <XAxis dataKey="name" stroke="#64748b" fontSize={11} tickLine={false} label={xAxisLabelConfig} />
              <YAxis stroke="#64748b" fontSize={11} tickLine={false} tickFormatter={formatTooltipValue} label={yAxisLabelConfig} />
              <Tooltip content={<CustomTooltip />} />
              {chart.showLegend !== false && seriesKeys.length > 1 && <Legend wrapperStyle={{ fontSize: "11px", paddingTop: "10px", color: "#334155" }} />}
              {showReferenceLine && (
                <ReferenceLine y={averageValue} stroke="#ef4444" strokeDasharray="3 3" label={{ value: `Avg: ${formatTooltipValue(averageValue)}`, fill: "#ef4444", fontSize: 10, fontWeight: 700 }} />
              )}
              {seriesKeys.map((key, i) => (
                <Bar
                  key={key}
                  dataKey={key}
                  radius={[8, 8, 0, 0]}
                  maxBarSize={48}
                >
                  {data.map((entry, index) => (
                    <Cell key={`bar-cell-${index}`} fill={colors[index % colors.length]} />
                  ))}
                  {showValues && (
                    <LabelList dataKey={key} position="top" style={{ fontSize: "10px", fill: "#475569", fontWeight: 700 }} formatter={formatTooltipValue} />
                  )}
                </Bar>
              ))}
              {showBrush && <Brush dataKey="name" height={22} stroke="#6366f1" fill="#f8fafc" />}
            </BarChart>
          </ResponsiveContainer>
        );

      case "line":
        return (
          <ResponsiveContainer width="100%" height={height}>
            <LineChart data={data} margin={{ top: 15, right: 10, left: 0, bottom: showBrush ? 30 : 20 }}>
              {showGrid && <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" opacity={0.8} />}
              <XAxis dataKey="name" stroke="#64748b" fontSize={11} tickLine={false} label={xAxisLabelConfig} />
              <YAxis stroke="#64748b" fontSize={11} tickLine={false} tickFormatter={formatTooltipValue} label={yAxisLabelConfig} />
              <Tooltip content={<CustomTooltip />} />
              {chart.showLegend !== false && seriesKeys.length > 1 && <Legend wrapperStyle={{ fontSize: "11px", paddingTop: "10px", color: "#334155" }} />}
              {showReferenceLine && (
                <ReferenceLine y={averageValue} stroke="#ef4444" strokeDasharray="3 3" label={{ value: `Avg: ${formatTooltipValue(averageValue)}`, fill: "#ef4444", fontSize: 10, fontWeight: 700 }} />
              )}
              {seriesKeys.map((key, i) => (
                <Line
                  key={key}
                  type={curveType}
                  dataKey={key}
                  stroke={colors[i % colors.length]}
                  strokeWidth={3}
                  dot={{ r: 5, fill: colors[i % colors.length], strokeWidth: 2, stroke: "#ffffff" }}
                  activeDot={{ r: 8, stroke: colors[i % colors.length], strokeWidth: 3 }}
                >
                  {showValues && (
                    <LabelList dataKey={key} position="top" style={{ fontSize: "10px", fill: "#475569", fontWeight: 700 }} formatter={formatTooltipValue} />
                  )}
                </Line>
              ))}
              {showBrush && <Brush dataKey="name" height={22} stroke="#6366f1" fill="#f8fafc" />}
            </LineChart>
          </ResponsiveContainer>
        );

      case "area":
        return (
          <ResponsiveContainer width="100%" height={height}>
            <AreaChart data={data} margin={{ top: 15, right: 10, left: 0, bottom: showBrush ? 30 : 20 }}>
              <defs>
                {seriesKeys.map((key, i) => (
                  <linearGradient key={`grad-${i}`} id={`areaGrad-${chart.id}-${i}`} x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor={colors[i % colors.length]} stopOpacity={0.7} />
                    <stop offset="95%" stopColor={colors[i % colors.length]} stopOpacity={0.05} />
                  </linearGradient>
                ))}
              </defs>
              {showGrid && <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" opacity={0.8} />}
              <XAxis dataKey="name" stroke="#64748b" fontSize={11} tickLine={false} label={xAxisLabelConfig} />
              <YAxis stroke="#64748b" fontSize={11} tickLine={false} tickFormatter={formatTooltipValue} label={yAxisLabelConfig} />
              <Tooltip content={<CustomTooltip />} />
              {chart.showLegend !== false && seriesKeys.length > 1 && <Legend wrapperStyle={{ fontSize: "11px", paddingTop: "10px", color: "#334155" }} />}
              {showReferenceLine && (
                <ReferenceLine y={averageValue} stroke="#ef4444" strokeDasharray="3 3" label={{ value: `Avg: ${formatTooltipValue(averageValue)}`, fill: "#ef4444", fontSize: 10, fontWeight: 700 }} />
              )}
              {seriesKeys.map((key, i) => (
                <Area
                  key={key}
                  type={curveType}
                  dataKey={key}
                  stroke={colors[i % colors.length]}
                  fill={`url(#areaGrad-${chart.id}-${i})`}
                  strokeWidth={3}
                >
                  {showValues && (
                    <LabelList dataKey={key} position="top" style={{ fontSize: "10px", fill: "#475569", fontWeight: 700 }} formatter={formatTooltipValue} />
                  )}
                </Area>
              ))}
              {showBrush && <Brush dataKey="name" height={22} stroke="#6366f1" fill="#f8fafc" />}
            </AreaChart>
          </ResponsiveContainer>
        );

      case "composed":
        return (
          <ResponsiveContainer width="100%" height={height}>
            <ComposedChart data={data} margin={{ top: 15, right: 10, left: 0, bottom: showBrush ? 30 : 20 }}>
              {showGrid && <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" opacity={0.8} />}
              <XAxis dataKey="name" stroke="#64748b" fontSize={11} tickLine={false} label={xAxisLabelConfig} />
              <YAxis stroke="#64748b" fontSize={11} tickLine={false} tickFormatter={formatTooltipValue} label={yAxisLabelConfig} />
              <Tooltip content={<CustomTooltip />} />
              {chart.showLegend !== false && <Legend wrapperStyle={{ fontSize: "11px", paddingTop: "10px", color: "#334155" }} />}
              {showReferenceLine && (
                <ReferenceLine y={averageValue} stroke="#ef4444" strokeDasharray="3 3" label={{ value: `Avg: ${formatTooltipValue(averageValue)}`, fill: "#ef4444", fontSize: 10, fontWeight: 700 }} />
              )}
              <Bar dataKey={seriesKeys[0] || "value"} radius={[8, 8, 0, 0]} maxBarSize={44}>
                {data.map((entry, index) => (
                  <Cell key={`comp-cell-${index}`} fill={colors[index % colors.length]} />
                ))}
              </Bar>
              <Line
                type={curveType}
                dataKey={seriesKeys[1] || seriesKeys[0] || "value"}
                stroke="#f59e0b"
                strokeWidth={3}
                dot={{ r: 5, fill: "#f59e0b", stroke: "#ffffff", strokeWidth: 2 }}
              />
              {showBrush && <Brush dataKey="name" height={22} stroke="#6366f1" fill="#f8fafc" />}
            </ComposedChart>
          </ResponsiveContainer>
        );

      case "radialBar":
        const radialData = data.slice(0, 8).map((item, idx) => ({
          ...item,
          fill: colors[idx % colors.length],
        }));
        return (
          <ResponsiveContainer width="100%" height={height}>
            <RadialBarChart
              cx="50%"
              cy="50%"
              innerRadius="20%"
              outerRadius="90%"
              barSize={16}
              data={radialData}
            >
              <RadialBar
                minAngle={15}
                label={{ position: "insideStart", fill: "#ffffff", fontSize: 10, fontWeight: 700 }}
                background
                clockWise
                dataKey={primaryValKey}
              />
              <Legend
                iconSize={10}
                layout="vertical"
                verticalAlign="middle"
                align="right"
                wrapperStyle={{ fontSize: "11px", color: "#334155" }}
              />
              <Tooltip content={<CustomTooltip />} />
            </RadialBarChart>
          </ResponsiveContainer>
        );

      case "treemap":
        const treemapData = data.map((item, idx) => ({
          name: item.name,
          size: Math.max(1, Number(item[primaryValKey]) || 1),
          fill: colors[idx % colors.length],
        }));
        return (
          <ResponsiveContainer width="100%" height={height}>
            <Treemap
              data={treemapData}
              dataKey="size"
              aspectRatio={4 / 3}
              stroke="#ffffff"
              fill="#6366f1"
            >
              <Tooltip content={<CustomTooltip />} />
            </Treemap>
          </ResponsiveContainer>
        );

      case "pie":
        return (
          <ResponsiveContainer width="100%" height={height}>
            <PieChart>
              <Tooltip content={<CustomTooltip />} />
              {chart.showLegend !== false && <Legend wrapperStyle={{ fontSize: "11px", color: "#334155" }} />}
              <Pie
                data={data}
                dataKey={seriesKeys[0] || "value"}
                nameKey="name"
                cx="50%"
                cy="50%"
                outerRadius={height > 300 ? 120 : 85}
                innerRadius={height > 300 ? 55 : 38}
                paddingAngle={3}
                label={showValues ? { fill: "#334155", fontSize: 10, fontWeight: 600 } : undefined}
              >
                {data.map((entry, index) => (
                  <Cell key={`pie-cell-${index}`} fill={colors[index % colors.length]} stroke="#ffffff" strokeWidth={2} />
                ))}
              </Pie>
            </PieChart>
          </ResponsiveContainer>
        );

      case "scatter":
        return (
          <ResponsiveContainer width="100%" height={height}>
            <ScatterChart margin={{ top: 15, right: 10, left: 0, bottom: 20 }}>
              {showGrid && <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" opacity={0.8} />}
              <XAxis dataKey="name" stroke="#64748b" fontSize={11} name={chart.customXAxisLabel || chart.xAxisColumn} label={xAxisLabelConfig} />
              <YAxis dataKey={seriesKeys[0] || "value"} stroke="#64748b" fontSize={11} name={chart.customYAxisLabel || chart.yAxisColumn} label={yAxisLabelConfig} />
              <Tooltip content={<CustomTooltip />} cursor={{ strokeDasharray: "3 3" }} />
              <Scatter name={chart.title} data={data}>
                {data.map((entry, index) => (
                  <Cell key={`scatter-cell-${index}`} fill={colors[index % colors.length]} />
                ))}
                {showValues && (
                  <LabelList dataKey={seriesKeys[0] || "value"} position="top" style={{ fontSize: "10px", fill: "#475569", fontWeight: 700 }} formatter={formatTooltipValue} />
                )}
              </Scatter>
            </ScatterChart>
          </ResponsiveContainer>
        );

      case "radar":
        return (
          <ResponsiveContainer width="100%" height={height}>
            <RadarChart cx="50%" cy="50%" outerRadius={height > 300 ? 120 : 85} data={data}>
              <PolarGrid stroke="#cbd5e1" />
              <PolarAngleAxis dataKey="name" stroke="#475569" fontSize={10} fontWeight={600} />
              <PolarRadiusAxis angle={30} domain={[0, "auto"]} stroke="#64748b" fontSize={9} />
              <Tooltip content={<CustomTooltip />} />
              {seriesKeys.map((key, i) => (
                <Radar
                  key={key}
                  name={key}
                  dataKey={key}
                  stroke={colors[i % colors.length]}
                  fill={colors[i % colors.length]}
                  fillOpacity={0.45}
                />
              ))}
            </RadarChart>
          </ResponsiveContainer>
        );

      default:
        return null;
    }
  };

  const exportChartCsv = () => {
    if (!data || data.length === 0) return;
    const headers = ["name", ...seriesKeys];
    const csvLines = [
      headers.join(","),
      ...data.map((row) => headers.map((h) => JSON.stringify(row[h] ?? "")).join(",")),
    ];
    const blob = new Blob([csvLines.join("\n")], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${chart.title.toLowerCase().replace(/\s+/g, "_")}_data.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <>
      <motion.div
        layout="position"
        initial={isReduced ? { opacity: 0 } : { opacity: 0, y: 15, scale: 0.98 }}
        animate={isReduced ? { opacity: 1 } : { opacity: 1, y: 0, scale: 1 }}
        exit={isReduced ? { opacity: 0 } : { opacity: 0, scale: 0.95 }}
        transition={isReduced ? { duration: 0 } : springTransition(320, 26)}
        whileHover={cardHover}
        className={`bg-white border border-slate-200 hover:border-slate-300 rounded-3xl p-6 shadow-sm hover:shadow-md transition-colors duration-200 flex flex-col justify-between text-slate-900 ${
          chart.colSpan === 2 ? "col-span-1 md:col-span-2 lg:col-span-2" : "col-span-1"
        }`}
      >
        {/* Card Header & Interactive Switcher Toolbar */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-3">
          <div>
            <div className="flex flex-wrap items-center gap-1.5 mb-1">
              {/* Interactive Chart Type Quick Toggles */}
              <div className="flex flex-wrap items-center gap-1 bg-slate-100 p-0.5 rounded-xl border border-slate-200">
                <button
                  onClick={() => setActiveChartType("bar")}
                  className={`p-1 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1 ${
                    activeChartType === "bar" ? "bg-white text-indigo-600 shadow-2xs font-bold" : "text-slate-500 hover:text-slate-900"
                  }`}
                  title="Bar Chart"
                >
                  <BarChart2 className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => setActiveChartType("line")}
                  className={`p-1 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1 ${
                    activeChartType === "line" ? "bg-white text-indigo-600 shadow-2xs font-bold" : "text-slate-500 hover:text-slate-900"
                  }`}
                  title="Line Chart"
                >
                  <TrendingUp className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => setActiveChartType("area")}
                  className={`p-1 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1 ${
                    activeChartType === "area" ? "bg-white text-indigo-600 shadow-2xs font-bold" : "text-slate-500 hover:text-slate-900"
                  }`}
                  title="Area Chart"
                >
                  <Layers className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => setActiveChartType("composed")}
                  className={`p-1.5 rounded-lg text-[10px] font-bold uppercase transition-colors flex items-center gap-1 ${
                    activeChartType === "composed" ? "bg-white text-indigo-600 shadow-2xs" : "text-slate-500 hover:text-slate-900"
                  }`}
                  title="Composed Combo Chart (Bar + Line)"
                >
                  <Zap className="w-3.5 h-3.5 text-amber-500" />
                  <span>Combo</span>
                </button>
                <button
                  onClick={() => setActiveChartType("pie")}
                  className={`p-1 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1 ${
                    activeChartType === "pie" ? "bg-white text-indigo-600 shadow-2xs font-bold" : "text-slate-500 hover:text-slate-900"
                  }`}
                  title="Donut / Pie Chart"
                >
                  <PieIcon className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => setActiveChartType("radialBar")}
                  className={`p-1.5 rounded-lg text-[10px] font-bold uppercase transition-colors flex items-center gap-1 ${
                    activeChartType === "radialBar" ? "bg-white text-indigo-600 shadow-2xs" : "text-slate-500 hover:text-slate-900"
                  }`}
                  title="Radial Gauge Graphic"
                >
                  <Sparkles className="w-3.5 h-3.5 text-purple-500" />
                  <span>Radial</span>
                </button>
                <button
                  onClick={() => setActiveChartType("treemap")}
                  className={`p-1.5 rounded-lg text-[10px] font-bold uppercase transition-colors flex items-center gap-1 ${
                    activeChartType === "treemap" ? "bg-white text-indigo-600 shadow-2xs" : "text-slate-500 hover:text-slate-900"
                  }`}
                  title="Treemap Tile Graphic"
                >
                  <Grid className="w-3.5 h-3.5 text-emerald-500" />
                  <span>Treemap</span>
                </button>
              </div>

              <span className="text-[11px] font-semibold text-indigo-600">
                {chart.aggregation} of {chart.yAxisColumn} by {chart.xAxisColumn}
              </span>
            </div>
            <h3 className="font-bold text-slate-900 text-base leading-snug">{chart.title}</h3>
            {chart.description && <p className="text-xs text-slate-500 mt-0.5">{chart.description}</p>}
          </div>

          {!isPreview && (
            <div className="flex flex-wrap items-center gap-1 shrink-0 bg-slate-100 p-1 rounded-xl border border-slate-200 self-start sm:self-center">
              {/* Interactive Sort Toggle */}
              <button
                onClick={() => {
                  if (sortOrder === "none") setSortOrder("desc");
                  else if (sortOrder === "desc") setSortOrder("asc");
                  else setSortOrder("none");
                }}
                className={`p-1.5 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1 ${
                  sortOrder !== "none" ? "bg-indigo-600 text-white shadow-2xs" : "text-slate-600 hover:text-indigo-600 hover:bg-white"
                }`}
                title={`Sort values (${sortOrder === "desc" ? "High to Low" : sortOrder === "asc" ? "Low to High" : "Default"})`}
              >
                <ArrowUpDown className="w-3.5 h-3.5" />
              </button>

              {/* Data Labels Toggle */}
              <button
                onClick={() => setShowValues(!showValues)}
                className={`p-1.5 rounded-lg transition-colors ${
                  showValues ? "bg-indigo-50 text-indigo-600 font-bold" : "text-slate-500 hover:text-slate-800 hover:bg-white"
                }`}
                title="Toggle Data Numbers over chart"
              >
                {showValues ? <Eye className="w-3.5 h-3.5 text-indigo-600" /> : <EyeOff className="w-3.5 h-3.5" />}
              </button>

              {/* Brush / Zoom Slider Toggle */}
              {(activeChartType === "bar" || activeChartType === "line" || activeChartType === "area" || activeChartType === "composed") && (
                <button
                  onClick={() => setShowBrush(!showBrush)}
                  className={`p-1.5 rounded-lg transition-colors ${
                    showBrush ? "bg-indigo-600 text-white font-bold" : "text-slate-500 hover:text-slate-800 hover:bg-white"
                  }`}
                  title="Toggle Zoom Brush Slider"
                >
                  <Sliders className="w-3.5 h-3.5" />
                </button>
              )}

              {/* Average Reference Line Toggle */}
              {(activeChartType === "bar" || activeChartType === "line" || activeChartType === "area" || activeChartType === "composed") && (
                <button
                  onClick={() => setShowReferenceLine(!showReferenceLine)}
                  className={`p-1.5 rounded-lg transition-colors ${
                    showReferenceLine ? "bg-rose-500 text-white font-bold" : "text-slate-500 hover:text-rose-600 hover:bg-white"
                  }`}
                  title="Toggle Benchmark Average Target Line"
                >
                  <Target className="w-3.5 h-3.5" />
                </button>
              )}

              {/* Curve Style Switcher for Line/Area */}
              {(activeChartType === "line" || activeChartType === "area" || activeChartType === "composed") && (
                <button
                  onClick={() => {
                    if (curveType === "monotone") setCurveType("step");
                    else if (curveType === "step") setCurveType("linear");
                    else setCurveType("monotone");
                  }}
                  className="px-1.5 py-1 text-[10px] font-bold uppercase rounded-lg text-slate-600 hover:text-indigo-600 hover:bg-white transition-colors border border-slate-200"
                  title={`Curve style: ${curveType}`}
                >
                  {curveType}
                </button>
              )}

              {/* Grid Toggle */}
              <button
                onClick={() => setShowGrid(!showGrid)}
                className={`p-1.5 rounded-lg transition-colors ${
                  showGrid ? "text-indigo-600 font-bold" : "text-slate-400 hover:text-slate-700"
                }`}
                title="Toggle Grid Lines"
              >
                <Grid className="w-3.5 h-3.5" />
              </button>

              {/* Color Picker Toggle */}
              {onUpdateColor && (
                <button
                  onClick={() => setShowColorPicker(!showColorPicker)}
                  className={`p-1.5 rounded-lg transition-colors ${
                    showColorPicker ? "bg-indigo-600 text-white shadow-xs" : "text-slate-600 hover:text-indigo-600 hover:bg-white"
                  }`}
                  title="Pick custom color"
                >
                  <Palette className="w-3.5 h-3.5" />
                </button>
              )}

              {/* Expand / Inspect Modal */}
              <button
                onClick={() => setIsExpandedModalOpen(true)}
                className="p-1.5 text-slate-600 hover:text-indigo-600 rounded-lg hover:bg-white transition-colors"
                title="Inspect in full screen view"
              >
                <Maximize2 className="w-3.5 h-3.5" />
              </button>

              {/* Column width span toggle */}
              {onToggleSpan && (
                <button
                  onClick={() => onToggleSpan(chart.id)}
                  className="p-1.5 text-slate-600 hover:text-slate-900 rounded-lg hover:bg-white transition-colors"
                  title={chart.colSpan === 2 ? "Reduce width" : "Expand width"}
                >
                  {chart.colSpan === 2 ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
                </button>
              )}

              {/* Edit */}
              {onEdit && (
                <button
                  onClick={() => onEdit(chart)}
                  className="p-1.5 text-slate-600 hover:text-indigo-600 rounded-lg hover:bg-white transition-colors"
                  title="Edit chart configuration"
                >
                  <Edit3 className="w-3.5 h-3.5" />
                </button>
              )}

              {/* Delete */}
              {onDelete && (
                <button
                  onClick={() => onDelete(chart.id)}
                  className="p-1.5 text-slate-600 hover:text-rose-600 rounded-lg hover:bg-white transition-colors"
                  title="Remove chart"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          )}
        </div>

        {/* Inline Custom Hex Colour Section */}
        {showColorPicker && !isPreview && (
          <div className="mb-4 p-3 bg-slate-50 border border-indigo-200 rounded-2xl shadow-xs animate-fadeIn flex flex-wrap items-center justify-between gap-2">
            <span className="text-xs font-bold text-slate-700">Custom Accent Color:</span>
            <div className="flex items-center gap-2">
              <input
                type="color"
                value={chart.customColorHex || colors[0]}
                onChange={(e) => {
                  if (onUpdateColor) onUpdateColor(chart.id, chart.colorTheme || "indigo", e.target.value);
                }}
                className="w-7 h-7 rounded-xl border border-slate-300 bg-white p-0.5 cursor-pointer shadow-xs"
              />
              <input
                type="text"
                value={chart.customColorHex || ""}
                onChange={(e) => {
                  if (onUpdateColor) onUpdateColor(chart.id, chart.colorTheme || "indigo", e.target.value);
                }}
                placeholder="#6366F1"
                className="w-24 px-2.5 py-1 rounded-xl border border-slate-300 text-[11px] font-mono uppercase bg-white focus:outline-none focus:border-indigo-500 font-bold text-slate-800"
              />
              {chart.customColorHex && (
                <button
                  onClick={() => {
                    if (onUpdateColor) onUpdateColor(chart.id, chart.colorTheme || "indigo", undefined);
                  }}
                  className="text-[11px] text-rose-600 hover:underline px-1.5 py-1 font-bold rounded hover:bg-rose-50"
                >
                  Reset
                </button>
              )}
            </div>
          </div>
        )}

        {/* Chart Canvas */}
        <div className="w-full pt-2 flex-1 min-h-[260px] flex items-center justify-center overflow-hidden">
          <AnimatePresence mode="wait">
            <motion.div
              key={`${chart.id}-${activeChartType}-${sortOrder}-${showValues}-${showBrush}-${showReferenceLine}-${curveType}`}
              initial={{ opacity: 0, scale: 0.96 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.96 }}
              transition={{ duration: 0.25 }}
              className="w-full h-full"
            >
              {renderChartContent(260)}
            </motion.div>
          </AnimatePresence>
        </div>
      </motion.div>

      {/* Interactive Full-Screen / Expanded Inspection Modal */}
      <AnimatePresence>
        {isExpandedModalOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 sm:p-6"
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              transition={{ type: "spring", damping: 25, stiffness: 300 }}
              className="bg-white border border-slate-200 rounded-3xl max-w-4xl w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden"
            >
              {/* Modal Header */}
              <div className="p-6 border-b border-slate-200 flex items-center justify-between bg-slate-50">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-[10px] font-bold tracking-wider uppercase px-2.5 py-0.5 rounded-full bg-indigo-100 text-indigo-700">
                      Graphical Visualization View
                    </span>
                    <span className="text-xs font-bold text-indigo-600">
                      {chart.aggregation} of {chart.yAxisColumn} by {chart.xAxisColumn}
                    </span>
                  </div>
                  <h2 className="text-xl font-extrabold text-slate-900">{chart.title}</h2>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={exportChartCsv}
                    className="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold flex items-center gap-1.5 transition-colors"
                  >
                    <Download className="w-4 h-4 text-emerald-600" />
                    <span>Export CSV</span>
                  </button>
                  <button
                    onClick={() => setIsExpandedModalOpen(false)}
                    className="p-2 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-700 transition-colors"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
              </div>

              {/* Modal Tabs */}
              <div className="px-6 pt-3 border-b border-slate-200 flex items-center gap-3 bg-white">
                <button
                  onClick={() => setActiveTab("chart")}
                  className={`pb-2 text-xs font-bold flex items-center gap-1.5 border-b-2 transition-all ${
                    activeTab === "chart" ? "border-indigo-600 text-indigo-600" : "border-transparent text-slate-500 hover:text-slate-800"
                  }`}
                >
                  <BarChart2 className="w-4 h-4" />
                  <span>High-Definition Canvas</span>
                </button>
                <button
                  onClick={() => setActiveTab("data")}
                  className={`pb-2 text-xs font-bold flex items-center gap-1.5 border-b-2 transition-all ${
                    activeTab === "data" ? "border-indigo-600 text-indigo-600" : "border-transparent text-slate-500 hover:text-slate-800"
                  }`}
                >
                  <Table className="w-4 h-4" />
                  <span>Aggregated Data Matrix ({data.length} records)</span>
                </button>
              </div>

              {/* Modal Body */}
              <div className="p-6 flex-1 overflow-y-auto bg-slate-50">
                {activeTab === "chart" ? (
                  <div className="w-full bg-white border border-slate-200 rounded-2xl p-6 shadow-xs">
                    {renderChartContent(400)}
                  </div>
                ) : (
                  <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
                    <table className="w-full text-left text-xs border-collapse">
                      <thead>
                        <tr className="bg-slate-100 border-b border-slate-200 text-slate-700 uppercase font-extrabold tracking-wider">
                          <th className="p-3">Rank #</th>
                          <th className="p-3">{chart.xAxisColumn}</th>
                          <th className="p-3">{chart.aggregation} of {chart.yAxisColumn}</th>
                          <th className="p-3">% Share of Total</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {data.map((item, idx) => {
                          const val = Number(item[primaryValKey]) || 0;
                          const pct = totalSum > 0 ? ((val / totalSum) * 100).toFixed(1) : "0.0";
                          return (
                            <tr key={idx} className="hover:bg-slate-50/80 transition-colors">
                              <td className="p-3 font-mono font-bold text-slate-400">#{idx + 1}</td>
                              <td className="p-3 font-semibold text-slate-900">{item.name}</td>
                              <td className="p-3 font-mono font-extrabold text-indigo-600">{formatTooltipValue(val)}</td>
                              <td className="p-3">
                                <div className="flex items-center gap-2">
                                  <div className="w-16 bg-slate-100 rounded-full h-2 overflow-hidden">
                                    <div
                                      className="bg-indigo-600 h-full rounded-full"
                                      style={{ width: `${Math.min(100, Number(pct))}%` }}
                                    />
                                  </div>
                                  <span className="font-mono text-slate-600 font-bold">{pct}%</span>
                                </div>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};
