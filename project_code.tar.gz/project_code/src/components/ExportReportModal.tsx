import React from "react";
import { Download, FileText, FileCode, FileSpreadsheet, X, Printer, Filter, Database } from "lucide-react";
import { Dataset, DashboardConfig, KpiConfig, ChartConfig } from "../types";

interface ExportReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  dataset: Dataset | null;
  filteredRows?: Record<string, any>[];
  kpis: KpiConfig[];
  charts: ChartConfig[];
  executiveSummary?: string;
  keyInsights?: string[];
}

export const ExportReportModal: React.FC<ExportReportModalProps> = ({
  isOpen,
  onClose,
  dataset,
  filteredRows,
  kpis,
  charts,
  executiveSummary,
  keyInsights,
}) => {
  if (!isOpen || !dataset) return null;

  const activeRows = filteredRows || dataset.rows;

  const handlePrintPdf = () => {
    window.print();
  };

  const handleDownloadDashboardJson = () => {
    const config: DashboardConfig = {
      id: `dash-${Date.now()}`,
      datasetId: dataset.id,
      title: `${dataset.name} Dashboard`,
      executiveSummary,
      keyInsights,
      kpis,
      charts,
      updatedAt: new Date().toISOString(),
    };

    const blob = new Blob([JSON.stringify(config, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.setAttribute("download", `${dataset.name.replace(/\s+/g, "_")}_dashboard_config.json`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const generateCsv = (rowsToExport: Record<string, any>[]) => {
    const headers = dataset.columns.map((c) => c.name).join(",");
    const csvRows = rowsToExport.map((r) =>
      dataset.columns
        .map((c) => {
          const val = r[c.name] ?? "";
          if (typeof val === "string" && (val.includes(",") || val.includes('"') || val.includes("\n"))) {
            return `"${val.replace(/"/g, '""')}"`;
          }
          return val;
        })
        .join(",")
    );
    return [headers, ...csvRows].join("\n");
  };

  const handleDownloadFilteredCsv = () => {
    const csvContent = generateCsv(activeRows);
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.setAttribute("download", `${dataset.name.replace(/\s+/g, "_")}_filtered_sorted.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleDownloadFilteredJson = () => {
    const blob = new Blob([JSON.stringify(activeRows, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.setAttribute("download", `${dataset.name.replace(/\s+/g, "_")}_filtered_sorted.json`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleDownloadRawCsv = () => {
    const csvContent = generateCsv(dataset.rows);
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.setAttribute("download", `${dataset.name.replace(/\s+/g, "_")}_raw_original.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleDownloadRawJson = () => {
    const blob = new Blob([JSON.stringify(dataset.rows, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.setAttribute("download", `${dataset.name.replace(/\s+/g, "_")}_raw_original.json`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4 overflow-y-auto print:hidden">
      <div className="bg-white border border-slate-200 rounded-3xl w-full max-w-2xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center border border-indigo-200 shadow-2xs">
              <Download className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-900">Export & Report Center</h2>
              <p className="text-xs text-slate-500">Download filtered dashboard datasets, raw datasets, or reports</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-700 rounded-xl hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 space-y-6 overflow-y-auto flex-1">
          {/* Section 1: Filtered & Sorted Data */}
          <div>
            <div className="flex items-center justify-between mb-2.5">
              <span className="text-xs font-bold text-indigo-600 uppercase tracking-wider flex items-center gap-1.5">
                <Filter className="w-3.5 h-3.5" />
                1. Export Displayed Data (Filtered & Sorted)
              </span>
              <span className="text-xs font-bold bg-indigo-50 text-indigo-700 px-2 py-0.5 rounded-full border border-indigo-200">
                {activeRows.length.toLocaleString()} rows selected
              </span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div
                onClick={handleDownloadFilteredCsv}
                className="group bg-slate-50 hover:bg-indigo-50/50 border border-slate-200 hover:border-indigo-300 rounded-2xl p-3.5 cursor-pointer transition-all flex items-center justify-between shadow-2xs"
              >
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center border border-emerald-200 group-hover:scale-105 transition-transform">
                    <FileSpreadsheet className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-900 text-xs">Filtered Data (CSV)</h3>
                    <p className="text-[11px] text-slate-500">Spreadsheet format</p>
                  </div>
                </div>
                <span className="text-xs font-bold text-indigo-600 group-hover:underline">CSV →</span>
              </div>

              <div
                onClick={handleDownloadFilteredJson}
                className="group bg-slate-50 hover:bg-indigo-50/50 border border-slate-200 hover:border-indigo-300 rounded-2xl p-3.5 cursor-pointer transition-all flex items-center justify-between shadow-2xs"
              >
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center border border-amber-200 group-hover:scale-105 transition-transform">
                    <FileText className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-900 text-xs">Filtered Data (JSON)</h3>
                    <p className="text-[11px] text-slate-500">Structured JSON array</p>
                  </div>
                </div>
                <span className="text-xs font-bold text-indigo-600 group-hover:underline">JSON →</span>
              </div>
            </div>
          </div>

          {/* Section 2: Original Raw Dataset */}
          <div>
            <div className="flex items-center justify-between mb-2.5">
              <span className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                <Database className="w-3.5 h-3.5 text-slate-500" />
                2. Export Original Raw Dataset
              </span>
              <span className="text-xs font-bold bg-slate-100 text-slate-700 px-2 py-0.5 rounded-full border border-slate-200">
                {dataset.rows.length.toLocaleString()} total rows
              </span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div
                onClick={handleDownloadRawCsv}
                className="group bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-2xl p-3.5 cursor-pointer transition-all flex items-center justify-between shadow-2xs"
              >
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center border border-emerald-200 group-hover:scale-105 transition-transform">
                    <FileSpreadsheet className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-900 text-xs">Original Dataset (CSV)</h3>
                    <p className="text-[11px] text-slate-500">Full un-filtered dataset</p>
                  </div>
                </div>
                <span className="text-xs font-bold text-slate-700 group-hover:underline">CSV →</span>
              </div>

              <div
                onClick={handleDownloadRawJson}
                className="group bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-2xl p-3.5 cursor-pointer transition-all flex items-center justify-between shadow-2xs"
              >
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center border border-amber-200 group-hover:scale-105 transition-transform">
                    <FileText className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-900 text-xs">Original Dataset (JSON)</h3>
                    <p className="text-[11px] text-slate-500">Full un-filtered dataset</p>
                  </div>
                </div>
                <span className="text-xs font-bold text-slate-700 group-hover:underline">JSON →</span>
              </div>
            </div>
          </div>

          {/* Section 3: Executive Reports & Layouts */}
          <div>
            <div className="flex items-center justify-between mb-2.5">
              <span className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                <Printer className="w-3.5 h-3.5 text-slate-500" />
                3. Dashboard Reports & Configs
              </span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div
                onClick={handlePrintPdf}
                className="group bg-slate-50 hover:bg-indigo-50/50 border border-slate-200 hover:border-indigo-300 rounded-2xl p-3.5 cursor-pointer transition-all flex items-center justify-between shadow-2xs"
              >
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center border border-indigo-200 group-hover:scale-105 transition-transform">
                    <Printer className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-900 text-xs">Print / Save PDF Report</h3>
                    <p className="text-[11px] text-slate-500">Executive dashboard report</p>
                  </div>
                </div>
                <span className="text-xs font-bold text-indigo-600 group-hover:underline">Print →</span>
              </div>

              <div
                onClick={handleDownloadDashboardJson}
                className="group bg-slate-50 hover:bg-purple-50/50 border border-slate-200 hover:border-purple-300 rounded-2xl p-3.5 cursor-pointer transition-all flex items-center justify-between shadow-2xs"
              >
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center border border-purple-200 group-hover:scale-105 transition-transform">
                    <FileCode className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-900 text-xs">Dashboard Layout (JSON)</h3>
                    <p className="text-[11px] text-slate-500">Charts, KPIs, & Dashboard config</p>
                  </div>
                </div>
                <span className="text-xs font-bold text-purple-600 group-hover:underline">Config →</span>
              </div>
            </div>
          </div>
        </div>

        {/* Footer actions */}
        <div className="px-6 py-4 border-t border-slate-200 bg-slate-50 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-6 py-2 rounded-xl bg-white hover:bg-slate-100 border border-slate-200 text-slate-700 text-xs font-semibold transition-colors shadow-2xs"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
