import React, { useEffect, useState, useRef } from "react";
import { useAnimationConfig } from "../context/AnimationContext";

interface AnimatedCounterProps {
  value: number | string;
  format?: "number" | "currency" | "percent" | "compact" | "raw";
  prefix?: string;
  suffix?: string;
  duration?: number;
  className?: string;
}

export const AnimatedCounter: React.FC<AnimatedCounterProps> = ({
  value,
  format = "number",
  prefix = "",
  suffix = "",
  duration = 0.65,
  className = "",
}) => {
  const { isReduced, mode, speed } = useAnimationConfig();

  // Extract numerical target value
  const parseNumeric = (val: number | string): { num: number; detectedPrefix: string; detectedSuffix: string; decimals: number } => {
    if (typeof val === "number") {
      const decimals = val.toString().split(".")[1]?.length || 0;
      return { num: val, detectedPrefix: "", detectedSuffix: "", decimals: Math.min(decimals, 2) };
    }

    const str = String(val).trim();
    // Check for existing symbols like $, %, etc.
    const match = str.match(/^([^0-9.-]*)([0-9.,-]+)([^0-9.-]*)$/);
    if (match) {
      const p = match[1];
      const rawNumStr = match[2].replace(/,/g, "");
      const s = match[3];
      const parsed = parseFloat(rawNumStr);
      const decimals = rawNumStr.split(".")[1]?.length || 0;
      return {
        num: isNaN(parsed) ? 0 : parsed,
        detectedPrefix: p,
        detectedSuffix: s,
        decimals: Math.min(decimals, 2),
      };
    }

    const parsed = parseFloat(str.replace(/[^0-9.-]/g, ""));
    return {
      num: isNaN(parsed) ? 0 : parsed,
      detectedPrefix: "",
      detectedSuffix: "",
      decimals: 0,
    };
  };

  const parsed = parseNumeric(value);
  const targetNum = parsed.num;
  const [displayValue, setDisplayValue] = useState<number>(() => targetNum);
  const currentRef = useRef<number>(targetNum);
  const animationFrameRef = useRef<number | null>(null);

  useEffect(() => {
    if (isReduced) {
      setDisplayValue(targetNum);
      currentRef.current = targetNum;
      return;
    }

    const startVal = currentRef.current;
    const endVal = targetNum;
    const change = endVal - startVal;

    // If change is negligible or non-numeric, jump immediately
    if (Math.abs(change) < 0.0001) {
      setDisplayValue(endVal);
      currentRef.current = endVal;
      return;
    }

    const startTime = performance.now();
    const animDuration = (mode === "snappy" ? 0.25 : mode === "gentle" ? 0.9 : duration) * (1000 / speed);

    const step = (timestamp: number) => {
      const elapsed = timestamp - startTime;
      const progress = Math.min(elapsed / animDuration, 1);

      // Easing curve: easeOutExpo / easeOutCubic
      const ease = progress === 1 ? 1 : 1 - Math.pow(2, -10 * progress);
      const current = startVal + change * ease;

      currentRef.current = current;
      setDisplayValue(current);

      if (progress < 1) {
        animationFrameRef.current = requestAnimationFrame(step);
      } else {
        currentRef.current = endVal;
        setDisplayValue(endVal);
      }
    };

    animationFrameRef.current = requestAnimationFrame(step);

    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [targetNum, duration, isReduced, mode, speed]);

  const formatOutput = (num: number): string => {
    const activePrefix = prefix || parsed.detectedPrefix;
    const activeSuffix = suffix || parsed.detectedSuffix;
    const dec = parsed.decimals;

    let formattedNum = "";

    if (format === "currency" || activePrefix.includes("$")) {
      formattedNum = num.toLocaleString("en-US", {
        minimumFractionDigits: dec,
        maximumFractionDigits: dec,
      });
      return `${activePrefix.includes("$") ? "" : "$"}${activePrefix}${formattedNum}${activeSuffix}`;
    }

    if (format === "percent" || activeSuffix.includes("%")) {
      formattedNum = num.toLocaleString("en-US", {
        minimumFractionDigits: dec,
        maximumFractionDigits: dec,
      });
      return `${activePrefix}${formattedNum}${activeSuffix.includes("%") ? activeSuffix : "%"}`;
    }

    if (format === "compact") {
      if (Math.abs(num) >= 1_000_000_000) {
        formattedNum = (num / 1_000_000_000).toFixed(1) + "B";
      } else if (Math.abs(num) >= 1_000_000) {
        formattedNum = (num / 1_000_000).toFixed(1) + "M";
      } else if (Math.abs(num) >= 1_000) {
        formattedNum = (num / 1_000).toFixed(1) + "K";
      } else {
        formattedNum = num.toFixed(dec);
      }
      return `${activePrefix}${formattedNum}${activeSuffix}`;
    }

    formattedNum = num.toLocaleString("en-US", {
      minimumFractionDigits: dec,
      maximumFractionDigits: dec,
    });
    return `${activePrefix}${formattedNum}${activeSuffix}`;
  };

  return <span className={`inline-block tabular-nums transition-colors ${className}`}>{formatOutput(displayValue)}</span>;
};
