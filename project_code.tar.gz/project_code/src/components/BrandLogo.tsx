import React from "react";

interface BrandLogoProps {
  size?: "xs" | "sm" | "md" | "lg" | "xl";
  className?: string;
  showText?: boolean;
  animated?: boolean;
}

export const BrandLogo: React.FC<BrandLogoProps> = ({
  size = "md",
  className = "",
  showText = false,
  animated = true,
}) => {
  const sizeMap = {
    xs: "w-6 h-6",
    sm: "w-8 h-8",
    md: "w-10 h-10",
    lg: "w-14 h-14",
    xl: "w-20 h-20",
  };

  const textMap = {
    xs: "text-base",
    sm: "text-lg",
    md: "text-xl",
    lg: "text-3xl",
    xl: "text-5xl",
  };

  return (
    <div className={`inline-flex items-center gap-3 select-none ${className}`}>
      {/* Icon Emblem Container */}
      <div className={`relative flex items-center justify-center shrink-0 ${sizeMap[size]}`}>
        {/* Glow backdrop effect for larger sizes */}
        {(size === "lg" || size === "xl") && (
          <div className="absolute inset-0 bg-gradient-to-tr from-indigo-500 via-cyan-400 to-purple-500 rounded-2xl blur-lg opacity-40 animate-pulse" />
        )}

        {/* Custom Vector SVG Logo */}
        <svg
          viewBox="0 0 100 100"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className={`w-full h-full relative z-10 transition-transform duration-300 ${
            animated ? "hover:scale-105" : ""
          }`}
        >
          <defs>
            {/* Primary Gradient (Indigo -> Cyan -> Violet) */}
            <linearGradient id="datadash-bg-grad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#4f46e5" />
              <stop offset="50%" stopColor="#6366f1" />
              <stop offset="100%" stopColor="#06b6d4" />
            </linearGradient>

            {/* Accent Wave Gradient (Cyan -> Emerald -> Lime) */}
            <linearGradient id="datadash-wave-grad" x1="0%" y1="100%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#06b6d4" />
              <stop offset="60%" stopColor="#10b981" />
              <stop offset="100%" stopColor="#34d399" />
            </linearGradient>

            {/* Spark Gold Gradient */}
            <linearGradient id="datadash-spark-grad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#f59e0b" />
              <stop offset="100%" stopColor="#fbbf24" />
            </linearGradient>

            {/* Subtle Inner Shimmer */}
            <filter id="logo-glow" x="-20%" y="-20%" width="140%" height="140%">
              <feGaussianBlur stdDeviation="3" result="blur" />
              <feComposite in="SourceGraphic" in2="blur" operator="over" />
            </filter>
          </defs>

          {/* Outer Rounded Hexagonal / Diamond Shield Frame */}
          <path
            d="M50 4L88 26V74L50 96L12 74V26L50 4Z"
            fill="url(#datadash-bg-grad)"
            className="drop-shadow-md"
          />

          {/* Subtle Geometric Overlay Lines representing Data Mesh */}
          <path
            d="M50 4V96M12 26L88 74M88 26L12 74"
            stroke="white"
            strokeWidth="0.75"
            strokeOpacity="0.15"
          />

          {/* Inner Dark Glass Container for Analytics Pillars */}
          <path
            d="M50 14L80 31.5V68.5L50 86L20 68.5V31.5L50 14Z"
            fill="#0f172a"
            fillOpacity="0.85"
          />

          {/* Data Pillar 1 (Left - Foundation) */}
          <rect
            x="31"
            y="54"
            width="8"
            height="22"
            rx="3"
            fill="#818cf8"
            fillOpacity="0.9"
            className="transition-all duration-500"
          />

          {/* Data Pillar 2 (Center - Growth) */}
          <rect
            x="46"
            y="40"
            width="8"
            height="36"
            rx="3"
            fill="url(#datadash-wave-grad)"
            className="transition-all duration-500"
          />

          {/* Data Pillar 3 (Right - High Performance) */}
          <rect
            x="61"
            y="26"
            width="8"
            height="50"
            rx="3"
            fill="#38bdf8"
            fillOpacity="0.95"
            className="transition-all duration-500"
          />

          {/* Velocity Slash / Automated Insights Arc cutting across the columns */}
          <path
            d="M22 62C34 58 48 42 78 28"
            stroke="url(#datadash-spark-grad)"
            strokeWidth="4.5"
            strokeLinecap="round"
            filter="url(#logo-glow)"
          />

          {/* Intelligence Spark Point at Peak */}
          <circle cx="78" cy="28" r="4.5" fill="#ffffff" filter="url(#logo-glow)" />
          <circle cx="78" cy="28" r="2" fill="#f59e0b" />
        </svg>
      </div>

      {/* Optional Wordmark */}
      {showText && (
        <div className="flex flex-col justify-center">
          <div className={`font-black tracking-tight leading-none text-slate-100 ${textMap[size]}`}>
            Auto <span className="bg-gradient-to-r from-indigo-400 via-cyan-400 to-emerald-400 bg-clip-text text-transparent">DataDash</span>
          </div>
          <span className="text-[10px] sm:text-xs font-bold tracking-widest text-indigo-300 uppercase mt-1 opacity-80">
            BI Analytics Studio
          </span>
        </div>
      )}
    </div>
  );
};
