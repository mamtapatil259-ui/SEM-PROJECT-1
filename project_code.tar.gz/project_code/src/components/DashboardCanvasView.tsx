import React from "react";
import { motion, AnimatePresence } from "motion/react";
import { Plus, Sparkles, BarChart3, DollarSign } from "lucide-react";
import { Dataset, KpiConfig, ChartConfig, ColorTheme } from "../types";
import { KpiCard } from "./KpiCard";
import { ChartRenderer } from "./ChartRenderer";
import { useAnimationConfig } from "../context/AnimationContext";

interface DashboardCanvasViewProps {
  dataset: Dataset;
  filteredRows: Record<string, any>[];
  kpis: KpiConfig[];
  charts: ChartConfig[];
  executiveSummary?: string;
  keyInsights?: string[];
  onOpenAddKpi: () => void;
  onEditKpi: (kpi: KpiConfig) => void;
  onDeleteKpi: (id: string) => void;
  onOpenAddChart: () => void;
  onEditChart: (chart: ChartConfig) => void;
  onDeleteChart: (id: string) => void;
  onToggleChartSpan: (id: string) => void;
  onUpdateChartColor?: (id: string, theme: ColorTheme, customHex?: string) => void;
  onAutoGenerate: () => void;
  isAutoGenerating: boolean;
  onOpenInsightsChat: () => void;
  colorTheme: ColorTheme;
  activePage?: "kpi_scorecard" | "visualizations" | "all";
}

export const DashboardCanvasView: React.FC<DashboardCanvasViewProps> = ({
  dataset,
  filteredRows,
  kpis,
  charts,
  executiveSummary,
  keyInsights,
  onOpenAddKpi,
  onEditKpi,
  onDeleteKpi,
  onOpenAddChart,
  onEditChart,
  onDeleteChart,
  onToggleChartSpan,
  onUpdateChartColor,
  onAutoGenerate,
  isAutoGenerating,
  onOpenInsightsChat,
  colorTheme,
  activePage = "all",
}) => {
  const { springTransition, buttonHover, buttonTap, isReduced } = useAnimationConfig();
  const showKpi = activePage === "kpi_scorecard" || activePage === "all";
  const showCharts = activePage === "visualizations" || activePage === "all";

  return (
    <div className="space-y-8 pb-12">
      {/* KPI Scorecard Grid */}
      {showKpi && (
        <motion.div
          initial={isReduced ? { opacity: 0 } : { opacity: 0, y: 20 }}
          animate={isReduced ? { opacity: 1 } : { opacity: 1, y: 0 }}
          transition={isReduced ? { duration: 0 } : springTransition(350, 26)}
        >
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <DollarSign className="w-5 h-5 text-emerald-400" />
              <h3 className="text-base font-bold text-slate-100">KPI Scorecards ({kpis.length})</h3>
              <span className="text-xs text-slate-400">Key metrics aggregated in real time</span>
            </div>

            <motion.button
              whileHover={buttonHover}
              whileTap={buttonTap}
              onClick={onOpenAddKpi}
              className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold transition-colors cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5 text-emerald-400" />
              <span>Make Your KPI</span>
            </motion.button>
          </div>

          {kpis.length === 0 ? (
            <div className="bg-slate-900/60 border border-dashed border-slate-800 rounded-3xl p-8 text-center flex flex-col items-center justify-center shadow-sm">
              <DollarSign className="w-8 h-8 text-slate-500 mb-2" />
              <p className="text-xs font-semibold text-slate-200 mb-1">No KPI scorecards added yet</p>
              <p className="text-[11px] text-slate-400 mb-4 max-w-sm">
                Create custom metric scorecards or click KPI auto Generator to analyze your dataset automatically.
              </p>
              <div className="flex items-center gap-3">
                <button
                  onClick={onOpenAddKpi}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold transition-colors"
                >
                  + Make Your KPI
                </button>
                <button
                  onClick={onAutoGenerate}
                  disabled={isAutoGenerating}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow-sm transition-all"
                >
                  <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                  <span>KPI auto Generator</span>
                </button>
              </div>
            </div>
          ) : (
            <AnimatePresence mode="popLayout">
              <motion.div layout className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {kpis.map((kpi, idx) => (
                  <KpiCard
                    key={kpi.id}
                    kpi={kpi}
                    rows={filteredRows}
                    onEdit={onEditKpi}
                    onDelete={onDeleteKpi}
                    index={idx}
                    colorTheme={colorTheme}
                  />
                ))}
              </motion.div>
            </AnimatePresence>
          )}
        </motion.div>
      )}

      {/* Interactive Charts Canvas */}
      {showCharts && (
        <motion.div
          initial={isReduced ? { opacity: 0 } : { opacity: 0, y: 20 }}
          animate={isReduced ? { opacity: 1 } : { opacity: 1, y: 0 }}
          transition={isReduced ? { duration: 0 } : { ...springTransition(350, 26), delay: 0.08 }}
        >
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <BarChart3 className="w-5 h-5 text-indigo-400" />
              <h3 className="text-base font-bold text-slate-100">Graphical Visualizations ({charts.length})</h3>
              <span className="text-xs text-slate-400">Dynamic charts reacting to global filters</span>
            </div>

            <motion.button
              whileHover={buttonHover}
              whileTap={buttonTap}
              onClick={onOpenAddChart}
              className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow-sm transition-all cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Make Your Chart</span>
            </motion.button>
          </div>

          {charts.length === 0 ? (
            <div className="bg-slate-900/60 border border-dashed border-slate-800 rounded-3xl p-12 text-center flex flex-col items-center justify-center shadow-sm">
              <div className="w-16 h-16 rounded-2xl bg-indigo-950/60 text-indigo-400 flex items-center justify-center mb-4 border border-indigo-800/60 shadow-sm">
                <BarChart3 className="w-8 h-8" />
              </div>
              <h3 className="text-base font-bold text-slate-100 mb-1">Your Dashboard Canvas is Empty</h3>
              <p className="text-xs text-slate-400 max-w-md mb-6 leading-relaxed">
                Start building your interactive BI dashboard. You can manually design bar, line, pie, and scatter charts or click Generate Dashboard to build a complete suite instantly!
              </p>
              <div className="flex items-center gap-3">
                <button
                  onClick={onOpenAddChart}
                  className="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold transition-colors flex items-center gap-1.5"
                >
                  <Plus className="w-4 h-4 text-indigo-400" />
                  <span>Make Your Chart</span>
                </button>
                <button
                  onClick={onAutoGenerate}
                  disabled={isAutoGenerating}
                  className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow-sm transition-all transform hover:scale-105 active:scale-95"
                >
                  <Sparkles className={`w-4 h-4 ${isAutoGenerating ? "animate-spin text-amber-300" : "text-amber-300"}`} />
                  <span>{isAutoGenerating ? "Generating Dashboard..." : "Generate Dashboard"}</span>
                </button>
              </div>
            </div>
          ) : (
            <AnimatePresence mode="popLayout">
              <motion.div layout className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {charts.map((chart) => (
                  <ChartRenderer
                    key={chart.id}
                    chart={{ ...chart, colorTheme: chart.customColorHex ? chart.colorTheme : colorTheme }}
                    rows={filteredRows}
                    onEdit={onEditChart}
                    onDelete={onDeleteChart}
                    onToggleSpan={onToggleChartSpan}
                    onUpdateColor={onUpdateChartColor}
                  />
                ))}
              </motion.div>
            </AnimatePresence>
          )}
        </motion.div>
      )}
    </div>
  );
};

