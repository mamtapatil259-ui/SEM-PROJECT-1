import React from "react";
import { motion } from "motion/react";
import { TrendingUp, TrendingDown, Minus, Edit3, Trash2 } from "lucide-react";
import { KpiConfig, ColorTheme } from "../types";
import { calculateAggregation } from "../utils/dataEngine";
import { useAnimationConfig } from "../context/AnimationContext";
import { AnimatedCounter } from "./AnimatedCounter";

interface KpiCardProps {
  kpi: KpiConfig;
  rows: Record<string, any>[];
  onEdit?: (kpi: KpiConfig) => void;
  onDelete?: (id: string) => void;
  index?: number;
  colorTheme?: ColorTheme;
}

const THEME_KPI_STYLES: Record<ColorTheme, { border: string; bg: string; accentText: string; highlightBg: string; highlightBorder: string }> = {
  indigo: {
    border: "border-indigo-100 hover:border-indigo-200",
    bg: "bg-white",
    accentText: "text-indigo-600",
    highlightBg: "bg-gradient-to-br from-indigo-50/80 via-white to-indigo-50/40",
    highlightBorder: "border-indigo-200",
  },
  emerald: {
    border: "border-emerald-100 hover:border-emerald-200",
    bg: "bg-white",
    accentText: "text-emerald-600",
    highlightBg: "bg-gradient-to-br from-emerald-50/80 via-white to-emerald-50/40",
    highlightBorder: "border-emerald-200",
  },
  amber: {
    border: "border-amber-100 hover:border-amber-200",
    bg: "bg-white",
    accentText: "text-amber-600",
    highlightBg: "bg-gradient-to-br from-amber-50/80 via-white to-amber-50/40",
    highlightBorder: "border-amber-200",
  },
  cyan: {
    border: "border-cyan-100 hover:border-cyan-200",
    bg: "bg-white",
    accentText: "text-cyan-600",
    highlightBg: "bg-gradient-to-br from-cyan-50/80 via-white to-cyan-50/40",
    highlightBorder: "border-cyan-200",
  },
  rose: {
    border: "border-rose-100 hover:border-rose-200",
    bg: "bg-white",
    accentText: "text-rose-600",
    highlightBg: "bg-gradient-to-br from-rose-50/80 via-white to-rose-50/40",
    highlightBorder: "border-rose-200",
  },
  purple: {
    border: "border-purple-100 hover:border-purple-200",
    bg: "bg-white",
    accentText: "text-purple-600",
    highlightBg: "bg-gradient-to-br from-purple-50/80 via-white to-purple-50/40",
    highlightBorder: "border-purple-200",
  },
  slate: {
    border: "border-slate-200 hover:border-slate-300",
    bg: "bg-white",
    accentText: "text-slate-700",
    highlightBg: "bg-slate-50",
    highlightBorder: "border-slate-200",
  },
};

export const KpiCard: React.FC<KpiCardProps> = ({ kpi, rows, onEdit, onDelete, index = 0, colorTheme = "indigo" }) => {
  const rawVal = calculateAggregation(rows, kpi.column, kpi.aggregation);
  const { springTransition, cardHover, buttonHover, buttonTap, mode, isReduced } = useAnimationConfig();

  const isHighlight = index % 3 === 0;
  const themeStyle = THEME_KPI_STYLES[colorTheme] || THEME_KPI_STYLES.indigo;

  const renderTrendIcon = () => {
    if (kpi.trendDirection === "up") {
      return (
        <motion.div
          animate={isReduced ? {} : { y: [0, -2, 0] }}
          transition={{ repeat: Infinity, duration: 2, ease: "easeInOut" }}
        >
          <TrendingUp className="w-4 h-4 text-emerald-600 shrink-0" />
        </motion.div>
      );
    }
    if (kpi.trendDirection === "down") {
      return (
        <motion.div
          animate={isReduced ? {} : { y: [0, 2, 0] }}
          transition={{ repeat: Infinity, duration: 2, ease: "easeInOut" }}
        >
          <TrendingDown className="w-4 h-4 text-rose-600 shrink-0" />
        </motion.div>
      );
    }
    return <Minus className="w-4 h-4 shrink-0 text-slate-500" />;
  };

  const trendBadgeClass =
    kpi.trendDirection === "up"
      ? "bg-emerald-50 text-emerald-700 border-emerald-200"
      : kpi.trendDirection === "down"
      ? "bg-rose-50 text-rose-700 border-rose-200"
      : "bg-slate-100 text-slate-700 border-slate-200";

  const cardBgClass = isHighlight
    ? `${themeStyle.highlightBg} rounded-3xl border ${themeStyle.highlightBorder} p-6 shadow-xs text-slate-900`
    : `${themeStyle.bg} rounded-3xl border ${themeStyle.border} p-6 shadow-xs text-slate-900`;

  return (
    <motion.div
      layout="position"
      initial={isReduced ? { opacity: 0 } : { opacity: 0, y: 20, scale: 0.94 }}
      animate={isReduced ? { opacity: 1 } : { opacity: 1, y: 0, scale: 1 }}
      exit={isReduced ? { opacity: 0 } : { opacity: 0, scale: 0.9, y: 10 }}
      transition={
        isReduced
          ? { duration: 0 }
          : {
              ...springTransition(350, 25),
              delay: index * (mode === "snappy" ? 0.03 : 0.06),
            }
      }
      whileHover={cardHover}
      whileTap={buttonTap}
      className={`group relative transition-colors duration-200 flex flex-col justify-between cursor-default ${cardBgClass}`}
    >
      {/* Top Header */}
      <div className="flex items-start justify-between gap-2">
        <div>
          <span className="text-[11px] font-bold tracking-wider uppercase text-slate-500">
            {kpi.title}
          </span>
          <div className={`text-[10px] font-semibold mt-0.5 ${themeStyle.accentText}`}>
            {kpi.aggregation} of {kpi.column}
          </div>
        </div>

        <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity p-1 rounded-xl border bg-slate-100 border-slate-200">
          {onEdit && (
            <motion.button
              whileHover={buttonHover}
              whileTap={buttonTap}
              onClick={() => onEdit(kpi)}
              className="p-1 rounded transition-colors text-slate-600 hover:text-slate-900 hover:bg-white"
              title="Edit KPI"
            >
              <Edit3 className="w-3.5 h-3.5" />
            </motion.button>
          )}
          {onDelete && (
            <motion.button
              whileHover={buttonHover}
              whileTap={buttonTap}
              onClick={() => onDelete(kpi.id)}
              className="p-1 rounded transition-colors text-slate-600 hover:text-rose-600 hover:bg-white"
              title="Remove KPI"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </motion.button>
          )}
        </div>
      </div>

      {/* Main Value with Kinetic Smooth Counting */}
      <div className="my-3">
        <div className="text-3xl font-extrabold tracking-tight text-slate-900 flex items-center">
          <AnimatedCounter
            value={rawVal}
            format={kpi.format as any}
            prefix={kpi.prefix}
            suffix={kpi.suffix}
          />
        </div>
      </div>

      {/* Bottom Trend & Description */}
      <div className="flex items-center justify-between gap-2 pt-3 border-t border-slate-200/80">
        {kpi.trendLabel ? (
          <motion.div
            whileHover={isReduced ? {} : { scale: 1.05 }}
            className={`flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-semibold border ${trendBadgeClass}`}
          >
            {renderTrendIcon()}
            <span>{kpi.trendLabel}</span>
          </motion.div>
        ) : (
          <span className="text-[11px] font-medium text-slate-500">Live aggregate</span>
        )}
        {kpi.description && (
          <span className="text-[10px] truncate max-w-[120px] text-slate-500" title={kpi.description}>
            {kpi.description}
          </span>
        )}
      </div>
    </motion.div>
  );
};

