import React from "react";
import { motion } from "motion/react";
import { BarChart3, Table, Sparkles, Upload, Download, Palette, ShieldCheck, Database, DollarSign } from "lucide-react";
import { Dataset, ColorTheme } from "../types";
import { BrandLogo } from "./BrandLogo";
import { AnimationSettingsDropdown } from "./AnimationSettingsDropdown";
import { useAnimationConfig } from "../context/AnimationContext";

export type AppTab = "import_raw" | "kpi_scorecard" | "visualizations";

interface NavbarProps {
  currentDataset: Dataset | null;
  activeTab: AppTab;
  setActiveTab: (tab: AppTab) => void;
  onOpenIngestion: () => void;
  onAutoGenerate: () => void;
  isAutoGenerating: boolean;
  onOpenExport: () => void;
  colorTheme: ColorTheme;
  setColorTheme: (theme: ColorTheme) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentDataset,
  activeTab,
  setActiveTab,
  onOpenIngestion,
  onAutoGenerate,
  isAutoGenerating,
  onOpenExport,
  colorTheme,
  setColorTheme,
}) => {
  const { buttonHover, buttonTap, springTransition, isReduced } = useAnimationConfig();

  const themes: { id: ColorTheme; label: string; colorClass: string }[] = [
    { id: "indigo", label: "Indigo Modern", colorClass: "bg-indigo-600" },
    { id: "emerald", label: "Emerald Mint", colorClass: "bg-emerald-600" },
    { id: "amber", label: "Sunset Amber", colorClass: "bg-amber-600" },
    { id: "cyan", label: "Ocean Cyan", colorClass: "bg-cyan-600" },
    { id: "rose", label: "Rose Quartz", colorClass: "bg-rose-600" },
    { id: "purple", label: "Royal Purple", colorClass: "bg-purple-600" },
  ];

  const tabs: { id: AppTab; label: string; icon: React.ReactNode; activeColor: string }[] = [
    {
      id: "import_raw",
      label: "1. File Import & Raw Data",
      icon: <Upload className="w-4 h-4" />,
      activeColor: "bg-indigo-600 text-white shadow-indigo-600/30",
    },
    {
      id: "kpi_scorecard",
      label: "2. KPI Scorecard",
      icon: <DollarSign className="w-4 h-4" />,
      activeColor: "bg-emerald-600 text-white shadow-emerald-600/30",
    },
    {
      id: "visualizations",
      label: "3. Graphical Visualizations",
      icon: <BarChart3 className="w-4 h-4" />,
      activeColor: "bg-indigo-600 text-white shadow-indigo-600/30",
    },
  ];

  return (
    <header className="bg-slate-900/90 backdrop-blur-md border-b border-slate-800/80 text-slate-100 sticky top-0 z-40 shadow-xs">
      <div style={{ backgroundColor: "#fefefe" }} className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
        {/* Brand & Dataset Info */}
        <div className="flex items-center gap-3">
          <BrandLogo size="md" />
          <div>
            <div className="flex items-center gap-2">
              <h1 style={{ color: "#000000" }} className="font-extrabold text-lg tracking-tight text-slate-100">
                Auto <span className="text-indigo-400">DataDash</span>
              </h1>
            </div>
            {currentDataset ? (
              <div className="flex items-center gap-1.5 text-xs text-slate-400">
                <Database className="w-3 h-3 text-indigo-400" />
                <span style={{ borderColor: "#000000", color: "#131e2c" }} className="font-medium text-slate-200 truncate max-w-[180px]">{currentDataset.name}</span>
                <span style={{ color: "#070b13" }}>• {currentDataset.rows.length.toLocaleString()} rows</span>
              </div>
            ) : (
              <div className="flex items-center gap-1.5 text-xs text-indigo-300 font-semibold animate-pulse">
                <Sparkles className="w-3 h-3 text-amber-300" />
                <span>Welcome to Auto DataDash</span>
              </div>
            )}
          </div>
        </div>

        {/* Right Actions */}
        <div className="flex items-center gap-2.5">
          {currentDataset ? (
            <>
              {/* Auto-Generate Button */}
              <motion.button
                whileHover={{ scale: 1.03 }}
                whileTap={{ scale: 0.97 }}
                onClick={onAutoGenerate}
                disabled={isAutoGenerating}
                className="flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-semibold shadow-sm transition-all disabled:opacity-50"
                title="Automatically generate charts and KPI scorecards from this dataset"
              >
                <Sparkles className={`w-4 h-4 ${isAutoGenerating ? "animate-spin text-amber-300" : "text-amber-300"}`} />
                <span>{isAutoGenerating ? "Generating dashboard..." : "Generate Dashboard"}</span>
              </motion.button>
              {/* Animation Controls dropdown */}
              <AnimationSettingsDropdown />

              {/* Theme Palette dropdown */}
              <div className="relative group">
                <button
                  className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-colors flex items-center gap-1.5 text-xs font-medium"
                  title="Change Color Theme"
                >
                  <Palette className="w-4 h-4 text-indigo-400" />
                  <span className="hidden lg:inline capitalize">{colorTheme}</span>
                </button>
                <div className="absolute right-0 mt-2 w-48 bg-slate-900 border border-slate-800 rounded-xl shadow-xl p-2 hidden group-hover:block z-50">
                  <div className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider px-2 py-1">
                    Dashboard Theme
                  </div>
                  {themes.map((t) => (
                    <button
                      key={t.id}
                      onClick={() => setColorTheme(t.id)}
                      className={`w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-xs font-medium text-left transition-colors ${
                        colorTheme === t.id ? "bg-slate-800 text-slate-100 font-semibold" : "text-slate-400 hover:bg-slate-800/50 hover:text-slate-100"
                      }`}
                    >
                      <span className={`w-3 h-3 rounded-full ${t.colorClass}`} />
                      <span>{t.label}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Export Button */}
              <motion.button
                whileHover={buttonHover}
                whileTap={buttonTap}
                onClick={onOpenExport}
                className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-colors flex items-center gap-1.5 text-xs font-medium"
                title="Export Dashboard or Cleaned Data"
              >
                <Download className="w-4 h-4 text-emerald-400" />
                <span className="hidden lg:inline">Export</span>
              </motion.button>
            </>
          ) : (
            <AnimationSettingsDropdown />
          )}

          {/* Upload / Switch Dataset Button */}
          <motion.button
            whileHover={buttonHover}
            whileTap={buttonTap}
            onClick={onOpenIngestion}
            className="flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-sm font-medium transition-colors"
          >
            <Upload className="w-4 h-4 text-indigo-400" />
            <span>{currentDataset ? "Switch Dataset" : "Upload Dataset"}</span>
          </motion.button>
        </div>
      </div>

      {/* 3-Page Tab Bar with Kinetic Sliding Indicator */}
      {currentDataset && (
        <div className="bg-slate-950/90 border-t border-slate-800/80 px-4 sm:px-6 lg:px-8 py-2">
          <div style={{ backgroundColor: "#ffffff" }} className="max-w-7xl mx-auto flex items-center justify-start sm:justify-center gap-3 overflow-x-auto no-scrollbar p-1.5 rounded-xl relative">
            {tabs.map((tab) => {
              const isActive = activeTab === tab.id;
              return (
                <motion.button
                  key={tab.id}
                  whileHover={isReduced ? {} : { scale: 1.02 }}
                  whileTap={isReduced ? {} : { scale: 0.98 }}
                  onClick={() => setActiveTab(tab.id)}
                  className={`relative px-4 py-2 rounded-xl text-xs sm:text-sm font-bold whitespace-nowrap transition-colors flex items-center gap-2 cursor-pointer ${
                    isActive ? "text-white font-extrabold" : "text-slate-700 hover:text-slate-900 font-semibold"
                  }`}
                >
                  {isActive && (
                    <motion.div
                      layoutId="activeNavTabPill"
                      className={`absolute inset-0 rounded-xl shadow-md ${tab.activeColor}`}
                      transition={springTransition(420, 30)}
                    />
                  )}
                  <span className="relative z-10 flex items-center gap-2">
                    {tab.icon}
                    <span>{tab.label}</span>
                  </span>
                </motion.button>
              );
            })}
          </div>
        </div>
      )}
    </header>
  );
};

