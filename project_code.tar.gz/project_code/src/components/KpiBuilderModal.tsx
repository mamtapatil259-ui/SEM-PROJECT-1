import React, { useState, useEffect } from "react";
import { X, TrendingUp, Check, DollarSign } from "lucide-react";
import { KpiConfig, AggregationType, ColumnSchema } from "../types";

interface KpiBuilderModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (kpi: KpiConfig) => void;
  initialKpi?: KpiConfig | null;
  columns: ColumnSchema[];
}

export const KpiBuilderModal: React.FC<KpiBuilderModalProps> = ({
  isOpen,
  onClose,
  onSave,
  initialKpi,
  columns,
}) => {
  const [title, setTitle] = useState("New KPI Scorecard");
  const [column, setColumn] = useState("");
  const [aggregation, setAggregation] = useState<AggregationType>("SUM");
  const [format, setFormat] = useState<"currency" | "percentage" | "number" | "standard">("currency");
  const [description, setDescription] = useState("");
  const [trendLabel, setTrendLabel] = useState("");
  const [trendDirection, setTrendDirection] = useState<"up" | "down" | "neutral">("up");

  const numCols = columns.filter((c) => c.type === "number");

  useEffect(() => {
    if (initialKpi) {
      setTitle(initialKpi.title);
      setColumn(initialKpi.column);
      setAggregation(initialKpi.aggregation);
      setFormat(initialKpi.format);
      setDescription(initialKpi.description || "");
      setTrendLabel(initialKpi.trendLabel || "");
      setTrendDirection(initialKpi.trendDirection || "neutral");
    } else if (columns.length > 0) {
      const defaultCol = numCols[0]?.name || columns[0]?.name || "";
      setColumn(defaultCol);
      setTitle(`Total ${defaultCol}`);
    }
  }, [initialKpi, columns, isOpen]);

  if (!isOpen) return null;

  const handleSave = () => {
    if (!column) return;
    const newKpi: KpiConfig = {
      id: initialKpi?.id || `kpi-${Date.now()}`,
      title: title.trim() || `${aggregation} of ${column}`,
      column,
      aggregation,
      format,
      description: description.trim(),
      trendLabel: trendLabel.trim() || undefined,
      trendDirection,
    };
    onSave(newKpi);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden flex flex-col">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-900/50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-500/30">
              <DollarSign className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">
                {initialKpi ? "Edit Your KPI" : "Make Your KPI"}
              </h2>
              <p className="text-xs text-slate-400">Configure metric, aggregation, format and trend badge</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Form */}
        <div className="p-6 space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
              1. Metric Column
            </label>
            <select
              value={column}
              onChange={(e) => {
                setColumn(e.target.value);
                if (!initialKpi) setTitle(`Total ${e.target.value}`);
              }}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
            >
              <option value="">Select column...</option>
              {columns.map((c) => (
                <option key={c.name} value={c.name}>
                  {c.name} ({c.type})
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                2. Aggregation
              </label>
              <select
                value={aggregation}
                onChange={(e) => setAggregation(e.target.value as AggregationType)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
              >
                <option value="SUM">SUM</option>
                <option value="AVERAGE">AVERAGE</option>
                <option value="COUNT">COUNT ROWS</option>
                <option value="MAX">MAXIMUM</option>
                <option value="MIN">MINIMUM</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                3. Display Format
              </label>
              <select
                value={format}
                onChange={(e) => setFormat(e.target.value as any)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
              >
                <option value="currency">Currency ($)</option>
                <option value="percentage">Percentage (%)</option>
                <option value="number">Formatted Number</option>
                <option value="standard">Standard Raw</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">
              4. KPI Title
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Gross Revenue USD"
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">
              5. Description / Subtext
            </label>
            <input
              type="text"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="e.g. Total order volume across all regions"
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">
                6. Trend Note (Optional)
              </label>
              <input
                type="text"
                value={trendLabel}
                onChange={(e) => setTrendLabel(e.target.value)}
                placeholder="e.g. +14.2% vs last month"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                7. Trend Color
              </label>
              <select
                value={trendDirection}
                onChange={(e) => setTrendDirection(e.target.value as any)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
              >
                <option value="up">Positive Green (Up)</option>
                <option value="down">Negative Red (Down)</option>
                <option value="neutral">Neutral Slate</option>
              </select>
            </div>
          </div>
        </div>

        {/* Footer actions */}
        <div className="px-6 py-4 border-t border-slate-800 bg-slate-900/80 flex items-center justify-end gap-3">
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition-colors"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={handleSave}
            disabled={!column}
            className="flex items-center gap-2 px-6 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold shadow-lg shadow-emerald-600/30 transition-all disabled:opacity-40"
          >
            <Check className="w-4 h-4" />
            <span>{initialKpi ? "Update Your KPI" : "Make Your KPI"}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
