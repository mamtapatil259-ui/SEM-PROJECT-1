import React, { useState, useMemo, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Table,
  ArrowUpDown,
  Download,
  Search,
  Plus,
  Trash2,
  Edit3,
  Copy,
  RotateCcw,
  Sparkles,
  Check,
  X,
  Columns,
  Wand2,
  CheckCircle2,
  AlertCircle,
  FileSpreadsheet,
  Save,
  Filter
} from "lucide-react";
import { Dataset } from "../types";
import Papa from "papaparse";

interface DataExplorerViewProps {
  dataset: Dataset;
  onUpdateDatasetRows?: (newRows: Record<string, any>[], actionNote: string) => void;
  onResetToOriginal?: () => void;
  isCleaned?: boolean;
}

export const DataExplorerView: React.FC<DataExplorerViewProps> = ({
  dataset,
  onUpdateDatasetRows,
  onResetToOriginal,
  isCleaned = false,
}) => {
  // Table search, sort, pagination
  const [search, setSearch] = useState("");
  const [sortCol, setSortCol] = useState<string | null>(null);
  const [sortDir, setSortDir] = useState<"asc" | "desc">("asc");
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(25);

  // Inline cell editing state
  const [cellEdit, setCellEdit] = useState<{ rowIndex: number; colName: string; value: string } | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Modals state
  const [isAddRowOpen, setIsAddRowOpen] = useState(false);
  const [newRowData, setNewRowData] = useState<Record<string, string>>({});

  const [editingRowIndex, setEditingRowIndex] = useState<number | null>(null);
  const [rowEditData, setRowEditData] = useState<Record<string, any>>({});

  const [isAddColOpen, setIsAddColOpen] = useState(false);
  const [newColName, setNewColName] = useState("");
  const [newColDefault, setNewColDefault] = useState("");

  const [isRenameColOpen, setIsRenameColOpen] = useState<string | null>(null);
  const [renameColValue, setRenameColValue] = useState("");

  const [isBulkToolsOpen, setIsBulkToolsOpen] = useState(false);
  const [bulkCol, setBulkCol] = useState<string>("");
  const [bulkFillVal, setBulkFillVal] = useState<string>("0");
  const [findText, setFindText] = useState("");
  const [replaceText, setReplaceText] = useState("");

  // Notification note toast
  const [actionToast, setActionToast] = useState<string | null>(null);

  const triggerToast = (msg: string) => {
    setActionToast(msg);
    setTimeout(() => {
      setActionToast(null);
    }, 3500);
  };

  // Focus input when editing cell starts
  useEffect(() => {
    if (cellEdit && inputRef.current) {
      inputRef.current.focus();
      inputRef.current.select();
    }
  }, [cellEdit]);

  // Filter and Sort rows
  const processedRows = useMemo(() => {
    let rows = dataset.rows.map((r, idx) => ({ ...r, __originalIndex: idx }));
    if (search.trim()) {
      const q = search.toLowerCase().trim();
      rows = rows.filter((r) =>
        Object.entries(r).some(
          ([k, val]) => k !== "__originalIndex" && val !== null && val !== undefined && String(val).toLowerCase().includes(q)
        )
      );
    }
    if (sortCol) {
      rows.sort((a, b) => {
        const valA = a[sortCol];
        const valB = b[sortCol];
        if (valA === valB) return 0;
        if (valA === null || valA === undefined) return 1;
        if (valB === null || valB === undefined) return -1;
        if (typeof valA === "number" && typeof valB === "number") {
          return sortDir === "asc" ? valA - valB : valB - valA;
        }
        return sortDir === "asc"
          ? String(valA).localeCompare(String(valB))
          : String(valB).localeCompare(String(valA));
      });
    }
    return rows;
  }, [dataset.rows, search, sortCol, sortDir]);

  const totalPages = Math.ceil(processedRows.length / pageSize) || 1;
  const paginatedRows = useMemo(() => {
    const start = (page - 1) * pageSize;
    return processedRows.slice(start, start + pageSize);
  }, [processedRows, page, pageSize]);

  const handleSort = (col: string) => {
    if (sortCol === col) {
      setSortDir(sortDir === "asc" ? "desc" : "asc");
    } else {
      setSortCol(col);
      setSortDir("asc");
    }
  };

  // Inline cell save
  const handleSaveCell = () => {
    if (!cellEdit || !onUpdateDatasetRows) return;
    const { rowIndex, colName, value } = cellEdit;
    const colType = dataset.columns.find((c) => c.name === colName)?.type;
    let parsedVal: any = value;

    if (colType === "number") {
      const trimmed = value.trim();
      parsedVal = trimmed === "" ? null : Number(trimmed);
      if (isNaN(parsedVal)) parsedVal = value;
    } else if (colType === "boolean") {
      parsedVal = value === "true" || value === "1" || value.toLowerCase() === "yes";
    }

    const updatedRows = [...dataset.rows];
    updatedRows[rowIndex] = {
      ...updatedRows[rowIndex],
      [colName]: parsedVal,
    };

    onUpdateDatasetRows(updatedRows, `Edited cell at row ${rowIndex + 1}, column "${colName}"`);
    triggerToast(`Updated cell in row ${rowIndex + 1}`);
    setCellEdit(null);
  };

  // Row operations
  const handleDeleteRow = (targetIndex: number) => {
    if (!onUpdateDatasetRows) return;
    const updatedRows = dataset.rows.filter((_, idx) => idx !== targetIndex);
    onUpdateDatasetRows(updatedRows, `Deleted row #${targetIndex + 1}`);
    triggerToast(`Row #${targetIndex + 1} deleted`);
  };

  const handleDuplicateRow = (targetIndex: number) => {
    if (!onUpdateDatasetRows) return;
    const targetRow = { ...dataset.rows[targetIndex] };
    const updatedRows = [...dataset.rows];
    updatedRows.splice(targetIndex + 1, 0, targetRow);
    onUpdateDatasetRows(updatedRows, `Duplicated row #${targetIndex + 1}`);
    triggerToast(`Row #${targetIndex + 1} duplicated`);
  };

  // Modal Add Row
  const handleAddRowSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!onUpdateDatasetRows) return;

    const rowObj: Record<string, any> = {};
    dataset.columns.forEach((col) => {
      const rawVal = newRowData[col.name] ?? "";
      if (col.type === "number") {
        rowObj[col.name] = rawVal.trim() === "" ? 0 : Number(rawVal) || 0;
      } else if (col.type === "boolean") {
        rowObj[col.name] = rawVal === "true";
      } else {
        rowObj[col.name] = rawVal;
      }
    });

    const updatedRows = [rowObj, ...dataset.rows];
    onUpdateDatasetRows(updatedRows, "Added new raw data row");
    triggerToast("New row added to dataset");
    setIsAddRowOpen(false);
    setNewRowData({});
  };

  // Modal Edit Row
  const handleOpenEditRowModal = (rowIndex: number) => {
    setEditingRowIndex(rowIndex);
    setRowEditData({ ...dataset.rows[rowIndex] });
  };

  const handleSaveRowEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingRowIndex === null || !onUpdateDatasetRows) return;

    const updatedRows = [...dataset.rows];
    updatedRows[editingRowIndex] = { ...rowEditData };

    onUpdateDatasetRows(updatedRows, `Updated raw data row #${editingRowIndex + 1}`);
    triggerToast(`Saved updates for row #${editingRowIndex + 1}`);
    setEditingRowIndex(null);
    setRowEditData({});
  };

  // Add Column
  const handleAddColumnSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const colName = newColName.trim();
    if (!colName || !onUpdateDatasetRows) return;

    const updatedRows = dataset.rows.map((r) => ({
      ...r,
      [colName]: newColDefault || null,
    }));

    onUpdateDatasetRows(updatedRows, `Added new column "${colName}"`);
    triggerToast(`Added column "${colName}"`);
    setIsAddColOpen(false);
    setNewColName("");
    setNewColDefault("");
  };

  // Delete Column
  const handleDeleteColumn = (colName: string) => {
    if (!onUpdateDatasetRows) return;
    const updatedRows = dataset.rows.map((r) => {
      const copy = { ...r };
      delete copy[colName];
      return copy;
    });
    onUpdateDatasetRows(updatedRows, `Deleted column "${colName}"`);
    triggerToast(`Column "${colName}" deleted`);
  };

  // Rename Column
  const handleRenameColumnSubmit = (oldName: string) => {
    const newName = renameColValue.trim();
    if (!newName || newName === oldName || !onUpdateDatasetRows) return;

    const updatedRows = dataset.rows.map((r) => {
      const copy: Record<string, any> = {};
      Object.keys(r).forEach((k) => {
        if (k === oldName) {
          copy[newName] = r[k];
        } else {
          copy[k] = r[k];
        }
      });
      return copy;
    });

    onUpdateDatasetRows(updatedRows, `Renamed column "${oldName}" to "${newName}"`);
    triggerToast(`Column renamed to "${newName}"`);
    setIsRenameColOpen(null);
    setRenameColValue("");
  };

  // Bulk Clean: Fill Nulls
  const handleFillNulls = () => {
    if (!bulkCol || !onUpdateDatasetRows) return;
    const colType = dataset.columns.find((c) => c.name === bulkCol)?.type;
    let fillVal: any = bulkFillVal;
    if (colType === "number") fillVal = Number(bulkFillVal) || 0;

    let affectedCount = 0;
    const updatedRows = dataset.rows.map((r) => {
      const val = r[bulkCol];
      if (val === null || val === undefined || String(val).trim() === "") {
        affectedCount++;
        return { ...r, [bulkCol]: fillVal };
      }
      return r;
    });

    onUpdateDatasetRows(updatedRows, `Filled nulls in "${bulkCol}" with ${fillVal}`);
    triggerToast(`Replaced ${affectedCount} null cells in "${bulkCol}"`);
  };

  // Bulk Clean: Search & Replace
  const handleSearchReplace = () => {
    if (!findText.trim() || !onUpdateDatasetRows) return;
    let affectedCount = 0;

    const updatedRows = dataset.rows.map((r) => {
      const newRow = { ...r };
      Object.keys(newRow).forEach((k) => {
        if (!bulkCol || bulkCol === k) {
          const valStr = String(newRow[k] ?? "");
          if (valStr.includes(findText)) {
            newRow[k] = valStr.replaceAll(findText, replaceText);
            affectedCount++;
          }
        }
      });
      return newRow;
    });

    onUpdateDatasetRows(updatedRows, `Replaced "${findText}" with "${replaceText}"`);
    triggerToast(`Replaced ${affectedCount} instances of "${findText}"`);
  };

  // Export CSV
  const handleExportCsv = () => {
    const csv = Papa.unparse(dataset.rows);
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `${dataset.name.toLowerCase().replace(/\s+/g, "_")}_raw_edited.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner with Quick Actions & Data Metrics */}
      <div
        style={{ color: "#000000", borderColor: "#ffffff", backgroundColor: "#ffffff" }}
        className="bg-white border border-slate-200 rounded-3xl p-5 shadow-sm text-slate-900 flex flex-wrap items-center justify-between gap-4"
      >
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-indigo-600/20 text-indigo-400 border border-indigo-500/30 flex items-center justify-center">
            <FileSpreadsheet className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 style={{ color: "#000000" }} className="font-bold text-slate-900 text-sm">{dataset.name}</h3>
              {isCleaned && (
                <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3" /> Modified
                </span>
              )}
            </div>
            <p style={{ color: "#112a42" }} className="text-xs text-slate-600">
              {dataset.rows.length.toLocaleString()} total rows • {dataset.columns.length} columns • Click any cell to edit raw data
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Add Row Button */}
          <motion.button
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.97 }}
            onClick={() => {
              setNewRowData({});
              setIsAddRowOpen(true);
            }}
            className="px-3.5 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold flex items-center gap-1.5 shadow-sm transition-all"
          >
            <Plus className="w-4 h-4" />
            <span>Add New Row</span>
          </motion.button>

          {/* Add Column Button */}
          <motion.button
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.97 }}
            onClick={() => {
              setNewColName("");
              setNewColDefault("");
              setIsAddColOpen(true);
            }}
            className="px-3.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold flex items-center gap-1.5 transition-all"
          >
            <Columns className="w-4 h-4 text-purple-400" />
            <span>Add Column</span>
          </motion.button>

          {/* Data Hygiene / Bulk Clean Tools Toggle */}
          <motion.button
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.97 }}
            onClick={() => setIsBulkToolsOpen(!isBulkToolsOpen)}
            className={`px-3.5 py-1.5 rounded-xl border text-xs font-semibold flex items-center gap-1.5 transition-all ${
              isBulkToolsOpen
                ? "bg-amber-500/20 text-amber-300 border-amber-500/40"
                : "bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700"
            }`}
          >
            <Wand2 className="w-4 h-4 text-amber-400" />
            <span>Bulk Tools</span>
          </motion.button>

          {/* Download CSV */}
          <motion.button
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.97 }}
            onClick={handleExportCsv}
            className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold flex items-center gap-1.5 transition-all"
            title="Export edited raw data as CSV"
          >
            <Download className="w-4 h-4 text-emerald-400" />
            <span>Export CSV</span>
          </motion.button>

          {/* Reset to Original Dataset */}
          {onResetToOriginal && isCleaned && (
            <motion.button
              whileHover={{ scale: 1.03 }}
              whileTap={{ scale: 0.97 }}
              onClick={onResetToOriginal}
              className="px-3 py-1.5 rounded-xl bg-rose-950/40 hover:bg-rose-900/60 text-rose-300 border border-rose-800/50 text-xs font-semibold flex items-center gap-1.5 transition-all"
              title="Reset dataset back to original state"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset Raw Data</span>
            </motion.button>
          )}
        </div>
      </div>

      {/* Action Note Toast Banner */}
      <AnimatePresence>
        {actionToast && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="bg-emerald-900/80 border border-emerald-500/50 text-emerald-100 p-3 rounded-2xl text-xs font-semibold flex items-center justify-between shadow-lg"
          >
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>{actionToast}</span>
            </div>
            <button onClick={() => setActionToast(null)} className="text-emerald-300 hover:text-white">
              <X className="w-4 h-4" />
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Bulk Cleaning & Transformation Panel */}
      <AnimatePresence>
        {isBulkToolsOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden"
          >
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-lg text-slate-100 space-y-4">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div className="flex items-center gap-2">
                  <Wand2 className="w-4 h-4 text-amber-400" />
                  <h4 className="font-bold text-xs uppercase tracking-wider text-slate-200">
                    Bulk Data Hygiene & Search-Replace
                  </h4>
                </div>
                <button
                  onClick={() => setIsBulkToolsOpen(false)}
                  className="text-slate-400 hover:text-white text-xs"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* 1. Fill Null Values */}
                <div className="bg-slate-950/60 p-4 rounded-2xl border border-slate-800 space-y-3">
                  <h5 className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
                    Fill Missing / Null Cells
                  </h5>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-[10px] font-semibold text-slate-400 mb-1">Target Column</label>
                      <select
                        value={bulkCol}
                        onChange={(e) => setBulkCol(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-700 rounded-xl px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-indigo-500"
                      >
                        <option value="">Select Column...</option>
                        {dataset.columns.map((c) => (
                          <option key={c.name} value={c.name}>
                            {c.name} ({c.nullCount} nulls)
                          </option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="block text-[10px] font-semibold text-slate-400 mb-1">Replace Null With</label>
                      <input
                        type="text"
                        value={bulkFillVal}
                        onChange={(e) => setBulkFillVal(e.target.value)}
                        placeholder="e.g. 0 or N/A"
                        className="w-full bg-slate-900 border border-slate-700 rounded-xl px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-indigo-500"
                      />
                    </div>
                  </div>
                  <button
                    onClick={handleFillNulls}
                    disabled={!bulkCol}
                    className="w-full py-1.5 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 text-white rounded-xl text-xs font-semibold transition-all"
                  >
                    Apply Null Replacement
                  </button>
                </div>

                {/* 2. Global Search & Replace */}
                <div className="bg-slate-950/60 p-4 rounded-2xl border border-slate-800 space-y-3">
                  <h5 className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                    <Search className="w-3.5 h-3.5 text-purple-400" />
                    Find & Replace Text
                  </h5>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-[10px] font-semibold text-slate-400 mb-1">Find Value</label>
                      <input
                        type="text"
                        value={findText}
                        onChange={(e) => setFindText(e.target.value)}
                        placeholder="Text to find..."
                        className="w-full bg-slate-900 border border-slate-700 rounded-xl px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-indigo-500"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-semibold text-slate-400 mb-1">Replace With</label>
                      <input
                        type="text"
                        value={replaceText}
                        onChange={(e) => setReplaceText(e.target.value)}
                        placeholder="New value..."
                        className="w-full bg-slate-900 border border-slate-700 rounded-xl px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-indigo-500"
                      />
                    </div>
                  </div>
                  <button
                    onClick={handleSearchReplace}
                    disabled={!findText.trim()}
                    className="w-full py-1.5 bg-purple-600 hover:bg-purple-500 disabled:opacity-40 text-white rounded-xl text-xs font-semibold transition-all"
                  >
                    Execute Search & Replace
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Raw Data Table Explorer */}
      <div className="bg-white border border-slate-200 rounded-3xl shadow-sm overflow-hidden">
        <div className="p-5 border-b border-slate-200 flex flex-wrap items-center justify-between gap-4 bg-slate-50/80">
          <div className="flex items-center gap-2">
            <Table className="w-5 h-5 text-indigo-600" />
            <h3 className="font-bold text-slate-900 text-base">Editable Data Grid</h3>
            <span className="text-xs text-slate-500 font-medium">
              ({processedRows.length.toLocaleString()} of {dataset.rows.length.toLocaleString()} rows)
            </span>
          </div>

          <div className="flex items-center gap-3">
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={search}
                onChange={(e) => {
                  setSearch(e.target.value);
                  setPage(1);
                }}
                placeholder="Search raw cells..."
                className="bg-white border border-slate-200 rounded-xl pl-8 pr-3 py-1.5 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:border-indigo-500 shadow-sm"
              />
            </div>

            <select
              value={pageSize}
              onChange={(e) => {
                setPageSize(Number(e.target.value));
                setPage(1);
              }}
              className="bg-white border border-slate-200 rounded-xl px-2.5 py-1.5 text-xs text-slate-800 focus:outline-none focus:border-indigo-500 shadow-sm font-medium"
            >
              <option value={25}>25 per page</option>
              <option value={50}>50 per page</option>
              <option value={100}>100 per page</option>
            </select>
          </div>
        </div>

        {/* Table wrapper */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-700 border-collapse">
            <thead className="bg-slate-100 text-slate-600 uppercase tracking-wider text-[11px] border-b border-slate-200 font-bold select-none">
              <tr>
                <th className="py-3 px-3 text-slate-400 w-12 text-center">#</th>
                {dataset.columns.map((col) => (
                  <th key={col.name} className="py-3 px-4 border-r border-slate-200/60 whitespace-nowrap group">
                    <div className="flex items-center justify-between gap-2">
                      <div
                        onClick={() => handleSort(col.name)}
                        className="flex items-center gap-1.5 cursor-pointer hover:text-indigo-600 transition-colors"
                      >
                        <span>{col.name}</span>
                        <ArrowUpDown
                          className={`w-3 h-3 ${sortCol === col.name ? "text-indigo-600" : "text-slate-400"}`}
                        />
                      </div>

                      {/* Column Header Action Popup / Edit */}
                      <div className="opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-1">
                        <button
                          onClick={() => {
                            setIsRenameColOpen(col.name);
                            setRenameColValue(col.name);
                          }}
                          className="p-1 rounded text-slate-400 hover:text-slate-900 hover:bg-slate-200"
                          title={`Rename column "${col.name}"`}
                        >
                          <Edit3 className="w-3 h-3" />
                        </button>
                        <button
                          onClick={() => handleDeleteColumn(col.name)}
                          className="p-1 rounded text-slate-400 hover:text-rose-600 hover:bg-slate-200"
                          title={`Delete column "${col.name}"`}
                        >
                          <Trash2 className="w-3 h-3" />
                        </button>
                      </div>
                    </div>
                  </th>
                ))}
                <th className="py-3 px-3 text-center text-slate-500 w-24">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {paginatedRows.length === 0 ? (
                <tr>
                  <td colSpan={dataset.columns.length + 2} className="py-12 text-center text-slate-400">
                    No records match your search criteria.
                  </td>
                </tr>
              ) : (
                paginatedRows.map((row, rIdx) => {
                  const actualRowNumber = (page - 1) * pageSize + rIdx + 1;
                  const originalRowIdx = row.__originalIndex;

                  return (
                    <tr key={originalRowIdx} className="hover:bg-indigo-50/40 transition-colors group">
                      <td className="py-2.5 px-3 text-slate-400 font-mono text-center text-[11px]">
                        {actualRowNumber}
                      </td>

                      {dataset.columns.map((col) => {
                        const val = row[col.name];
                        const isNull = val === null || val === undefined || String(val).trim() === "";
                        const isEditingThisCell =
                          cellEdit?.rowIndex === originalRowIdx && cellEdit?.colName === col.name;

                        return (
                          <td
                            key={col.name}
                            onClick={() => {
                              if (!isEditingThisCell) {
                                setCellEdit({
                                  rowIndex: originalRowIdx,
                                  colName: col.name,
                                  value: val === null || val === undefined ? "" : String(val),
                                });
                              }
                            }}
                            className={`py-2.5 px-4 whitespace-nowrap cursor-pointer transition-colors relative ${
                              isEditingThisCell ? "bg-indigo-100/80 outline-2 outline-indigo-500" : "hover:bg-indigo-100/30"
                            }`}
                          >
                            {isEditingThisCell ? (
                              <div className="flex items-center gap-1">
                                <input
                                  ref={inputRef}
                                  type="text"
                                  value={cellEdit.value}
                                  onChange={(e) =>
                                    setCellEdit({ ...cellEdit, value: e.target.value })
                                  }
                                  onKeyDown={(e) => {
                                    if (e.key === "Enter") handleSaveCell();
                                    if (e.key === "Escape") setCellEdit(null);
                                  }}
                                  className="w-full bg-white border border-indigo-400 rounded-lg px-2 py-1 text-xs text-slate-900 focus:outline-none shadow-inner"
                                />
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    handleSaveCell();
                                  }}
                                  className="p-1 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700"
                                  title="Save edit"
                                >
                                  <Check className="w-3.5 h-3.5" />
                                </button>
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    setCellEdit(null);
                                  }}
                                  className="p-1 bg-slate-200 text-slate-700 rounded-lg hover:bg-slate-300"
                                  title="Cancel"
                                >
                                  <X className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            ) : (
                              <div className="flex items-center justify-between gap-2">
                                {isNull ? (
                                  <span className="text-amber-600 italic text-[10px] bg-amber-50 px-1.5 py-0.5 rounded border border-amber-200">
                                    null
                                  </span>
                                ) : typeof val === "number" ? (
                                  <span className="font-mono text-indigo-700 font-medium">
                                    {val.toLocaleString()}
                                  </span>
                                ) : typeof val === "boolean" ? (
                                  <span
                                    className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                                      val
                                        ? "bg-emerald-50 text-emerald-700 border border-emerald-200"
                                        : "bg-rose-50 text-rose-700 border border-rose-200"
                                    }`}
                                  >
                                    {String(val)}
                                  </span>
                                ) : (
                                  <span className="text-slate-800">{String(val)}</span>
                                )}

                                <Edit3 className="w-3 h-3 text-slate-300 opacity-0 group-hover:opacity-100 transition-opacity shrink-0" />
                              </div>
                            )}
                          </td>
                        );
                      })}

                      {/* Actions Column */}
                      <td className="py-2.5 px-3 text-center whitespace-nowrap">
                        <div className="flex items-center justify-center gap-1">
                          {/* Edit Row in Modal */}
                          <button
                            onClick={() => handleOpenEditRowModal(originalRowIdx)}
                            className="p-1 rounded text-slate-400 hover:text-indigo-600 hover:bg-slate-200 transition-colors"
                            title="Edit full row"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                          </button>
                          {/* Duplicate Row */}
                          <button
                            onClick={() => handleDuplicateRow(originalRowIdx)}
                            className="p-1 rounded text-slate-400 hover:text-purple-600 hover:bg-slate-200 transition-colors"
                            title="Duplicate row"
                          >
                            <Copy className="w-3.5 h-3.5" />
                          </button>
                          {/* Delete Row */}
                          <button
                            onClick={() => handleDeleteRow(originalRowIdx)}
                            className="p-1 rounded text-slate-400 hover:text-rose-600 hover:bg-slate-200 transition-colors"
                            title="Delete row"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination Footer */}
        <div className="p-4 border-t border-slate-200 bg-slate-50/80 flex items-center justify-between text-xs text-slate-600">
          <div>
            Page <strong className="text-slate-900">{page}</strong> of{" "}
            <strong className="text-slate-900">{totalPages}</strong>
          </div>
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              disabled={page === 1}
              className="px-3.5 py-1.5 rounded-xl bg-white border border-slate-200 hover:bg-slate-100 text-slate-700 disabled:opacity-30 disabled:cursor-not-allowed transition-colors font-medium shadow-sm"
            >
              Previous
            </button>
            <button
              onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
              disabled={page === totalPages}
              className="px-3.5 py-1.5 rounded-xl bg-white border border-slate-200 hover:bg-slate-100 text-slate-700 disabled:opacity-30 disabled:cursor-not-allowed transition-colors font-medium shadow-sm"
            >
              Next
            </button>
          </div>
        </div>
      </div>

      {/* MODAL: Add New Row */}
      <AnimatePresence>
        {isAddRowOpen && (
          <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white border border-slate-200 rounded-3xl max-w-lg w-full p-6 shadow-2xl space-y-5 overflow-hidden"
            >
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <div className="flex items-center gap-2">
                  <Plus className="w-5 h-5 text-indigo-600" />
                  <h3 className="font-bold text-slate-900 text-base">Add New Raw Data Row</h3>
                </div>
                <button
                  onClick={() => setIsAddRowOpen(false)}
                  className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleAddRowSubmit} className="space-y-4 max-h-[60vh] overflow-y-auto pr-1">
                {dataset.columns.map((col) => (
                  <div key={col.name}>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      {col.name} <span className="text-slate-400 font-normal">({col.type})</span>
                    </label>
                    <input
                      type={col.type === "number" ? "number" : "text"}
                      step="any"
                      value={newRowData[col.name] ?? ""}
                      onChange={(e) => setNewRowData({ ...newRowData, [col.name]: e.target.value })}
                      placeholder={`Enter ${col.name}...`}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:outline-none focus:border-indigo-500"
                    />
                  </div>
                ))}

                <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
                  <button
                    type="button"
                    onClick={() => setIsAddRowOpen(false)}
                    className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow-sm"
                  >
                    Insert Row
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* MODAL: Edit Full Row */}
      <AnimatePresence>
        {editingRowIndex !== null && (
          <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white border border-slate-200 rounded-3xl max-w-lg w-full p-6 shadow-2xl space-y-5 overflow-hidden"
            >
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <div className="flex items-center gap-2">
                  <Edit3 className="w-5 h-5 text-indigo-600" />
                  <h3 className="font-bold text-slate-900 text-base">
                    Edit Row #{editingRowIndex + 1}
                  </h3>
                </div>
                <button
                  onClick={() => setEditingRowIndex(null)}
                  className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleSaveRowEdit} className="space-y-4 max-h-[60vh] overflow-y-auto pr-1">
                {dataset.columns.map((col) => (
                  <div key={col.name}>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      {col.name} <span className="text-slate-400 font-normal">({col.type})</span>
                    </label>
                    <input
                      type={col.type === "number" ? "number" : "text"}
                      step="any"
                      value={rowEditData[col.name] ?? ""}
                      onChange={(e) => setRowEditData({ ...rowEditData, [col.name]: e.target.value })}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:outline-none focus:border-indigo-500 font-medium"
                    />
                  </div>
                ))}

                <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
                  <button
                    type="button"
                    onClick={() => setEditingRowIndex(null)}
                    className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow-sm flex items-center gap-1.5"
                  >
                    <Save className="w-4 h-4" />
                    <span>Save Changes</span>
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* MODAL: Add Column */}
      <AnimatePresence>
        {isAddColOpen && (
          <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white border border-slate-200 rounded-3xl max-w-md w-full p-6 shadow-2xl space-y-4"
            >
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <div className="flex items-center gap-2">
                  <Columns className="w-5 h-5 text-purple-600" />
                  <h3 className="font-bold text-slate-900 text-base">Add New Column</h3>
                </div>
                <button
                  onClick={() => setIsAddColOpen(false)}
                  className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleAddColumnSubmit} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Column Header Name</label>
                  <input
                    type="text"
                    value={newColName}
                    onChange={(e) => setNewColName(e.target.value)}
                    placeholder="e.g. SalesTax or Status"
                    required
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:outline-none focus:border-indigo-500 font-medium"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Default Value for Existing Rows (Optional)
                  </label>
                  <input
                    type="text"
                    value={newColDefault}
                    onChange={(e) => setNewColDefault(e.target.value)}
                    placeholder="e.g. 0 or Active"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:outline-none focus:border-indigo-500 font-medium"
                  />
                </div>

                <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
                  <button
                    type="button"
                    onClick={() => setIsAddColOpen(false)}
                    className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-semibold shadow-sm"
                  >
                    Create Column
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* MODAL: Rename Column */}
      <AnimatePresence>
        {isRenameColOpen && (
          <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white border border-slate-200 rounded-3xl max-w-md w-full p-6 shadow-2xl space-y-4"
            >
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <div className="flex items-center gap-2">
                  <Edit3 className="w-5 h-5 text-indigo-600" />
                  <h3 className="font-bold text-slate-900 text-base">Rename Column "{isRenameColOpen}"</h3>
                </div>
                <button
                  onClick={() => setIsRenameColOpen(null)}
                  className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  handleRenameColumnSubmit(isRenameColOpen);
                }}
                className="space-y-4"
              >
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">New Header Name</label>
                  <input
                    type="text"
                    value={renameColValue}
                    onChange={(e) => setRenameColValue(e.target.value)}
                    required
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:outline-none focus:border-indigo-500 font-medium"
                  />
                </div>

                <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
                  <button
                    type="button"
                    onClick={() => setIsRenameColOpen(null)}
                    className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow-sm"
                  >
                    Update Column Name
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
