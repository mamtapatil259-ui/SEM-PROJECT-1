import React, { useState } from "react";
import { Search, Filter, X, RotateCcw, ChevronDown, ArrowUpDown, SlidersHorizontal } from "lucide-react";
import { ColumnSchema, FilterState } from "../types";

interface FilterBarProps {
  columns: ColumnSchema[];
  filterState: FilterState;
  onFilterChange: (newFilters: FilterState) => void;
  totalRowsCount: number;
  filteredRowsCount: number;
}

export const FilterBar: React.FC<FilterBarProps> = ({
  columns,
  filterState,
  onFilterChange,
  totalRowsCount,
  filteredRowsCount,
}) => {
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);
  const [rangeInputs, setRangeInputs] = useState<Record<string, { min: string; max: string }>>({});

  const handleSearchChange = (q: string) => {
    onFilterChange({
      ...filterState,
      searchQuery: q,
    });
  };

  const handleToggleCategory = (columnName: string, value: string) => {
    const current = filterState.categoricalFilters[columnName] || [];
    const next = current.includes(value)
      ? current.filter((v) => v !== value)
      : [...current, value];

    onFilterChange({
      ...filterState,
      categoricalFilters: {
        ...filterState.categoricalFilters,
        [columnName]: next,
      },
    });
  };

  const handleApplyRange = (colName: string, minStr: string, maxStr: string) => {
    const minVal = minStr !== "" ? Number(minStr) : undefined;
    const maxVal = maxStr !== "" ? Number(maxStr) : undefined;

    const newRanges = { ...filterState.numericalRanges };
    if (minVal !== undefined && maxVal !== undefined && !isNaN(minVal) && !isNaN(maxVal)) {
      newRanges[colName] = [minVal, maxVal];
    } else {
      delete newRanges[colName];
    }

    onFilterChange({
      ...filterState,
      numericalRanges: newRanges,
    });
  };

  const handleSortColumnChange = (colName: string) => {
    onFilterChange({
      ...filterState,
      sortColumn: colName ? colName : undefined,
      sortDirection: colName ? (filterState.sortDirection || "asc") : undefined,
    });
  };

  const handleToggleSortDirection = () => {
    onFilterChange({
      ...filterState,
      sortDirection: filterState.sortDirection === "asc" ? "desc" : "asc",
    });
  };

  const handleReset = () => {
    onFilterChange({
      searchQuery: "",
      categoricalFilters: {},
      numericalRanges: {},
      sortColumn: undefined,
      sortDirection: undefined,
    });
    setActiveDropdown(null);
    setRangeInputs({});
  };

  const hasActiveFilters =
    filterState.searchQuery !== "" ||
    Object.values(filterState.categoricalFilters).some((arr: string[]) => Array.isArray(arr) && arr.length > 0) ||
    Object.values(filterState.numericalRanges).some((arr: [number, number]) => Array.isArray(arr) && arr.length === 2) ||
    (filterState.sortColumn !== undefined && filterState.sortColumn !== "");

  // Get top 3 categorical columns with <= 15 unique values for quick filtering
  const categoricalCols = columns.filter(
    (c) => c.type === "string" && c.uniqueCount <= 15 && c.uniqueCount > 1
  );

  const numericalCols = columns.filter(
    (c) => c.type === "number" && c.min !== undefined && c.max !== undefined
  );

  const sortColumn = filterState.sortColumn || "";
  const sortDirection = filterState.sortDirection || "asc";

  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-4 shadow-sm mb-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        {/* Search & Filter status */}
        <div className="flex items-center gap-3 flex-1 min-w-[280px]">
          <div className="relative flex-1 max-w-sm">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={filterState.searchQuery}
              onChange={(e) => handleSearchChange(e.target.value)}
              placeholder="Search keyword across all columns..."
              className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-4 py-2 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-indigo-500 focus:bg-slate-900 transition-colors"
            />
            {filterState.searchQuery && (
              <button
                onClick={() => handleSearchChange("")}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-200"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          <div className="flex items-center gap-2 text-xs font-medium text-slate-400 border-l border-slate-800 pl-3">
            <Filter className="w-3.5 h-3.5 text-indigo-400" />
            <span>
              Showing <strong className="text-slate-100 font-semibold">{filteredRowsCount.toLocaleString()}</strong> of{" "}
              {totalRowsCount.toLocaleString()} rows
            </span>
          </div>
        </div>

        {/* Sort Controls, Categorical Dropdowns & Reset */}
        <div className="flex items-center flex-wrap gap-2">
          {/* Sort Control */}
          <div className="flex items-center gap-1.5 bg-slate-800 border border-slate-700 rounded-xl px-3 py-1.5">
            <ArrowUpDown className="w-3.5 h-3.5 text-indigo-400" />
            <span className="text-[11px] font-bold text-slate-400 uppercase">Sort:</span>
            <select
              value={sortColumn}
              onChange={(e) => handleSortColumnChange(e.target.value)}
              className="bg-slate-800 text-xs font-semibold text-slate-200 focus:outline-none pr-2 py-0 cursor-pointer"
            >
              <option value="">Default (None)</option>
              {columns.map((c) => (
                <option key={c.name} value={c.name}>
                  {c.name} ({c.type})
                </option>
              ))}
            </select>
            {sortColumn && (
              <button
                onClick={handleToggleSortDirection}
                className="px-2 py-0.5 rounded-lg bg-slate-900 border border-slate-700 text-[11px] font-extrabold text-indigo-400 hover:bg-indigo-950/60 transition-colors shadow-xs ml-1"
                title={sortDirection === "asc" ? "Ascending order" : "Descending order"}
              >
                {sortDirection === "asc" ? "↑ ASC" : "↓ DESC"}
              </button>
            )}
          </div>

          {/* Categorical Dropdowns */}
          {categoricalCols.map((col) => {
            const selected = filterState.categoricalFilters[col.name] || [];
            const isOpen = activeDropdown === col.name;

            return (
              <div key={col.name} className="relative">
                <button
                  onClick={() => setActiveDropdown(isOpen ? null : col.name)}
                  className={`flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs font-medium border transition-all ${
                    selected.length > 0
                      ? "bg-indigo-950/60 border-indigo-800/60 text-indigo-300 font-semibold"
                      : "bg-slate-800 border-slate-700 text-slate-200 hover:bg-slate-700"
                  }`}
                >
                  <span>{col.name}</span>
                  {selected.length > 0 && (
                    <span className="w-4 h-4 rounded-full bg-indigo-600 text-white text-[10px] flex items-center justify-center font-bold">
                      {selected.length}
                    </span>
                  )}
                  <ChevronDown className={`w-3.5 h-3.5 transition-transform ${isOpen ? "rotate-180" : ""}`} />
                </button>

                {isOpen && (
                  <div className="absolute right-0 mt-2 w-56 bg-slate-900 border border-slate-800 rounded-xl shadow-xl p-2 z-50 max-h-60 overflow-y-auto">
                    <div className="flex items-center justify-between px-2 py-1 border-b border-slate-800 mb-1">
                      <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                        Filter by {col.name}
                      </span>
                      {selected.length > 0 && (
                        <button
                          onClick={() => {
                            onFilterChange({
                              ...filterState,
                              categoricalFilters: {
                                ...filterState.categoricalFilters,
                                [col.name]: [],
                              },
                            });
                          }}
                          className="text-[10px] text-indigo-400 hover:underline font-medium"
                        >
                          Clear
                        </button>
                      )}
                    </div>
                    <div className="space-y-1">
                      {col.sampleValues.map((val: any) => {
                        const strVal = String(val);
                        const isChecked = selected.includes(strVal);
                        return (
                          <label
                            key={strVal}
                            onClick={() => handleToggleCategory(col.name, strVal)}
                            className="flex items-center gap-2 px-2 py-1.5 rounded-lg hover:bg-slate-800/60 cursor-pointer text-xs text-slate-200 select-none"
                          >
                            <input
                              type="checkbox"
                              checked={isChecked}
                              onChange={() => {}} // handled by div click
                              className="w-3.5 h-3.5 rounded border-slate-700 bg-slate-950 text-indigo-500 focus:ring-0"
                            />
                            <span className="truncate">{strVal}</span>
                          </label>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>
            );
          })}

          {/* Numerical Range Filters */}
          {numericalCols.slice(0, 2).map((col) => {
            const currentRange = filterState.numericalRanges[col.name];
            const isOpen = activeDropdown === `num-${col.name}`;
            const inputVal = rangeInputs[col.name] || {
              min: currentRange ? String(currentRange[0]) : "",
              max: currentRange ? String(currentRange[1]) : "",
            };

            return (
              <div key={col.name} className="relative">
                <button
                  onClick={() => {
                    if (!isOpen) {
                      setRangeInputs({
                        ...rangeInputs,
                        [col.name]: {
                          min: currentRange ? String(currentRange[0]) : "",
                          max: currentRange ? String(currentRange[1]) : "",
                        },
                      });
                    }
                    setActiveDropdown(isOpen ? null : `num-${col.name}`);
                  }}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium border transition-all ${
                    currentRange
                      ? "bg-indigo-950/60 border-indigo-800/60 text-indigo-300 font-semibold"
                      : "bg-slate-800 border-slate-700 text-slate-200 hover:bg-slate-700"
                  }`}
                >
                  <SlidersHorizontal className="w-3 h-3" />
                  <span>{col.name}</span>
                  {currentRange && (
                    <span className="text-[10px] bg-indigo-600 text-white px-1.5 py-0.5 rounded-full font-bold">
                      {currentRange[0]}–{currentRange[1]}
                    </span>
                  )}
                  <ChevronDown className={`w-3.5 h-3.5 transition-transform ${isOpen ? "rotate-180" : ""}`} />
                </button>

                {isOpen && (
                  <div className="absolute right-0 mt-2 w-64 bg-slate-900 border border-slate-800 rounded-xl shadow-xl p-3 z-50">
                    <div className="flex items-center justify-between pb-2 border-b border-slate-800 mb-2">
                      <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                        Range: {col.name}
                      </span>
                      <span className="text-[10px] text-slate-400">
                        Min: {col.min} / Max: {col.max}
                      </span>
                    </div>
                    <div className="grid grid-cols-2 gap-2 mb-3">
                      <div>
                        <label className="block text-[10px] text-slate-400 font-semibold mb-1">Min Value</label>
                        <input
                          type="number"
                          value={inputVal.min}
                          onChange={(e) =>
                            setRangeInputs({
                              ...rangeInputs,
                              [col.name]: { ...inputVal, min: e.target.value },
                            })
                          }
                          placeholder={String(col.min)}
                          className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2 py-1 text-xs text-slate-100 focus:outline-none focus:border-indigo-500"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] text-slate-400 font-semibold mb-1">Max Value</label>
                        <input
                          type="number"
                          value={inputVal.max}
                          onChange={(e) =>
                            setRangeInputs({
                              ...rangeInputs,
                              [col.name]: { ...inputVal, max: e.target.value },
                            })
                          }
                          placeholder={String(col.max)}
                          className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2 py-1 text-xs text-slate-100 focus:outline-none focus:border-indigo-500"
                        />
                      </div>
                    </div>
                    <div className="flex items-center justify-end gap-2">
                      {currentRange && (
                        <button
                          onClick={() => {
                            handleApplyRange(col.name, "", "");
                            setActiveDropdown(null);
                          }}
                          className="text-xs text-rose-400 hover:underline px-2 py-1"
                        >
                          Clear
                        </button>
                      )}
                      <button
                        onClick={() => {
                          handleApplyRange(col.name, inputVal.min, inputVal.max);
                          setActiveDropdown(null);
                        }}
                        className="px-3 py-1 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow-xs"
                      >
                        Apply Filter
                      </button>
                    </div>
                  </div>
                )}
              </div>
            );
          })}

          {hasActiveFilters && (
            <button
              onClick={handleReset}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-rose-950/60 hover:bg-rose-900/60 border border-rose-800/60 text-rose-300 text-xs font-semibold transition-all"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
