import React, { useState, useEffect } from "react";
import { X, BarChart2, Check, Sparkles, Palette } from "lucide-react";
import { ChartConfig, ChartType, AggregationType, ColorTheme, ColumnSchema } from "../types";
import { ChartRenderer } from "./ChartRenderer";

interface ChartBuilderModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (chart: ChartConfig) => void;
  initialChart?: ChartConfig | null;
  columns: ColumnSchema[];
  rows: Record<string, any>[];
}

export const ChartBuilderModal: React.FC<ChartBuilderModalProps> = ({
  isOpen,
  onClose,
  onSave,
  initialChart,
  columns,
  rows,
}) => {
  const [title, setTitle] = useState("New Chart");
  const [description, setDescription] = useState("");
  const [type, setType] = useState<ChartType>("bar");
  const [xAxisColumn, setXAxisColumn] = useState("");
  const [yAxisColumn, setYAxisColumn] = useState("");
  const [aggregation, setAggregation] = useState<AggregationType>("SUM");
  const [groupByColumn, setGroupByColumn] = useState<string>("");
  const [colorTheme, setColorTheme] = useState<ColorTheme>("indigo");
  const [colSpan, setColSpan] = useState<1 | 2>(1);
  const [customColorHex, setCustomColorHex] = useState("");
  const [customXAxisLabel, setCustomXAxisLabel] = useState("");
  const [customYAxisLabel, setCustomYAxisLabel] = useState("");
  const [showValues, setShowValues] = useState(false);

  const numCols = columns.filter((c) => c.type === "number");
  const stringCols = columns.filter((c) => c.type === "string" || c.type === "date");

  useEffect(() => {
    if (initialChart) {
      setTitle(initialChart.title);
      setDescription(initialChart.description || "");
      setType(initialChart.type);
      setXAxisColumn(initialChart.xAxisColumn);
      setYAxisColumn(initialChart.yAxisColumn);
      setAggregation(initialChart.aggregation);
      setGroupByColumn(initialChart.groupByColumn || "");
      setColorTheme(initialChart.colorTheme);
      setColSpan(initialChart.colSpan);
      setCustomColorHex(initialChart.customColorHex || "");
      setCustomXAxisLabel(initialChart.customXAxisLabel || "");
      setCustomYAxisLabel(initialChart.customYAxisLabel || "");
      setShowValues(initialChart.showValues || false);
    } else if (columns.length > 0) {
      const defaultX = stringCols[0]?.name || columns[0]?.name || "";
      const defaultY = numCols[0]?.name || columns[1]?.name || "";
      setXAxisColumn(defaultX);
      setYAxisColumn(defaultY);
      setTitle(`${defaultY ? `SUM of ${defaultY}` : "Chart"} by ${defaultX}`);
      setCustomColorHex("");
      setCustomXAxisLabel("");
      setCustomYAxisLabel("");
      setShowValues(false);
    }
  }, [initialChart, columns, isOpen]);

  if (!isOpen) return null;

  const handleTypeChange = (newType: ChartType) => {
    setType(newType);
    if (!initialChart && yAxisColumn && xAxisColumn) {
      setTitle(`${aggregation} of ${yAxisColumn} by ${xAxisColumn}`);
    }
  };

  const handleSave = () => {
    if (!xAxisColumn || !yAxisColumn) return;
    const newChart: ChartConfig = {
      id: initialChart?.id || `chart-${Date.now()}`,
      title: title.trim() || `${aggregation} of ${yAxisColumn} by ${xAxisColumn}`,
      description: description.trim(),
      type,
      xAxisColumn,
      yAxisColumn,
      aggregation,
      groupByColumn: groupByColumn ? groupByColumn : undefined,
      colorTheme,
      colSpan,
      customColorHex: customColorHex ? customColorHex : undefined,
      customXAxisLabel: customXAxisLabel.trim() ? customXAxisLabel.trim() : undefined,
      customYAxisLabel: customYAxisLabel.trim() ? customYAxisLabel.trim() : undefined,
      showValues,
    };
    onSave(newChart);
    onClose();
  };

  const previewConfig: ChartConfig = {
    id: "preview",
    title: title || `${aggregation} of ${yAxisColumn} by ${xAxisColumn}`,
    description,
    type,
    xAxisColumn,
    yAxisColumn,
    aggregation,
    groupByColumn: groupByColumn ? groupByColumn : undefined,
    colorTheme,
    colSpan: 1,
    customColorHex: customColorHex ? customColorHex : undefined,
    customXAxisLabel: customXAxisLabel.trim() ? customXAxisLabel.trim() : undefined,
    customYAxisLabel: customYAxisLabel.trim() ? customYAxisLabel.trim() : undefined,
    showValues,
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="bg-white border border-slate-200 rounded-3xl w-full max-w-5xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center border border-indigo-200 shadow-2xs">
              <BarChart2 className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-900">
                {initialChart ? "Edit Your Chart" : "Make Your Chart"}
              </h2>
              <p className="text-xs text-slate-500">Configure axes, aggregation, labels, and color theme with real-time preview</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-700 rounded-xl hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 grid grid-cols-1 lg:grid-cols-12 gap-6 overflow-y-auto flex-1">
          {/* Controls Form (Left 6 col) */}
          <div className="lg:col-span-6 space-y-4">
            {/* Chart Type Selector */}
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                1. Graphical Chart Type
              </label>
              <div className="grid grid-cols-3 gap-2">
                {(["bar", "line", "area", "composed", "radialBar", "treemap", "pie", "scatter", "radar"] as ChartType[]).map((t) => (
                  <button
                    key={t}
                    type="button"
                    onClick={() => handleTypeChange(t)}
                    className={`px-3 py-2 rounded-xl text-xs font-semibold uppercase tracking-wider border transition-all flex items-center justify-center gap-1.5 ${
                      type === t
                        ? "bg-indigo-600 text-white border-indigo-500 shadow-md shadow-indigo-600/20"
                        : "bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100 hover:border-slate-300"
                    }`}
                  >
                    <span>{t === "composed" ? "combo" : t === "radialBar" ? "radial" : t}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Axes and Aggregation */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  2. X-Axis (Dimension)
                </label>
                <select
                  value={xAxisColumn}
                  onChange={(e) => setXAxisColumn(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 font-medium focus:outline-none focus:border-indigo-500 focus:bg-white"
                >
                  <option value="">Select column...</option>
                  {columns.map((c) => (
                    <option key={c.name} value={c.name}>
                      {c.name} ({c.type})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  3. Y-Axis (Metric)
                </label>
                <select
                  value={yAxisColumn}
                  onChange={(e) => setYAxisColumn(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 font-medium focus:outline-none focus:border-indigo-500 focus:bg-white"
                >
                  <option value="">Select column...</option>
                  {columns.map((c) => (
                    <option key={c.name} value={c.name}>
                      {c.name} ({c.type})
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  4. Aggregation Function
                </label>
                <select
                  value={aggregation}
                  onChange={(e) => setAggregation(e.target.value as AggregationType)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 font-medium focus:outline-none focus:border-indigo-500 focus:bg-white"
                >
                  <option value="SUM">SUM</option>
                  <option value="AVERAGE">AVERAGE (MEAN)</option>
                  <option value="COUNT">COUNT ROWS</option>
                  <option value="MAX">MAXIMUM</option>
                  <option value="MIN">MINIMUM</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  5. Segment / Group By (Opt)
                </label>
                <select
                  value={groupByColumn}
                  onChange={(e) => setGroupByColumn(e.target.value)}
                  disabled={type === "pie" || type === "scatter"}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 font-medium focus:outline-none focus:border-indigo-500 focus:bg-white disabled:opacity-40"
                >
                  <option value="">None (Single Series)</option>
                  {stringCols
                    .filter((c) => c.name !== xAxisColumn && c.uniqueCount <= 10)
                    .map((c) => (
                      <option key={c.name} value={c.name}>
                        {c.name} ({c.uniqueCount} groups)
                      </option>
                    ))}
                </select>
              </div>
            </div>

            {/* Title & Description */}
            <div className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  6. Chart Title
                </label>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. Total Revenue by Product Category"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 font-medium focus:outline-none focus:border-indigo-500 focus:bg-white"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  7. Description / Subtitle
                </label>
                <input
                  type="text"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="e.g. Compares quarterly sales performance across regional branches"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 font-medium focus:outline-none focus:border-indigo-500 focus:bg-white"
                />
              </div>
            </div>

            {/* Custom Axis Labels */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  8. Custom X-Axis Label (Opt)
                </label>
                <input
                  type="text"
                  value={customXAxisLabel}
                  onChange={(e) => setCustomXAxisLabel(e.target.value)}
                  placeholder={xAxisColumn || "e.g. Region"}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 font-medium focus:outline-none focus:border-indigo-500 focus:bg-white"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  9. Custom Y-Axis Label (Opt)
                </label>
                <input
                  type="text"
                  value={customYAxisLabel}
                  onChange={(e) => setCustomYAxisLabel(e.target.value)}
                  placeholder={yAxisColumn || "e.g. Revenue ($)"}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 font-medium focus:outline-none focus:border-indigo-500 focus:bg-white"
                />
              </div>
            </div>

            {/* Color Theme & Custom Hex */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  10. Color Theme Palette
                </label>
                <select
                  value={colorTheme}
                  onChange={(e) => setColorTheme(e.target.value as ColorTheme)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 font-medium focus:outline-none focus:border-indigo-500 capitalize"
                >
                  {(["indigo", "emerald", "amber", "cyan", "rose", "purple", "slate"] as ColorTheme[]).map((thm) => (
                    <option key={thm} value={thm} className="capitalize">
                      {thm}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  11. Custom Primary Color (Hex)
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="color"
                    value={customColorHex || "#6366f1"}
                    onChange={(e) => setCustomColorHex(e.target.value)}
                    className="w-9 h-9 rounded-xl border border-slate-200 bg-white p-0.5 cursor-pointer shadow-2xs"
                  />
                  <input
                    type="text"
                    value={customColorHex}
                    onChange={(e) => setCustomColorHex(e.target.value)}
                    placeholder="e.g. #4f46e5"
                    className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 font-medium focus:outline-none focus:border-indigo-500"
                  />
                  {customColorHex && (
                    <button
                      type="button"
                      onClick={() => setCustomColorHex("")}
                      className="text-[11px] text-slate-400 hover:text-rose-600 px-1"
                    >
                      Clear
                    </button>
                  )}
                </div>
              </div>
            </div>

            {/* Card Width & Show Values */}
            <div className="grid grid-cols-2 gap-4 items-center pt-1">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  12. Card Width
                </label>
                <div className="flex rounded-xl bg-slate-100 border border-slate-200 p-1">
                  <button
                    type="button"
                    onClick={() => setColSpan(1)}
                    className={`flex-1 py-1.5 rounded-lg text-xs font-bold transition-all ${
                      colSpan === 1 ? "bg-white text-indigo-600 shadow-2xs" : "text-slate-500 hover:text-slate-900"
                    }`}
                  >
                    Half (1 Col)
                  </button>
                  <button
                    type="button"
                    onClick={() => setColSpan(2)}
                    className={`flex-1 py-1.5 rounded-lg text-xs font-bold transition-all ${
                      colSpan === 2 ? "bg-white text-indigo-600 shadow-2xs" : "text-slate-500 hover:text-slate-900"
                    }`}
                  >
                    Full (2 Col)
                  </button>
                </div>
              </div>

              <div className="flex items-center gap-3 pt-4">
                <input
                  type="checkbox"
                  id="showValuesCheckbox"
                  checked={showValues}
                  onChange={(e) => setShowValues(e.target.checked)}
                  className="w-4 h-4 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500 cursor-pointer"
                />
                <label htmlFor="showValuesCheckbox" className="text-xs font-bold text-slate-700 cursor-pointer select-none">
                  Show Data Point Value Labels
                </label>
              </div>
            </div>
          </div>

          {/* Live Preview (Right 6 col) */}
          <div className="lg:col-span-6 flex flex-col">
            <label className="block text-xs font-bold text-indigo-600 uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5" />
              Real-Time Chart Preview
            </label>
            <div className="flex-1 bg-slate-50 border border-slate-200 rounded-3xl p-4 flex flex-col justify-center shadow-inner">
              {xAxisColumn && yAxisColumn ? (
                <ChartRenderer chart={previewConfig} rows={rows} isPreview={true} />
              ) : (
                <div className="text-center text-slate-400 text-xs py-12 font-medium">
                  Please select X and Y axes to render preview
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Footer actions */}
        <div className="px-6 py-4 border-t border-slate-200 bg-slate-50 flex items-center justify-end gap-3">
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-white hover:bg-slate-100 border border-slate-200 text-slate-700 text-xs font-semibold transition-colors"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={handleSave}
            disabled={!xAxisColumn || !yAxisColumn}
            className="flex items-center gap-2 px-6 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow-md shadow-indigo-600/20 transition-all disabled:opacity-40"
          >
            <Check className="w-4 h-4" />
            <span>{initialChart ? "Update Your Chart" : "Make Your Chart"}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
