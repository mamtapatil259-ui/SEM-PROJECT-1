import React, { useState, useRef, useEffect } from "react";
import { Sparkles, Zap, Feather, FastForward, Sliders, Check } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { useAnimationConfig, AnimationMode, AnimationSpeed } from "../context/AnimationContext";

export const AnimationSettingsDropdown: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const { mode, setMode, speed, setSpeed, buttonHover, buttonTap } = useAnimationConfig();

  // Close on outside click
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const modes: { id: AnimationMode; label: string; desc: string; icon: React.ReactNode }[] = [
    {
      id: "energetic",
      label: "Energetic Spring",
      desc: "Bouncy spring physics & live counter animations",
      icon: <Sparkles className="w-3.5 h-3.5 text-amber-400" />,
    },
    {
      id: "gentle",
      label: "Gentle & Fluid",
      desc: "Smooth easing curves & cinematic transitions",
      icon: <Feather className="w-3.5 h-3.5 text-cyan-400" />,
    },
    {
      id: "snappy",
      label: "Snappy & Rapid",
      desc: "Instant feedback with minimal transition times",
      icon: <FastForward className="w-3.5 h-3.5 text-indigo-400" />,
    },
    {
      id: "reduced",
      label: "Reduced Motion",
      desc: "Instant changes without translational motion",
      icon: <Zap className="w-3.5 h-3.5 text-slate-400" />,
    },
  ];

  const speeds: { id: AnimationSpeed; label: string }[] = [
    { id: 0.75, label: "0.75x" },
    { id: 1, label: "1.0x" },
    { id: 1.5, label: "1.5x" },
  ];

  return (
    <div className="relative" ref={dropdownRef}>
      <motion.button
        whileHover={buttonHover}
        whileTap={buttonTap}
        onClick={() => setIsOpen(!isOpen)}
        className={`p-2 rounded-xl border transition-colors flex items-center gap-1.5 text-xs font-semibold ${
          isOpen
            ? "bg-indigo-600/20 text-indigo-200 border-indigo-500/40"
            : "bg-slate-800 hover:bg-slate-700 text-slate-200 border-slate-700"
        }`}
        title="Customize Animation Style & Speed"
        aria-label="Animation Settings"
      >
        <Zap className="w-4 h-4 text-amber-400 animate-pulse" />
        <span className="hidden lg:inline capitalize">{mode}</span>
      </motion.button>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 8, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 8, scale: 0.95 }}
            transition={{ duration: 0.18 }}
            className="absolute right-0 mt-2 w-72 bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl p-3 z-50 text-slate-200"
          >
            <div className="flex items-center justify-between pb-2 border-b border-slate-800 mb-2">
              <div className="flex items-center gap-1.5 text-xs font-bold text-slate-300">
                <Sliders className="w-3.5 h-3.5 text-indigo-400" />
                <span>Animation Settings</span>
              </div>
              <span className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold">Motion</span>
            </div>

            {/* Animation Style selection */}
            <div className="space-y-1 mb-3">
              <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block px-1 mb-1">
                Physics Style
              </span>
              {modes.map((m) => (
                <button
                  key={m.id}
                  onClick={() => setMode(m.id)}
                  className={`w-full flex items-start gap-2.5 p-2 rounded-xl text-left transition-all ${
                    mode === m.id
                      ? "bg-indigo-600/20 text-indigo-100 border border-indigo-500/40"
                      : "text-slate-300 hover:bg-slate-800/70 border border-transparent"
                  }`}
                >
                  <div className="mt-0.5 shrink-0">{m.icon}</div>
                  <div className="flex-1 min-w-0">
                    <div className="text-xs font-bold flex items-center justify-between">
                      <span>{m.label}</span>
                      {mode === m.id && <Check className="w-3.5 h-3.5 text-indigo-400" />}
                    </div>
                    <div className="text-[10px] text-slate-400 leading-tight mt-0.5">{m.desc}</div>
                  </div>
                </button>
              ))}
            </div>

            {/* Speed Multiplier */}
            {mode !== "reduced" && (
              <div className="pt-2 border-t border-slate-800">
                <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block px-1 mb-1.5">
                  Animation Speed
                </span>
                <div className="grid grid-cols-3 gap-1.5 p-1 bg-slate-950 rounded-xl border border-slate-800">
                  {speeds.map((s) => (
                    <button
                      key={s.id}
                      onClick={() => setSpeed(s.id)}
                      className={`py-1 text-xs font-bold rounded-lg transition-all ${
                        speed === s.id
                          ? "bg-indigo-600 text-white shadow-sm"
                          : "text-slate-400 hover:text-slate-200"
                      }`}
                    >
                      {s.label}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
