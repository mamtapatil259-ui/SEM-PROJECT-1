import React, { useState, useRef } from "react";
import { Upload, FileSpreadsheet, Sparkles, Check, AlertCircle, ArrowRight, Layers, FileText, Database } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import * as XLSX from "xlsx";
import { Dataset } from "../types";
import { parseRawInput, analyzeDatasetSchema } from "../utils/dataEngine";
import { BrandLogo } from "./BrandLogo";
import { useAnimationConfig } from "../context/AnimationContext";

interface ExcelUploadSectionProps {
  onSelectDataset: (dataset: Dataset) => void;
  onAutoGenerate?: () => void;
  isAutoGenerating?: boolean;
  onOpenSampleLibrary?: () => void;
}

export const ExcelUploadSection: React.FC<ExcelUploadSectionProps> = ({
  onSelectDataset,
  onAutoGenerate,
  isAutoGenerating,
  onOpenSampleLibrary,
}) => {
  const { buttonHover, buttonTap, isReduced } = useAnimationConfig();
  const [isDragging, setIsDragging] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [autoVisualize, setAutoVisualize] = useState(true);
  const [workbookData, setWorkbookData] = useState<{
    workbook: XLSX.WorkBook;
    fileName: string;
    sheetNames: string[];
    selectedSheet: string;
  } | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    processFile(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      processFile(file);
    }
  };

  const processFile = (file: File) => {
    setError(null);
    setSuccessMsg(null);
    setWorkbookData(null);

    const ext = file.name.split(".").pop()?.toLowerCase();
    const isExcel = ext === "xlsx" || ext === "xls";

    if (isExcel) {
      const reader = new FileReader();
      reader.onload = (event) => {
        try {
          const data = new Uint8Array(event.target?.result as ArrayBuffer);
          const workbook = XLSX.read(data, { type: "array" });
          const sheetNames = workbook.SheetNames;

          if (!sheetNames || sheetNames.length === 0) {
            setError("The uploaded Excel workbook contains no sheets.");
            return;
          }

          if (sheetNames.length > 1) {
            // Save workbook state to allow user to pick or switch sheets
            setWorkbookData({
              workbook,
              fileName: file.name,
              sheetNames,
              selectedSheet: sheetNames[0],
            });
          }

          loadExcelSheet(workbook, sheetNames[0], file.name);
        } catch (err: any) {
          setError(`Failed to read Excel workbook: ${err?.message || "Unknown format error"}`);
        }
      };
      reader.onerror = () => setError("Error reading Excel file from disk.");
      reader.readAsArrayBuffer(file);
    } else {
      // Handle CSV, TSV, JSON
      const reader = new FileReader();
      reader.onload = (event) => {
        const content = event.target?.result as string;
        if (!content) {
          setError("Failed to read file contents.");
          return;
        }
        const format = ext === "json" ? "json" : ext === "tsv" ? "tsv" : "csv";
        const { rows, error: parseErr } = parseRawInput(content, format as any);

        if (parseErr || !rows || rows.length === 0) {
          setError(parseErr || "No valid data rows found in file.");
          return;
        }

        const columns = analyzeDatasetSchema(rows);
        const newDataset: Dataset = {
          id: `upload-${Date.now()}`,
          name: file.name.replace(/\.[^/.]+$/, ""),
          description: `Uploaded from file ${file.name} (${rows.length} rows, ${columns.length} columns)`,
          rows,
          columns,
          uploadedAt: new Date().toISOString(),
        };

        onSelectDataset(newDataset);
        setSuccessMsg(`Successfully loaded "${file.name}" with ${rows.length.toLocaleString()} rows!`);
        if (autoVisualize && onAutoGenerate) {
          setTimeout(() => onAutoGenerate(), 300);
        }
      };
      reader.onerror = () => setError("Error reading file from disk.");
      reader.readAsText(file);
    }
  };

  const loadExcelSheet = (workbook: XLSX.WorkBook, sheetName: string, fileName: string) => {
    try {
      const worksheet = workbook.Sheets[sheetName];
      const rows = XLSX.utils.sheet_to_json<Record<string, any>>(worksheet, { defval: "" });

      if (!rows || rows.length === 0) {
        setError(`Sheet "${sheetName}" appears to be empty or has no recognizable data rows.`);
        return;
      }

      const columns = analyzeDatasetSchema(rows);
      const cleanName = fileName.replace(/\.[^/.]+$/, "");
      const newDataset: Dataset = {
        id: `excel-${Date.now()}`,
        name: workbook.SheetNames.length > 1 ? `${cleanName} (${sheetName})` : cleanName,
        description: `Imported from Excel sheet "${sheetName}" (${rows.length} rows, ${columns.length} columns)`,
        rows,
        columns,
        uploadedAt: new Date().toISOString(),
      };

      onSelectDataset(newDataset);
      setSuccessMsg(`Successfully loaded Excel sheet "${sheetName}" with ${rows.length.toLocaleString()} rows!`);
      if (autoVisualize && onAutoGenerate) {
        setTimeout(() => onAutoGenerate(), 300);
      }
    } catch (err: any) {
      setError(`Error extracting data from sheet "${sheetName}": ${err?.message || "Unknown error"}`);
    }
  };

  const handleSheetChange = (sheetName: string) => {
    if (!workbookData) return;
    setWorkbookData({ ...workbookData, selectedSheet: sheetName });
    loadExcelSheet(workbookData.workbook, sheetName, workbookData.fileName);
  };

  return (
    <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm mb-6 text-slate-900">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-4">
        <div className="flex items-center gap-3">
          <BrandLogo size="md" />
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-base font-extrabold text-slate-900 tracking-tight">
                Excel & CSV Instant Visualization Station
              </h3>
              <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200">
                Auto DataDash Feature
              </span>
            </div>
            <p className="text-xs text-slate-600 mt-0.5">
              Upload any Excel workbook (<span className="font-semibold text-emerald-700">.xlsx, .xls</span>) or CSV file to immediately generate interactive BI graphs & scorecards
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3 bg-slate-50 px-3 py-1.5 rounded-xl border border-slate-200 shadow-2xs">
          <input
            type="checkbox"
            id="autoVisCheck"
            checked={autoVisualize}
            onChange={(e) => setAutoVisualize(e.target.checked)}
            className="w-4 h-4 rounded border-slate-300 text-emerald-600 focus:ring-emerald-500 cursor-pointer"
          />
          <label htmlFor="autoVisCheck" className="text-xs font-bold text-slate-700 cursor-pointer select-none flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-amber-500" />
            Generate dashboard with data dash upon Upload
          </label>
        </div>
      </div>

      {/* Drag & Drop Upload Zone */}
      <motion.div
        style={{ borderStyle: "ridge" }}
        whileHover={isReduced ? {} : { scale: 1.008 }}
        whileTap={isReduced ? {} : { scale: 0.995 }}
        onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
        onDragLeave={() => setIsDragging(false)}
        onDrop={handleDrop}
        onClick={() => fileInputRef.current?.click()}
        className={`w-full border-2 border-dashed rounded-2xl p-6 flex flex-col sm:flex-row items-center justify-between gap-4 cursor-pointer transition-all ${
          isDragging
            ? "border-emerald-500 bg-emerald-50/90 scale-[1.02] shadow-lg shadow-emerald-500/10"
            : "border-slate-300 bg-slate-50/50 hover:border-emerald-500 hover:bg-slate-50"
        }`}
      >
        <div className="flex items-center gap-4 text-center sm:text-left">
          <motion.div
            animate={isDragging && !isReduced ? { y: [-3, 3, -3], rotate: [-4, 4, -4] } : {}}
            transition={{ repeat: Infinity, duration: 0.8 }}
            className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center border border-emerald-200 shrink-0 mx-auto sm:mx-0 shadow-xs"
          >
            <Upload className="w-5 h-5" />
          </motion.div>
          <div>
            <p className="text-sm font-bold text-slate-800">
              Drag & Drop your Excel or CSV file here, or click to browse
            </p>
            <p className="text-xs text-slate-500 mt-0.5">
              Supports <strong className="text-emerald-700 font-semibold">.xlsx, .xls</strong> (Microsoft Excel), <strong className="text-indigo-700 font-semibold">.csv</strong>, .tsv, and .json files.
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2 shrink-0">
          <motion.button
            whileHover={buttonHover}
            whileTap={buttonTap}
            type="button"
            onClick={(e) => { e.stopPropagation(); fileInputRef.current?.click(); }}
            className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-md shadow-emerald-600/20 transition-all flex items-center gap-1.5 cursor-pointer"
          >
            <FileSpreadsheet className="w-4 h-4" />
            <span>Select Excel / CSV File</span>
          </motion.button>
          {onOpenSampleLibrary && (
            <motion.button
              whileHover={buttonHover}
              whileTap={buttonTap}
              type="button"
              onClick={(e) => { e.stopPropagation(); onOpenSampleLibrary(); }}
              className="px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold border border-slate-300 transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <Database className="w-4 h-4 text-indigo-600" />
              <span>Sample Library</span>
            </motion.button>
          )}
        </div>
        <input
          ref={fileInputRef}
          type="file"
          accept=".xlsx,.xls,.csv,.tsv,.json,.txt"
          onChange={handleFileUpload}
          className="hidden"
        />
      </motion.div>

      {/* Multi-Sheet Selector (if workbook has multiple sheets) */}
      {workbookData && workbookData.sheetNames.length > 1 && (
        <div className="mt-4 p-3 bg-slate-50 rounded-2xl border border-emerald-200 flex flex-wrap items-center justify-between gap-3 shadow-2xs animate-fadeIn">
          <div className="flex items-center gap-2 text-xs font-bold text-slate-700">
            <Layers className="w-4 h-4 text-emerald-600" />
            <span>Workbook "{workbookData.fileName}" has multiple sheets. Select sheet to visualize:</span>
          </div>
          <div className="flex flex-wrap items-center gap-1.5">
            {workbookData.sheetNames.map((sheet) => (
              <button
                key={sheet}
                type="button"
                onClick={(e) => { e.stopPropagation(); handleSheetChange(sheet); }}
                className={`px-3 py-1 rounded-xl text-xs font-bold transition-all ${
                  workbookData.selectedSheet === sheet
                    ? "bg-emerald-600 text-white shadow-2xs"
                    : "bg-white text-slate-700 border border-slate-200 hover:bg-slate-100"
                }`}
              >
                {sheet}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Messages */}
      {error && (
        <div className="mt-3 p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-semibold flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
          <span>{error}</span>
        </div>
      )}

      {successMsg && !error && (
        <div className="mt-3 p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-semibold flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Check className="w-4 h-4 shrink-0 text-emerald-600" />
            <span>{successMsg}</span>
          </div>
          {isAutoGenerating && (
            <span className="text-[11px] font-bold text-amber-600 flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5 animate-spin" />
              Smart Engine Designing Dashboard...
            </span>
          )}
        </div>
      )}
    </div>
  );
};
