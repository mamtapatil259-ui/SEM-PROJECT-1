export type ColumnType = "number" | "string" | "date" | "boolean";

export interface ColumnSchema {
  name: string;
  type: ColumnType;
  sampleValues: any[];
  uniqueCount: number;
  nullCount: number;
  min?: number;
  max?: number;
  mean?: number;
}

export interface Dataset {
  id: string;
  name: string;
  description?: string;
  rows: Record<string, any>[];
  columns: ColumnSchema[];
  uploadedAt: string;
}

export type AggregationType = "SUM" | "AVERAGE" | "COUNT" | "MAX" | "MIN";

export type ChartType = "bar" | "line" | "area" | "pie" | "scatter" | "radar" | "composed" | "radialBar" | "treemap";

export type ColorTheme = "indigo" | "emerald" | "amber" | "rose" | "cyan" | "purple" | "slate";

export interface KpiConfig {
  id: string;
  title: string;
  column: string;
  aggregation: AggregationType;
  format: "currency" | "percentage" | "number" | "standard";
  description?: string;
  trendLabel?: string;
  trendDirection?: "up" | "down" | "neutral";
  prefix?: string;
  suffix?: string;
}

export interface ChartConfig {
  id: string;
  title: string;
  description?: string;
  type: ChartType;
  xAxisColumn: string;
  yAxisColumn: string;
  aggregation: AggregationType;
  groupByColumn?: string;
  colorTheme: ColorTheme;
  colSpan: 1 | 2; // 1 for standard half width, 2 for full width
  showLegend?: boolean;
  showGrid?: boolean;
  customColorHex?: string;
  customXAxisLabel?: string;
  customYAxisLabel?: string;
  showValues?: boolean;
  showBrush?: boolean;
  showReferenceLine?: boolean;
  curveType?: "monotone" | "linear" | "step";
}

export interface DashboardConfig {
  id: string;
  datasetId: string;
  title: string;
  executiveSummary?: string;
  keyInsights?: string[];
  kpis: KpiConfig[];
  charts: ChartConfig[];
  updatedAt: string;
}

export interface FilterState {
  searchQuery: string;
  categoricalFilters: Record<string, string[]>; // column -> selected values
  numericalRanges: Record<string, [number, number]>; // column -> [min, max]
  sortColumn?: string;
  sortDirection?: "asc" | "desc";
}

export interface InsightsChatMessage {
  id: string;
  sender: "user" | "assistant";
  text: string;
  timestamp: string;
  keyFindings?: string[];
  suggestedChart?: ChartConfig | null;
  suggestedKpi?: KpiConfig | null;
  isLoading?: boolean;
}

export interface CleaningRecommendation {
  title: string;
  description: string;
  actionType: "fill_mean" | "drop_nulls" | "remove_duplicates" | "trim_strings";
  targetColumn?: string;
  impact: "High" | "Medium" | "Low";
}

export interface DataHygieneResult {
  hygieneScore: number;
  scoreLabel: "Excellent" | "Good" | "Needs Attention" | "Critical";
  summary: string;
  recommendations: CleaningRecommendation[];
}
