/**
 * Auto DataDash - Frontend Application Engine
 * Pure Vanilla JavaScript communicating with the Python Backend REST API
 */

// Global State
const state = {
  currentDataset: null,
  activeTab: "import_raw",
  kpis: [],
  charts: [],
  chartInstances: {},
  animationSpeed: 1.0,
  filterQuery: "",
};

// Sample datasets for quick demo
const SAMPLE_DATASETS = {
  saas: {
    name: "SaaS Enterprise Sales & ARR.xlsx",
    columns: [
      { name: "account_name", type: "string" },
      { name: "tier", type: "string" },
      { name: "arr_usd", type: "currency" },
      { name: "seats", type: "number" },
      { name: "nps_score", type: "number" },
      { name: "renewal_quarter", type: "string" },
    ],
    rows: [
      { account_name: "Apex Logistics", tier: "Enterprise", arr_usd: 124000, seats: 450, nps_score: 78, renewal_quarter: "Q1" },
      { account_name: "Starlight Media", tier: "Growth", arr_usd: 48000, seats: 120, nps_score: 82, renewal_quarter: "Q2" },
      { account_name: "Beacon Health", tier: "Enterprise", arr_usd: 195000, seats: 820, nps_score: 91, renewal_quarter: "Q1" },
      { account_name: "Nova Fintech", tier: "Starter", arr_usd: 18000, seats: 45, nps_score: 65, renewal_quarter: "Q3" },
      { account_name: "Vanguard Tech", tier: "Enterprise", arr_usd: 240000, seats: 1100, nps_score: 88, renewal_quarter: "Q4" },
      { account_name: "Horizon Cloud", tier: "Growth", arr_usd: 62000, seats: 210, nps_score: 74, renewal_quarter: "Q2" },
      { account_name: "Crestview Labs", tier: "Starter", arr_usd: 14500, seats: 30, nps_score: 70, renewal_quarter: "Q3" },
      { account_name: "Omni Retail", tier: "Enterprise", arr_usd: 178000, seats: 680, nps_score: 85, renewal_quarter: "Q4" },
    ],
  },
  ecommerce: {
    name: "Global E-Commerce Orders.csv",
    columns: [
      { name: "order_id", type: "string" },
      { name: "region", type: "string" },
      { name: "product_category", type: "string" },
      { name: "sales_amount", type: "currency" },
      { name: "quantity", type: "number" },
      { name: "shipping_days", type: "number" },
    ],
    rows: [
      { order_id: "ORD-901", region: "North America", product_category: "Electronics", sales_amount: 1240, quantity: 2, shipping_days: 3 },
      { order_id: "ORD-902", region: "Europe", product_category: "Apparel", sales_amount: 320, quantity: 4, shipping_days: 5 },
      { order_id: "ORD-903", region: "Asia Pacific", product_category: "Home & Garden", sales_amount: 680, quantity: 3, shipping_days: 4 },
      { order_id: "ORD-904", region: "North America", product_category: "Apparel", sales_amount: 510, quantity: 5, shipping_days: 2 },
      { order_id: "ORD-905", region: "Latin America", product_category: "Electronics", sales_amount: 2100, quantity: 3, shipping_days: 7 },
      { order_id: "ORD-906", region: "Europe", product_category: "Office Supplies", sales_amount: 195, quantity: 8, shipping_days: 3 },
      { order_id: "ORD-907", region: "Asia Pacific", product_category: "Electronics", sales_amount: 1840, quantity: 2, shipping_days: 4 },
    ],
  },
};

// Initialize Application
document.addEventListener("DOMContentLoaded", () => {
  setupEventListeners();
  // Load initial demo dataset
  loadDataset(SAMPLE_DATASETS.saas);
});

// Event Listeners
function setupEventListeners() {
  // Navigation tabs
  document.querySelectorAll(".tab-btn").forEach((btn) => {
    btn.addEventListener("click", (e) => {
      const tab = btn.dataset.tab;
      switchTab(tab);
    });
  });

  // Dropzone drag & drop
  const dropzone = document.getElementById("fileDropzone");
  const fileInput = document.getElementById("fileInput");

  if (dropzone && fileInput) {
    dropzone.addEventListener("click", () => fileInput.click());

    ["dragenter", "dragover"].forEach((eventName) => {
      dropzone.addEventListener(eventName, (e) => {
        e.preventDefault();
        dropzone.classList.add("dragover");
      });
    });

    ["dragleave", "drop"].forEach((eventName) => {
      dropzone.addEventListener(eventName, (e) => {
        e.preventDefault();
        dropzone.classList.remove("dragover");
      });
    });

    dropzone.addEventListener("drop", (e) => {
      const files = e.dataTransfer.files;
      if (files.length > 0) handleFileUpload(files[0]);
    });

    fileInput.addEventListener("change", (e) => {
      if (e.target.files.length > 0) handleFileUpload(e.target.files[0]);
    });
  }

  // Sample Buttons
  document.getElementById("btnSampleSaas")?.addEventListener("click", () => loadDataset(SAMPLE_DATASETS.saas));
  document.getElementById("btnSampleEcom")?.addEventListener("click", () => loadDataset(SAMPLE_DATASETS.ecommerce));

  // Auto Generate Button
  document.getElementById("btnAutoGenerate")?.addEventListener("click", () => requestPythonDashboardGeneration());

  // Search Filter
  document.getElementById("tableSearch")?.addEventListener("input", (e) => {
    state.filterQuery = e.target.value.toLowerCase();
    renderDataTable();
  });

  // Export CSV
  document.getElementById("btnExportCsv")?.addEventListener("click", exportCurrentDataCsv);

  // Modals
  setupModal("modalAddKpi", "btnOpenAddKpi", "btnCloseAddKpi");
  setupModal("modalAddChart", "btnOpenAddChart", "btnCloseAddChart");

  // Add KPI Form Submit
  document.getElementById("formAddKpi")?.addEventListener("submit", handleAddKpiSubmit);

  // Add Chart Form Submit
  document.getElementById("formAddChart")?.addEventListener("submit", handleAddChartSubmit);
}

// Switch Active View Tab
function switchTab(tabId) {
  state.activeTab = tabId;

  document.querySelectorAll(".tab-btn").forEach((btn) => {
    btn.classList.toggle("active", btn.dataset.tab === tabId);
  });

  document.querySelectorAll(".tab-pane").forEach((pane) => {
    pane.style.display = pane.id === `tab-${tabId}` ? "block" : "none";
  });

  if (tabId === "visualizations") {
    // Re-render charts when visible so canvas sizes correctly
    renderCharts();
  }
}

// File Upload Handler
function handleFileUpload(file) {
  const ext = file.name.split(".").pop().toLowerCase();

  if (ext === "xlsx" || ext === "xls") {
    const reader = new FileReader();
    reader.onload = (e) => {
      const data = new Uint8Array(e.target.result);
      const workbook = XLSX.read(data, { type: "array" });
      const firstSheet = workbook.SheetNames[0];
      const rows = XLSX.utils.sheet_to_json(workbook.Sheets[firstSheet]);
      processParsedRows(file.name, rows);
    };
    reader.readAsArrayBuffer(file);
  } else if (ext === "csv" || ext === "tsv" || ext === "json") {
    const reader = new FileReader();
    reader.onload = (e) => {
      const text = e.target.result;
      if (ext === "json") {
        try {
          const rows = JSON.parse(text);
          processParsedRows(file.name, Array.isArray(rows) ? rows : [rows]);
        } catch (err) {
          alert("Invalid JSON file");
        }
      } else {
        const rows = parseCsvText(text, ext === "tsv" ? "\t" : ",");
        processParsedRows(file.name, rows);
      }
    };
    reader.readAsText(file);
  } else {
    alert("Please upload a .xlsx, .xls, .csv, or .json file.");
  }
}

// Simple CSV text parser
function parseCsvText(text, delimiter = ",") {
  const lines = text.trim().split("\n");
  if (lines.length === 0) return [];
  const headers = lines[0].split(delimiter).map((h) => h.trim().replace(/^"|"$/g, ""));
  const rows = [];

  for (let i = 1; i < lines.length; i++) {
    const values = lines[i].split(delimiter);
    const row = {};
    headers.forEach((h, idx) => {
      let val = values[idx]?.trim().replace(/^"|"$/g, "");
      const num = Number(val);
      row[h] = !isNaN(num) && val !== "" ? num : val;
    });
    rows.push(row);
  }
  return rows;
}

// Process Ingested Rows
function processParsedRows(datasetName, rows) {
  if (!rows || rows.length === 0) {
    alert("The uploaded file does not contain any valid data rows.");
    return;
  }

  const sampleRow = rows[0];
  const columns = Object.keys(sampleRow).map((key) => {
    const sampleVal = sampleRow[key];
    const isNum = typeof sampleVal === "number" || (!isNaN(Number(sampleVal)) && sampleVal !== "");
    const isCurrency = isNum && (key.includes("revenue") || key.includes("sales") || key.includes("arr") || key.includes("price") || key.includes("cost"));
    return {
      name: key,
      type: isCurrency ? "currency" : isNum ? "number" : "string",
    };
  });

  const dataset = {
    name: datasetName,
    columns: columns,
    rows: rows,
  };

  loadDataset(dataset);
  requestPythonDashboardGeneration();
}

// Load Dataset into State & UI
function loadDataset(dataset) {
  state.currentDataset = dataset;

  // Update header badges
  const nameEl = document.getElementById("headerDatasetName");
  if (nameEl) nameEl.textContent = dataset.name;
  const countEl = document.getElementById("headerRowCount");
  if (countEl) countEl.textContent = `• ${dataset.rows.length.toLocaleString()} rows`;

  // Populate column selectors in modals
  populateColumnDropdowns(dataset.columns);

  // Render Data Table
  renderDataTable();

  // Call Python Backend for automated dashboard creation
  requestPythonDashboardGeneration();
}

// Populate Column Selectors for Modal Dialogs
function populateColumnDropdowns(columns) {
  const kpiColSelect = document.getElementById("kpiColumnSelect");
  const chartXSelect = document.getElementById("chartXSelect");
  const chartYSelect = document.getElementById("chartYSelect");

  if (kpiColSelect) {
    kpiColSelect.innerHTML = columns.map((c) => `<option value="${c.name}">${c.name} (${c.type})</option>`).join("");
  }
  if (chartXSelect) {
    chartXSelect.innerHTML = columns.map((c) => `<option value="${c.name}">${c.name}</option>`).join("");
  }
  if (chartYSelect) {
    chartYSelect.innerHTML = columns
      .filter((c) => c.type === "number" || c.type === "currency")
      .map((c) => `<option value="${c.name}">${c.name}</option>`).join("");
  }
}

// Connect to Python Backend API to Generate Dashboard
async function requestPythonDashboardGeneration() {
  if (!state.currentDataset) return;

  const btn = document.getElementById("btnAutoGenerate");
  if (btn) {
    btn.innerHTML = `<span class="animate-spin">⚙</span> Generating...`;
    btn.disabled = true;
  }

  try {
    const response = await fetch("/api/analytics/generate-dashboard", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        datasetName: state.currentDataset.name,
        columns: state.currentDataset.columns,
        rowCount: state.currentDataset.rows.length,
        sampleRows: state.currentDataset.rows.slice(0, 5),
      }),
    });

    if (response.ok) {
      const data = await response.json();
      if (data.success && data.dashboardConfig) {
        state.kpis = data.dashboardConfig.kpis || [];
        state.charts = data.dashboardConfig.charts || [];
        renderKpis();
        renderCharts();
      }
    }
  } catch (err) {
    console.log("Using algorithmic fallback for dashboard generation:", err);
    generateClientFallbackDashboard();
  } finally {
    if (btn) {
      btn.innerHTML = `<span>⚡</span> Generate Dashboard`;
      btn.disabled = false;
    }
  }
}

// Fallback Dashboard Generator (Client-Side if backend is unreachable)
function generateClientFallbackDashboard() {
  const cols = state.currentDataset.columns;
  const numCols = cols.filter((c) => c.type === "number" || c.type === "currency");
  const catCols = cols.filter((c) => c.type === "string");

  state.kpis = [];
  if (numCols.length > 0) {
    numCols.slice(0, 4).forEach((col, i) => {
      state.kpis.push({
        id: `kpi-${i}`,
        title: `Total ${col.name.replace("_", " ").toUpperCase()}`,
        column: col.name,
        aggregation: "SUM",
        format: col.type,
        trendLabel: "+12.4% vs prev period",
        trendDirection: "up",
      });
    });
  } else {
    state.kpis.push({
      id: "kpi-1",
      title: "Total Records Ingested",
      column: cols[0]?.name || "id",
      aggregation: "COUNT",
      format: "number",
      trendLabel: "+100% active",
      trendDirection: "up",
    });
  }

  const xCol = catCols[0]?.name || cols[0]?.name || "category";
  const yCol = numCols[0]?.name || cols[1]?.name || xCol;

  state.charts = [
    { id: "chart-1", title: `${yCol} by ${xCol}`, type: "bar", xAxisColumn: xCol, yAxisColumn: yCol, aggregation: "SUM", colSpan: 2 },
    { id: "chart-2", title: `${yCol} Trajectory`, type: "line", xAxisColumn: xCol, yAxisColumn: yCol, aggregation: "SUM", colSpan: 1 },
    { id: "chart-3", title: `Share of ${yCol}`, type: "pie", xAxisColumn: xCol, yAxisColumn: yCol, aggregation: "SUM", colSpan: 1 },
  ];

  renderKpis();
  renderCharts();
}

// Render KPI Scorecards with Kinetic Count-Up Animation
function renderKpis() {
  const container = document.getElementById("kpiGrid");
  if (!container) return;

  container.innerHTML = "";

  state.kpis.forEach((kpi) => {
    const rawVal = computeAggregation(state.currentDataset.rows, kpi.column, kpi.aggregation);
    const card = document.createElement("div");
    card.className = "kpi-card animate-fade-in";

    card.innerHTML = `
      <div class="kpi-header">
        <div>
          <div class="kpi-label">${escapeHtml(kpi.title)}</div>
          <div class="kpi-metric-info">${kpi.aggregation} of ${kpi.column}</div>
        </div>
        <button class="btn btn-secondary" style="padding: 4px 8px; font-size: 11px;" onclick="removeKpi('${kpi.id}')">✕</button>
      </div>
      <div class="kpi-value" id="kpi-val-${kpi.id}">0</div>
      <div class="kpi-footer">
        <span class="trend-badge ${kpi.trendDirection === "up" ? "trend-up" : "trend-neutral"}">
          ${kpi.trendDirection === "up" ? "▲" : "•"} ${kpi.trendLabel || "Live aggregate"}
        </span>
        <span style="font-size: 10px; color: #64748b;">Formula calculation</span>
      </div>
    `;

    container.appendChild(card);
    animateNumber(`kpi-val-${kpi.id}`, rawVal, kpi.format);
  });
}

// Kinetic Animated Number Counter
function animateNumber(elementId, targetValue, format = "number") {
  const el = document.getElementById(elementId);
  if (!el) return;

  const duration = 800 / state.animationSpeed;
  const startVal = 0;
  const startTime = performance.now();

  function updateCount(currentTime) {
    const elapsed = currentTime - startTime;
    const progress = Math.min(elapsed / duration, 1);
    // Smooth easeOutCubic curve
    const ease = 1 - Math.pow(1 - progress, 3);
    const current = startVal + (targetValue - startVal) * ease;

    el.textContent = formatMetricValue(current, format);

    if (progress < 1) {
      requestAnimationFrame(updateCount);
    } else {
      el.textContent = formatMetricValue(targetValue, format);
    }
  }

  requestAnimationFrame(updateCount);
}

// Metric Value Formatter
function formatMetricValue(val, format) {
  if (isNaN(val)) return "N/A";
  if (format === "currency") {
    if (val >= 1000000) return `$${(val / 1000000).toFixed(2)}M`;
    if (val >= 1000) return `$${(val / 1000).toFixed(1)}k`;
    return `$${val.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  }
  if (format === "percentage") {
    return `${val.toFixed(1)}%`;
  }
  if (val >= 1000000) return `${(val / 1000000).toFixed(2)}M`;
  if (val >= 10000) return `${(val / 1000).toFixed(1)}k`;
  return val.toLocaleString();
}

// Compute Aggregation Value
function computeAggregation(rows, column, agg) {
  if (!rows || rows.length === 0) return 0;
  if (agg === "COUNT") return rows.length;

  const nums = rows
    .map((r) => {
      const v = r[column];
      return typeof v === "number" ? v : parseFloat(String(v).replace(/[$,%]/g, ""));
    })
    .filter((v) => !isNaN(v));

  if (nums.length === 0) return 0;

  if (agg === "SUM") return nums.reduce((a, b) => a + b, 0);
  if (agg === "AVERAGE") return nums.reduce((a, b) => a + b, 0) / nums.length;
  if (agg === "MAX") return Math.max(...nums);
  if (agg === "MIN") return Math.min(...nums);
  return nums.reduce((a, b) => a + b, 0);
}

// Render Graphical Visualizations with Chart.js
function renderCharts() {
  const container = document.getElementById("chartsGrid");
  if (!container || !state.currentDataset) return;

  // Clean up existing Chart.js instances
  Object.values(state.chartInstances).forEach((inst) => inst?.destroy());
  state.chartInstances = {};
  container.innerHTML = "";

  state.charts.forEach((chartConfig) => {
    const card = document.createElement("div");
    card.className = `chart-card ${chartConfig.colSpan === 2 ? "full-width" : ""}`;

    const canvasId = `canvas-${chartConfig.id}`;
    card.innerHTML = `
      <div class="chart-header">
        <div>
          <div class="chart-title">${escapeHtml(chartConfig.title)}</div>
          <div style="font-size: 11px; color: #64748b;">${chartConfig.aggregation} of ${chartConfig.yAxisColumn} by ${chartConfig.xAxisColumn}</div>
        </div>
        <div style="display: flex; gap: 6px;">
          <button class="btn btn-secondary" style="padding: 4px 8px; font-size: 11px;" onclick="toggleChartType('${chartConfig.id}')">Switch Type</button>
          <button class="btn btn-secondary" style="padding: 4px 8px; font-size: 11px;" onclick="removeChart('${chartConfig.id}')">✕</button>
        </div>
      </div>
      <div class="chart-canvas-wrap">
        <canvas id="${canvasId}"></canvas>
      </div>
    `;

    container.appendChild(card);
    buildChartInstance(canvasId, chartConfig);
  });
}

// Build Chart.js Instance
function buildChartInstance(canvasId, config) {
  const canvas = document.getElementById(canvasId);
  if (!canvas || !window.Chart) return;

  // Aggregate data points by x-axis
  const grouped = {};
  state.currentDataset.rows.forEach((r) => {
    const key = String(r[config.xAxisColumn] || "Other");
    const val = Number(r[config.yAxisColumn]) || 0;
    grouped[key] = (grouped[key] || 0) + val;
  });

  const labels = Object.keys(grouped);
  const dataVals = Object.values(grouped);

  const colors = [
    "rgba(99, 102, 241, 0.8)",
    "rgba(16, 185, 129, 0.8)",
    "rgba(245, 158, 11, 0.8)",
    "rgba(6, 182, 212, 0.8)",
    "rgba(244, 63, 94, 0.8)",
    "rgba(168, 85, 247, 0.8)",
  ];

  let chartType = config.type;
  if (chartType === "area") chartType = "line";

  const chart = new Chart(canvas, {
    type: chartType,
    data: {
      labels: labels,
      datasets: [
        {
          label: config.yAxisColumn,
          data: dataVals,
          backgroundColor: config.type === "pie" ? colors : colors[0],
          borderColor: config.type === "pie" ? "#ffffff" : "rgba(99, 102, 241, 1)",
          borderWidth: 2,
          fill: config.type === "area",
          tension: 0.35,
          borderRadius: 8,
        },
      ],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          display: config.type === "pie",
          position: "bottom",
        },
      },
      scales: config.type === "pie" ? {} : {
        y: {
          beginAtZero: true,
          grid: { color: "rgba(0, 0, 0, 0.05)" },
        },
        x: {
          grid: { display: false },
        },
      },
    },
  });

  state.chartInstances[config.id] = chart;
}

// Toggle Chart Type
window.toggleChartType = function (chartId) {
  const chart = state.charts.find((c) => c.id === chartId);
  if (!chart) return;
  const types = ["bar", "line", "pie", "area"];
  const currentIdx = types.indexOf(chart.type);
  chart.type = types[(currentIdx + 1) % types.length];
  renderCharts();
};

// Remove KPI
window.removeKpi = function (id) {
  state.kpis = state.kpis.filter((k) => k.id !== id);
  renderKpis();
};

// Remove Chart
window.removeChart = function (id) {
  state.charts = state.charts.filter((c) => c.id !== id);
  renderCharts();
};

// Render Data Table
function renderDataTable() {
  const container = document.getElementById("tableContainer");
  if (!container || !state.currentDataset) return;

  const cols = state.currentDataset.columns;
  let rows = state.currentDataset.rows;

  if (state.filterQuery) {
    rows = rows.filter((r) =>
      cols.some((c) => String(r[c.name]).toLowerCase().includes(state.filterQuery))
    );
  }

  let html = `<table class="data-table"><thead><tr>`;
  cols.forEach((col) => {
    html += `<th>${escapeHtml(col.name)}</th>`;
  });
  html += `</tr></thead><tbody>`;

  rows.slice(0, 50).forEach((row) => {
    html += `<tr>`;
    cols.forEach((col) => {
      html += `<td>${escapeHtml(String(row[col.name] ?? ""))}</td>`;
    });
    html += `</tr>`;
  });

  html += `</tbody></table>`;
  container.innerHTML = html;
}

// Export CSV
function exportCurrentDataCsv() {
  if (!state.currentDataset) return;
  const cols = state.currentDataset.columns.map((c) => c.name);
  const rows = state.currentDataset.rows;

  const csvRows = [cols.join(",")];
  rows.forEach((r) => {
    const line = cols.map((c) => JSON.stringify(r[c] ?? "")).join(",");
    csvRows.push(line);
  });

  const blob = new Blob([csvRows.join("\n")], { type: "text/csv" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `${state.currentDataset.name.replace(/\.[^/.]+$/, "")}_export.csv`;
  a.click();
  URL.revokeObjectURL(url);
}

// Modal Setup Helper
function setupModal(modalId, openBtnId, closeBtnId) {
  const modal = document.getElementById(modalId);
  const openBtn = document.getElementById(openBtnId);
  const closeBtn = document.getElementById(closeBtnId);

  openBtn?.addEventListener("click", () => modal?.classList.add("open"));
  closeBtn?.addEventListener("click", () => modal?.classList.remove("open"));

  modal?.addEventListener("click", (e) => {
    if (e.target === modal) modal.classList.remove("open");
  });
}

// Handle Add KPI Form
function handleAddKpiSubmit(e) {
  e.preventDefault();
  const title = document.getElementById("kpiTitleInput")?.value || "Metric";
  const column = document.getElementById("kpiColumnSelect")?.value;
  const aggregation = document.getElementById("kpiAggSelect")?.value || "SUM";
  const format = document.getElementById("kpiFormatSelect")?.value || "number";

  state.kpis.push({
    id: `kpi-custom-${Date.now()}`,
    title: title,
    column: column,
    aggregation: aggregation,
    format: format,
    trendLabel: "+10% manual KPI",
    trendDirection: "up",
  });

  document.getElementById("modalAddKpi")?.classList.remove("open");
  renderKpis();
}

// Handle Add Chart Form
function handleAddChartSubmit(e) {
  e.preventDefault();
  const title = document.getElementById("chartTitleInput")?.value || "Custom Chart";
  const type = document.getElementById("chartTypeSelect")?.value || "bar";
  const xCol = document.getElementById("chartXSelect")?.value;
  const yCol = document.getElementById("chartYSelect")?.value;
  const agg = document.getElementById("chartAggSelect")?.value || "SUM";
  const colSpan = Number(document.getElementById("chartSpanSelect")?.value) || 1;

  state.charts.push({
    id: `chart-custom-${Date.now()}`,
    title: title,
    type: type,
    xAxisColumn: xCol,
    yAxisColumn: yCol,
    aggregation: agg,
    colSpan: colSpan,
  });

  document.getElementById("modalAddChart")?.classList.remove("open");
  renderCharts();
}

function escapeHtml(str) {
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}
